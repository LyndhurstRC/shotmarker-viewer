cd /app && node server.js >> /dev/null 2>&1 || node recovery.js >> /dev/null 2>&1 &
