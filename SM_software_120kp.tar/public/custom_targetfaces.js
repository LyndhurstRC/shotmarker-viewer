

// **********    IMPORTANT    READ THIS      *********
/*

	This file is standard Javascript code which will be integrated into
	the ShotMarker software running on the Access Point you install it on.

	If there is an error, usually the browser will display an error in the
	developer console (F12 with Chrome) and you will still be able to otherwise
	use the software and install a different version.

	If you cannot, go to this page and select "Update Software":
	192.168.100.1/recovery.html

	It is POSSIBLE that you will be unable to revert to a previous version without support.

	ONLY PROCEED if you accept the risk that if there is a mistake in this code, it is POSSIBLE
	that recovering your Access Point will require either shipping it to Canada, or replacing the SD card.

	*****  Do not proceed unless you understand the risk.  *****

	Basic JSON tutorial:
	https://www.w3schools.com/js/js_json_intro.asp

	You can use notepad, but if you use a proper code editor you will see syntax errors:
	https://code.visualstudio.com/

	I have a program for tracing the outline of a shape to generate coordinates.
	I will post that with a guide later.

	To use this file, you need the beta software version 1.11d or higher
	and to watch the video where I explain how to integrate this into your software.
	https://autotrickler.com/pages/support

*/


// these two lines must be here, as well as the closing bracket at the end of the file
custom_targetfaces = {}
function init_custom_targetfaces() {


	return; // DELETE THIS LINE to start using custom target faces




	// example target face
	// you can copy this section and have as many target faces as you want
	custom_targetfaces["mytarget"] = { // unique identifier, choose something simple
		
		name: "example custom target", // displayed name
		
		dist: 300, // default distance when the user selects this target in the list
		dist_unit: "y", // distance unit either "y" for yards or "m" for meters

		score: [10, "X"], // scoring system; the number is the points value of a letter

		board: {w: 1200, h: 1200, line: 20}, // outer board size, which the grid will stay within

		rings: [ // array of scoring rings

			/* each scoring ring has:

			 - x, y: optional position, center if not defined
			 - diam: ring diameter in milimeters, or divide by INCH to convert to inches
			 - color:
				w : white fill with black line
				b : black fill with white line
				g : grey fill with black line
				wl : white line, no fill
				bl : black line, no fill
				gl : grey line, no fill
			 - line: thickness in millimeters, 0 to have no line
			 - score: either a number, or one of the letters in "score" above

			the first rings in the list have priority, so the higher scores should be first (if they overlap)

			*/

			{x: 50, y: 50, diam: 2.85/INCH, color: "w", line: 3, score: "X"},

			{diam: 2.85/INCH, color: "b", line: 3, score: "X"},
			{diam: 5.85/INCH, color: "b", line: 6, score: 10},
			{diam: 8.85/INCH, color: "b", line: 6, score: 9},
			{diam: 11.85/INCH, color: "b", line: 6, score: 8},
			{diam: 17.85/INCH, color: "b", line: 6, score: 7},
			{diam: 23.85/INCH, color: "w", line: 6, score: 6},
			{diam: 29.85/INCH, color: "w", line: 6, score: 5},


		], // end of rings

		poly: [ // array of shapes, higher priority first


			{ // each shape is a closed polygon
				points: [ // list of xy coordinates
					{x: -500, y: 200},
					{x: 500, y: 200},
					{x: 500, y: -200},
					{x: -500, y: -200},
				],
				color: "w", // see rings for explanation of the colors
				line: 5, // line thickness
				score: 1 // score for a shot touching this polygon
			}, // end of shape


		], // end of poly

	}; // end of target face definition



	// example clean target (for starting from scratch)
	custom_targetfaces["basic"] = {
		
		name: "example basic",
		
		dist: 300,
		dist_unit: "y",

		score: [10],

		board: {w: 1200, h: 1200, line: 20},

		rings: [

			{diam: 5/INCH, color: "b", line: 3, score: 10},

		], // rings

		poly: [

			{points: [
				{x: -200, y: 100},
				{x: 200, y: 100},
				{x: 200, y: -100},
				{x: -200, y: -100},
			], color: "w", line: 5, score: 1},


		], // poly

	}; // target


	// example NRA long range
	custom_targetfaces["NRA_LR"] = {
		name: "example NRA LR",
		dist: 1000,
		dist_unit: "y",
		score: [10, "X"],
		board: {w: 72/INCH, h: 72/INCH, line: 20, score: 6},
		rings: [
			{diam: 10/INCH, color: "b", line: 10, score: "X"},
			{diam: 20/INCH, color: "b", line: 10, score: 10},
			{diam: 30/INCH, color: "b", line: 10, score: 9},
			{diam: 44/INCH, color: "b", line: 10, score: 8},
			{diam: 60/INCH, color: "w", line: 10, score: 7},
		],
	};

	
	// example: figure 14
	custom_targetfaces["Fig14"] = {
		name: "example figure 14",
		dist: 300,
		dist_unit: "y",
		score: [5],
		board: {w: 1200, h: 1200, line: 5, score: 0},
		rings: [
			{diam: 100, color: "bl", line: 4, score: 5}
		],
		poly: [

			{points: [
				{x: 0 -128, y: -285 +138},
				{x: 17 -128, y: -250 +138},
				{x: 41 -128, y: -232 +138},
				{x: 44 -128, y: -210 +138},
				{x: 29 -128, y: -165 +138},
				{x: 37 -128, y: -150 +138},
				{x: 102 -128, y: -118 +138},
				{x: 128- 102, y: -118 +138},
				{x: 128- 37, y: -150 +138},
				{x: 128- 29, y: -165 +138},
				{x: 128- 44, y: -210 +138},
				{x: 128- 41, y: -232 +138},
				{x: 128- 17, y: -250 +138},
				{x: 128- 0, y: -285 +138},
			], color: "g", line: 4, score: 4},

			{points: [
				{x: 37 -128, y: -150 +138},
				{x: 56 -128, y: -53 +138},
				{x: 76 -128, y: -14 +138},
				{x: 100 -128, y: 0 +138},
				{x: 128- 100, y: 0 +138},
				{x: 128- 76, y: -14 +138},
				{x: 128- 56, y: -53 +138},
				{x: 128- 37, y: -150 +138},
				{x: 128- 102, y: -118 +138},
				{x: 102 -128, y: -118 +138},
			], color: "w", line: 4, score: 4},

		],
	};


	// example multiple aiming marks
	custom_targetfaces["multirings"] = {
		name: "example multiples",
		dist: 100,
		dist_unit: "y",
		score: [10, "X"],
		board: {w: 24/INCH, h: 24/INCH, line: 2},
		rings: [

			// center
			{x: 0, y: 0, diam: 1/INCH, color: "b", line: 0, score: "X"},
			{x: 0, y: 0, diam: 2/INCH, color: "bl", line: 2, score: 10},
			{x: 0, y: 0, diam: 4/INCH, color: "bl", line: 2, score: 9},

			// left
			{x: -6/INCH, y: 0, diam: 1/INCH, color: "b", line: 0, score: "X"},
			{x: -6/INCH, y: 0, diam: 2/INCH, color: "bl", line: 2, score: 10},
			{x: -6/INCH, y: 0, diam: 4/INCH, color: "bl", line: 2, score: 9},

			// right
			{x: 6/INCH, y: 0, diam: 1/INCH, color: "b", line: 0, score: "X"},
			{x: 6/INCH, y: 0, diam: 2/INCH, color: "bl", line: 2, score: 10},
			{x: 6/INCH, y: 0, diam: 4/INCH, color: "bl", line: 2, score: 9},

		],
	};




// this closing bracket must be here !!!!
}


