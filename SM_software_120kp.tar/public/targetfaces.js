

var targetfaces = {};
var targetface_categories = [];

// points of a box
function polybox(x, y, w, h) {
	return [{x: x-w/2, y: y-h/2}, {x: x-w/2, y: y+h/2}, {x: x+w/2, y: y+h/2}, {x: x+w/2, y: y-h/2}];
}

// points of circular arc
// from left, clockwise, degrees
// resolution in mm
function polyarc(x, y, r, a0, a1, res) {
	var points = [];
	var n = Math.ceil((a1 - a0) / res);
	if (n < 3) n = 3;
	var da = (a1 - a0) / (n-1);
	for (var i = 0; i < n; i++) {
		var a = (a0 + i * da) * PI / 180;
		var p = {
			x: x - r * Math.cos(a),
			y: y + r * Math.sin(a)
		}
		points.push(p);
	}
	return points;
}


// return text in a linear pattern
function text_rings(origin, increment, from, to, params) {
	var result = [];
	var x = origin.x;
	var y = origin.y;
	for (var i = from; i >= to; i--) {
		var text = {};
		update_object(text, params);
		text.x = x;
		text.y = y;
		text.text = i;
		result.push(text);
		x += increment.x;
		y += increment.y;
	}
	return result;
}

// add text to a face for all rings automatically
function add_default_ring_text(face) {
	
	if (!face.rings || face.rings.length < 3) return;
	if (!face.text) face.text = [];
	
	var size_base = (face.rings[2].diam - face.rings[1].diam) * 0.25;

	for (var i = 0; i < face.rings.length; i++) {
		
		var x = face.rings[i].x || 0;
		var y = face.rings[i].y || 0;
		var size = size_base;
		if (i && face.rings[i].x == face.rings[i-1].x) {
			var left = face.rings[i-1].diam/2;
			var right = face.rings[i].diam/2 - face.rings[i].line;
			x += (left + right) / 2;
			size = size * 0.7;
		}
		
		face.text.push({x: x, y: y, size: size, color: "gl", text: face.rings[i].score});
		
	}
	
}

// Misc

function init_targetfaces() {

	// custom scaled 200 yd

    targetfaces["NRA_MR52FC"] = {
        name: "NRA MR-52FC",
        shortname: "MR-52FC (200)",
        dist: 200,
        dist_unit: "y",
        score: [10, "X"],
        board: {w: 1200, h: 1200, line: 20},
        rings: [    {diam: 0.89/INCH, color: "b", line: 2, score: "X"},
                    {diam: 1.79/INCH, color: "b", line: 4, score: 10},
                    {diam: 3.79/INCH, color: "b", line: 4, score: 9},
                    {diam: 5.79/INCH, color: "b", line: 4, score: 8},
                    {diam: 7.79/INCH, color: "b", line: 4, score: 7},
                    {diam: 11.79/INCH, color: "b", line: 4, score: 6},
                    {diam: 15.79/INCH, color: "w", line: 4, score: 5}
        ],
        default_ring_text: true,
    };


	targetfaces["NRA_A32"] = {
		name: "NRA A-32",
		shortname: "NRA A-32 (50ft)",
		force_colors: true,
		dist: 15,
		dist_unit: "y",
		board: {w: 12/INCH, h: 9.5/INCH, line: 2},
		score: [10],

		rings: [

			{diam: 0.218/INCH, color: "w", line: 0, x: 0-3.87/INCH, y: 0-1.955/INCH, score: 10},
			{diam: 0.439/INCH, color: "b", line: 0.6, x: 0-3.87/INCH, y: 0-1.955/INCH, score: 10},
			{diam: 1.187/INCH, color: "b", line: 0.6, x: 0-3.87/INCH, y: 0-1.955/INCH, score: 9},
			{diam: 1.874/INCH, color: "b", line: 0, x: 0-3.87/INCH, y: 0-1.955/INCH, score: 8},
			{diam: 2.656/INCH, color: "w", line: 0.6, x: 0-3.87/INCH, y: 0-1.955/INCH, score: 7},
			{diam: 3.374/INCH, color: "w", line: 0.6, x: 0-3.87/INCH, y: 0-1.955/INCH, score: 6},

			{diam: 0.218/INCH, color: "w", line: 0, x: 0-3.87/INCH, y: 0+1.955/INCH, score: 10},
			{diam: 0.439/INCH, color: "b", line: 0.6, x: 0-3.87/INCH, y: 0+1.955/INCH, score: 10},
			{diam: 1.187/INCH, color: "b", line: 0.6, x: 0-3.87/INCH, y: 0+1.955/INCH, score: 9},
			{diam: 1.874/INCH, color: "b", line: 0, x: 0-3.87/INCH, y: 0+1.955/INCH, score: 8},
			{diam: 2.656/INCH, color: "w", line: 0.6, x: 0-3.87/INCH, y: 0+1.955/INCH, score: 7},
			{diam: 3.374/INCH, color: "w", line: 0.6, x: 0-3.87/INCH, y: 0+1.955/INCH, score: 6},

			{diam: 0.218/INCH, color: "w", line: 0, x: 0, y: 0-1.955/INCH, score: 10},
			{diam: 0.439/INCH, color: "b", line: 0.6, x: 0, y: 0-1.955/INCH, score: 10},
			{diam: 1.187/INCH, color: "b", line: 0.6, x: 0, y: 0-1.955/INCH, score: 9},
			{diam: 1.874/INCH, color: "b", line: 0, x: 0, y: 0-1.955/INCH, score: 8},
			{diam: 2.656/INCH, color: "w", line: 0.6, x: 0, y: 0-1.955/INCH, score: 7},
			{diam: 3.374/INCH, color: "w", line: 0.6, x: 0, y: 0-1.955/INCH, score: 6},

			// sighting
			{diam: 0.218/INCH, color: "w", line: 0, x: 0, y: 0+1.955/INCH},
			{diam: 0.439/INCH, color: "b", line: 0.6, x: 0, y: 0+1.955/INCH},
			{diam: 1.187/INCH, color: "b", line: 0.6, x: 0, y: 0+1.955/INCH},
			{diam: 1.874/INCH, color: "b", line: 0, x: 0, y: 0+1.955/INCH},
			{diam: 3.374/INCH, color: "w", line: 0.6, x: 0, y: 0+1.955/INCH},

			{diam: 0.218/INCH, color: "w", line: 0, x: 0+3.87/INCH, y: 0-1.955/INCH, score: 10},
			{diam: 0.439/INCH, color: "b", line: 0.6, x: 0+3.87/INCH, y: 0-1.955/INCH, score: 10},
			{diam: 1.187/INCH, color: "b", line: 0.6, x: 0+3.87/INCH, y: 0-1.955/INCH, score: 9},
			{diam: 1.874/INCH, color: "b", line: 0, x: 0+3.87/INCH, y: 0-1.955/INCH, score: 8},
			{diam: 2.656/INCH, color: "w", line: 0.6, x: 0+3.87/INCH, y: 0-1.955/INCH, score: 7},
			{diam: 3.374/INCH, color: "w", line: 0.6, x: 0+3.87/INCH, y: 0-1.955/INCH, score: 6},

			{diam: 0.218/INCH, color: "w", line: 0, x: 0+3.87/INCH, y: 0+1.955/INCH, score: 10},
			{diam: 0.439/INCH, color: "b", line: 0.6, x: 0+3.87/INCH, y: 0+1.955/INCH, score: 10},
			{diam: 1.187/INCH, color: "b", line: 0.6, x: 0+3.87/INCH, y: 0+1.955/INCH, score: 9},
			{diam: 1.874/INCH, color: "b", line: 0, x: 0+3.87/INCH, y: 0+1.955/INCH, score: 8},
			{diam: 2.656/INCH, color: "w", line: 0.6, x: 0+3.87/INCH, y: 0+1.955/INCH, score: 7},
			{diam: 3.374/INCH, color: "w", line: 0.6, x: 0+3.87/INCH, y: 0+1.955/INCH, score: 6},

		],

		text: [
			{x: 0, y: 3.16/INCH, size: 0.15/INCH, color: "bl", text: "SIGHTING ONLY"},
			{x: -2.5/INCH, y: 0.3/INCH, size: 0.2/INCH, color: "bl", text: "1"},
			{x: (-2.5+3.87+3.87)/INCH, y: 0.3/INCH, size: 0.2/INCH, color: "bl", text: "2"},
			{x: -2.5/INCH, y: (0.3-3.91)/INCH, size: 0.2/INCH, color: "bl", text: "3"},
			{x: (-2.5+3.87)/INCH, y: (0.3-3.91)/INCH, size: 0.2/INCH, color: "bl", text: "4"},
			{x: (-2.5+3.87+3.87)/INCH, y: (0.3-3.91)/INCH, size: 0.2/INCH, color: "bl", text: "5"},
		],

	};

	targetfaces["NRA_A23_5"] = {
		name: "NRA A-23/5",
		shortname: "NRA A-23/5 (50)",
		force_colors: true,
		dist: 50,
		dist_unit: "y",
		board: {w: 14/INCH, h: 23/INCH, line: 3},
		score: [10, "X"],

		rings: [

			{diam: 0.39/INCH, color: "b", line: 0.8, x: 0, y: 7.27/INCH},
			{diam: 0.89/INCH, color: "b", line: 0.8, x: 0, y: 7.27/INCH},
			{diam: 1.89/INCH, color: "b", line: 0.8, x: 0, y: 7.27/INCH},
			{diam: 2.89/INCH, color: "b", line: 0.8, x: 0, y: 7.27/INCH},
			{diam: 3.89/INCH, color: "b", line: 0.8, x: 0, y: 7.27/INCH},
			{diam: 4.89/INCH, color: "w", line: 0.8, x: 0, y: 7.27/INCH},
			{diam: 5.89/INCH, color: "w", line: 0.8, x: 0, y: 7.27/INCH},

			{diam: 0.39/INCH, color: "b", line: 0.8, x: -3.55/INCH, y: 0, score: "X"},
			{diam: 0.89/INCH, color: "b", line: 0.8, x: -3.55/INCH, y: 0, score: 10},
			{diam: 1.89/INCH, color: "b", line: 0.8, x: -3.55/INCH, y: 0, score: 9},
			{diam: 2.89/INCH, color: "b", line: 0.8, x: -3.55/INCH, y: 0, score: 8},
			{diam: 3.89/INCH, color: "b", line: 0.8, x: -3.55/INCH, y: 0, score: 7},
			{diam: 4.89/INCH, color: "w", line: 0.8, x: -3.55/INCH, y: 0, score: 6},
			{diam: 5.89/INCH, color: "w", line: 0.8, x: -3.55/INCH, y: 0, score: 6},

			{diam: 0.39/INCH, color: "b", line: 0.8, x: 3.55/INCH, y: 0, score: "X"},
			{diam: 0.89/INCH, color: "b", line: 0.8, x: 3.55/INCH, y: 0, score: 10},
			{diam: 1.89/INCH, color: "b", line: 0.8, x: 3.55/INCH, y: 0, score: 9},
			{diam: 2.89/INCH, color: "b", line: 0.8, x: 3.55/INCH, y: 0, score: 8},
			{diam: 3.89/INCH, color: "b", line: 0.8, x: 3.55/INCH, y: 0, score: 7},
			{diam: 4.89/INCH, color: "w", line: 0.8, x: 3.55/INCH, y: 0, score: 6},
			{diam: 5.89/INCH, color: "w", line: 0.8, x: 3.55/INCH, y: 0, score: 6},

			{diam: 0.39/INCH, color: "b", line: 0.8, x: -3.55/INCH, y: -7.03/INCH, score: "X"},
			{diam: 0.89/INCH, color: "b", line: 0.8, x: -3.55/INCH, y: -7.03/INCH, score: 10},
			{diam: 1.89/INCH, color: "b", line: 0.8, x: -3.55/INCH, y: -7.03/INCH, score: 9},
			{diam: 2.89/INCH, color: "b", line: 0.8, x: -3.55/INCH, y: -7.03/INCH, score: 8},
			{diam: 3.89/INCH, color: "b", line: 0.8, x: -3.55/INCH, y: -7.03/INCH, score: 7},
			{diam: 4.89/INCH, color: "w", line: 0.8, x: -3.55/INCH, y: -7.03/INCH, score: 6},
			{diam: 5.89/INCH, color: "w", line: 0.8, x: -3.55/INCH, y: -7.03/INCH, score: 6},

			{diam: 0.39/INCH, color: "b", line: 0.8, x: 3.55/INCH, y: -7.03/INCH, score: "X"},
			{diam: 0.89/INCH, color: "b", line: 0.8, x: 3.55/INCH, y: -7.03/INCH, score: 10},
			{diam: 1.89/INCH, color: "b", line: 0.8, x: 3.55/INCH, y: -7.03/INCH, score: 9},
			{diam: 2.89/INCH, color: "b", line: 0.8, x: 3.55/INCH, y: -7.03/INCH, score: 8},
			{diam: 3.89/INCH, color: "b", line: 0.8, x: 3.55/INCH, y: -7.03/INCH, score: 7},
			{diam: 4.89/INCH, color: "w", line: 0.8, x: 3.55/INCH, y: -7.03/INCH, score: 6},
			{diam: 5.89/INCH, color: "w", line: 0.8, x: 3.55/INCH, y: -7.03/INCH, score: 6},

		],

		text: [
			{x: -4.8/INCH, y: 7.27/INCH, size: 0.45/INCH, color: "bl", text: "S"},
			{x: 4.8/INCH, y: 7.27/INCH, size: 0.45/INCH, color: "bl", text: "S"},
			{x: -1/INCH, y: -2.5/INCH, size: 0.45/INCH, color: "bl", text: "1"},
			{x: (-1+7.1)/INCH, y: -2.5/INCH, size: 0.45/INCH, color: "bl", text: "2"},
			{x: -1/INCH, y: (-2.5-7.03)/INCH, size: 0.45/INCH, color: "bl", text: "3"},
			{x: (-1+7.1)/INCH, y: (-2.5-7.03)/INCH, size: 0.45/INCH, color: "bl", text: "4"},
		],

		poly: [
			{points: [{x: -7/INCH, y: 3.64/INCH}, {x: 7/INCH, y: 3.64/INCH}], color: "bl", line: 0.8},
		],

	};

	targetfaces["RNBRA"] = {
		name: "RNBRA",
		shortname: "RNBRA",
		force_colors: true,
		dist: 100,
		dist_unit: "m",
		board: {w: 16/INCH, h: 16/INCH, line: 1},
		score: [10],

		rings: [

			{diam: 0.25/INCH, color: "w", line: 0, x: 0, y: 0},
			{diam: 1/INCH, color: "g", line: 0.015/INCH, x: 0, y: 0, score: 10},
			{diam: 3/INCH, color: "w", line: 0.015/INCH, x: 0, y: 0, score: 9},
			{diam: 5/INCH, color: "g", line: 0.015/INCH, x: 0, y: 0, score: 8},
			{diam: 7/INCH, color: "w", line: 0.015/INCH, x: 0, y: 0, score: 7},
			{diam: 9/INCH, color: "g", line: 0.015/INCH, x: 0, y: 0, score: 6},
			{diam: 11/INCH, color: "w", line: 0.015/INCH, x: 0, y: 0, score: 5},
			{diam: 13/INCH, color: "g", line: 0.015/INCH, x: 0, y: 0, score: 4},

			{diam: 0.25/INCH, color: "w", line: 0/INCH, x: -6/INCH, y: -6/INCH},
			{diam: 1/INCH, color: "g", line: 0.015/INCH, x: -6/INCH, y: -6/INCH},
			{diam: 2/INCH, color: "w", line: 0.015/INCH, x: -6/INCH, y: -6/INCH},
			{diam: 3/INCH, color: "w", line: 0.1/INCH, x: -6/INCH, y: -6/INCH},

			{diam: 0.25/INCH, color: "w", line: 0/INCH, x: 6/INCH, y: 6/INCH},
			{diam: 1/INCH, color: "g", line: 0.015/INCH, x: 6/INCH, y: 6/INCH},
			{diam: 2/INCH, color: "w", line: 0.015/INCH, x: 6/INCH, y: 6/INCH},
			{diam: 3/INCH, color: "w", line: 0.1/INCH, x: 6/INCH, y: 6/INCH},

			{diam: 0.25/INCH, color: "w", line: 0/INCH, x: 6/INCH, y: -6/INCH},
			{diam: 1/INCH, color: "g", line: 0.015/INCH, x: 6/INCH, y: -6/INCH},
			{diam: 2/INCH, color: "w", line: 0.015/INCH, x: 6/INCH, y: -6/INCH},
			{diam: 3/INCH, color: "w", line: 0.1/INCH, x: 6/INCH, y: -6/INCH},

			{diam: 0.25/INCH, color: "w", line: 0/INCH, x: -6/INCH, y: 6/INCH},
			{diam: 1/INCH, color: "g", line: 0.015/INCH, x: -6/INCH, y: 6/INCH},
			{diam: 2/INCH, color: "w", line: 0.015/INCH, x: -6/INCH, y: 6/INCH},
			{diam: 3/INCH, color: "w", line: 0.1/INCH, x: -6/INCH, y: 6/INCH},


		],

		poly_top: [

			{points: [{x: -6.75/INCH, y: 0}, {x: -0.5/INCH, y: 0}], color: "bl", line: 0.015/INCH},
			{points: [{x: 6.75/INCH, y: 0}, {x: 0.5/INCH, y: 0}], color: "bl", line: 0.015/INCH},
			{points: [{x: 0, y: 6.75/INCH}, {x: 0, y: 0.5/INCH}], color: "bl", line: 0.015/INCH},
			{points: [{x: 0, y: -6.75/INCH}, {x: 0, y: -0.5/INCH}], color: "bl", line: 0.015/INCH},

		],

		text: [

			{x: 0/INCH, y: -0.35/INCH, size: 0.25/INCH, color: "bl", text: "10"},
			{x: 1/INCH, y: -0.35/INCH, size: 0.25/INCH, color: "bl", text: "9"},
			{x: 2/INCH, y: -0.35/INCH, size: 0.25/INCH, color: "bl", text: "8"},
			{x: 3/INCH, y: -0.35/INCH, size: 0.25/INCH, color: "bl", text: "7"},
			{x: 4/INCH, y: -0.35/INCH, size: 0.25/INCH, color: "bl", text: "6"},
			{x: 5/INCH, y: -0.35/INCH, size: 0.25/INCH, color: "bl", text: "5"},
			{x: 6/INCH, y: -0.35/INCH, size: 0.25/INCH, color: "bl", text: "4"},
			{x: -1/INCH, y: -0.35/INCH, size: 0.25/INCH, color: "bl", text: "9"},
			{x: -2/INCH, y: -0.35/INCH, size: 0.25/INCH, color: "bl", text: "8"},
			{x: -3/INCH, y: -0.35/INCH, size: 0.25/INCH, color: "bl", text: "7"},
			{x: -4/INCH, y: -0.35/INCH, size: 0.25/INCH, color: "bl", text: "6"},
			{x: -5/INCH, y: -0.35/INCH, size: 0.25/INCH, color: "bl", text: "5"},
			{x: -6/INCH, y: -0.35/INCH, size: 0.25/INCH, color: "bl", text: "4"},

			{x: 0/INCH, y: -7.5/INCH, size: 0.25/INCH, color: "bl", text: "rnbra.ca"},

		],



	};

	//Simon Barrie
	targetfaces["RingTarget200"] = {
		name: "Ring Target 200yd",
		shortname: "Ring 200yd",
		dist: 200,
		dist_unit: "y",
		score: [13],
		board: {w: 48/INCH, h: 48/INCH, line: 5, score: 1},

		rings: [
					{diam: 2/INCH, color: "b", line: 0.5, score: 13},
					{diam: 5/INCH, color: "b", line: 0.5, score: 12},
					{diam: 8/INCH, color: "b", line: 1, score: 11},
					{diam: 12/INCH, color: "w", line: 1, score: 10},
					{diam: 16/INCH, color: "w", line: 1, score: 9},
					{diam: 20/INCH, color: "w", line: 1, score: 8},
					{diam: 24/INCH, color: "w", line: 1, score: 7},
					{diam: 28/INCH, color: "w", line: 1, score: 6},
					{diam: 32/INCH, color: "w", line: 1, score: 5},
					{diam: 36/INCH, color: "w", line: 1, score: 4},
					{diam: 40/INCH, color: "w", line: 1, score: 3},
					{diam: 44/INCH, color: "w", line: 1, score: 2}
		],

		default_ring_text: true,

	};


	targetfaces["TRD"] = {
		name: "TRD",
		shortname: "TRD",
		dist: 300,
		dist_unit: "y",
		score: [5, "V"],
		board: {w: 1000, h: 1000, line: 2, score: 0},
		
		rings: [
			{diam: 112, color: "wl", line: 7, score: "V"},
		],

		poly: [			
			{points: [

				{x: -207.8, y: -82.1},
				{x: 207.2, y: -82.7},
				{x: 207.2, y: -33.5},
				{x: 206.0, y: -24.6},
				{x: 203.6, y: -17.4},
				{x: 200.6, y: -12.0},
				{x: 196.4, y: -7.2},
				{x: 191.1, y: -3.0},
				{x: 185.1, y: 0.6},
				{x: 170.1, y: 4.8},
				{x: 152.7, y: 11.4},
				{x: 139.0, y: 18.0},
				{x: 125.2, y: 25.8},
				{x: 110.8, y: 35.3},
				{x: 96.4, y: 46.1},
				{x: 83.9, y: 57.5},
				{x: 70.7, y: 71.9},
				{x: 59.3, y: 85.6},
				{x: 48.5, y: 101.8},
				{x: 38.9, y: 121.0},
				{x: 30.5, y: 141.3},
				{x: 24.6, y: 159.9},
				{x: 21.6, y: 171.9},
				{x: 19.2, y: 191.1},
				{x: 17.4, y: 199.4},
				{x: 12.6, y: 204.8},
				{x: 6.6, y: 208.4},
				{x: -2.4, y: 209.0},
				{x: -10.2, y: 206.6},
				{x: -15.6, y: 200.6},
				{x: -18.6, y: 193.5},
				{x: -21.0, y: 175.5},
				{x: -24.6, y: 158.7},
				{x: -29.3, y: 143.7},
				{x: -35.3, y: 127.6},
				{x: -42.5, y: 113.8},
				{x: -50.3, y: 100.0},
				{x: -59.9, y: 86.2},
				{x: -71.9, y: 70.1},
				{x: -83.3, y: 58.7},
				{x: -97.6, y: 44.9},
				{x: -112.6, y: 33.5},
				{x: -126.4, y: 25.8},
				{x: -141.9, y: 16.8},
				{x: -157.5, y: 9.6},
				{x: -171.9, y: 4.8},
				{x: -183.3, y: 1.2},
				{x: -191.1, y: -3.0},
				{x: -197.6, y: -8.4},
				{x: -202.4, y: -15.0},
				{x: -206.0, y: -22.8},
				{x: -207.2, y: -30.5},

			], color: "b", line: 7, score: 5},
							
			{points: [

				{x: -306.7, y: -140.1},
				{x: 306.7, y: -140.1},
				{x: 306.7, y: -13.8},
				{x: 304.3, y: 3.0},
				{x: 301.3, y: 14.4},
				{x: 297.7, y: 22.8},
				{x: 292.3, y: 33.5},
				{x: 286.3, y: 43.7},
				{x: 279.1, y: 52.1},
				{x: 271.3, y: 61.1},
				{x: 261.7, y: 68.9},
				{x: 251.6, y: 76.1},
				{x: 240.2, y: 82.7},
				{x: 225.2, y: 88.0},
				{x: 209.0, y: 94.0},
				{x: 194.7, y: 101.8},
				{x: 182.7, y: 108.4},
				{x: 170.7, y: 117.4},
				{x: 159.9, y: 128.8},
				{x: 148.5, y: 140.1},
				{x: 139.0, y: 153.3},
				{x: 131.2, y: 165.9},
				{x: 124.6, y: 178.5},
				{x: 118.6, y: 193.5},
				{x: 114.4, y: 210.8},
				{x: 110.2, y: 228.8},
				{x: 103.6, y: 243.8},
				{x: 95.2, y: 256.9},
				{x: 85.0, y: 270.1},
				{x: 71.9, y: 282.1},
				{x: 57.5, y: 291.7},
				{x: 42.5, y: 298.9},
				{x: 27.6, y: 303.7},
				{x: 9.0, y: 306.1},
				{x: -6.6, y: 306.7},
				{x: -24.0, y: 304.3},
				{x: -38.9, y: 299.5},
				{x: -53.9, y: 294.1},
				{x: -67.1, y: 285.7},
				{x: -79.7, y: 274.9},
				{x: -90.4, y: 264.7},
				{x: -98.2, y: 252.7},
				{x: -105.4, y: 239.6},
				{x: -110.8, y: 226.4},
				{x: -114.4, y: 210.8},
				{x: -118.6, y: 195.9},
				{x: -124.0, y: 180.9},
				{x: -131.8, y: 165.9},
				{x: -140.1, y: 153.3},
				{x: -148.5, y: 140.7},
				{x: -158.7, y: 129.4},
				{x: -170.1, y: 118.6},
				{x: -182.1, y: 110.2},
				{x: -192.9, y: 103.0},
				{x: -206.6, y: 95.2},
				{x: -219.8, y: 89.2},
				{x: -237.8, y: 83.3},
				{x: -250.4, y: 76.7},
				{x: -261.7, y: 68.9},
				{x: -272.5, y: 59.9},
				{x: -282.1, y: 49.7},
				{x: -289.3, y: 38.9},
				{x: -295.9, y: 27.6},
				{x: -300.7, y: 16.2},
				{x: -304.9, y: -0.6},
				{x: -306.7, y: -17.4},


			], color: "b", line: 0, score: 4},	
			
			//outline
			{points: [

				{x: -398.9, y: -340.2},
				{x: 398.9, y: -340.2},
				{x: 398.9, y: -14.4},
				{x: 397.1, y: 4.8},
				{x: 394.1, y: 23.4},
				{x: 388.1, y: 43.7},
				{x: 382.1, y: 60.5},
				{x: 373.7, y: 77.9},
				{x: 362.4, y: 96.4},
				{x: 349.2, y: 113.2},
				{x: 334.8, y: 128.2},
				{x: 316.8, y: 143.1},
				{x: 301.3, y: 153.9},
				{x: 285.1, y: 162.9},
				{x: 268.3, y: 170.1},
				{x: 249.8, y: 176.7},
				{x: 235.4, y: 185.1},
				{x: 225.2, y: 193.5},
				{x: 215.0, y: 203.6},
				{x: 207.2, y: 213.8},
				{x: 201.2, y: 225.2},
				{x: 195.9, y: 238.4},
				{x: 191.1, y: 256.9},
				{x: 185.1, y: 272.5},
				{x: 179.7, y: 284.5},
				{x: 170.7, y: 298.9},
				{x: 160.5, y: 312.0},
				{x: 150.3, y: 325.8},
				{x: 137.2, y: 339.0},
				{x: 124.0, y: 349.8},
				{x: 107.8, y: 361.8},
				{x: 90.4, y: 371.3},
				{x: 73.7, y: 378.5},
				{x: 53.9, y: 385.1},
				{x: 33.5, y: 389.9},
				{x: 11.4, y: 392.3},
				{x: -11.4, y: 392.3},
				{x: -32.9, y: 389.9},
				{x: -55.7, y: 384.5},
				{x: -74.3, y: 378.5},
				{x: -92.2, y: 370.1},
				{x: -110.8, y: 359.4},
				{x: -127.0, y: 348.0},
				{x: -140.1, y: 336.0},
				{x: -152.1, y: 322.8},
				{x: -164.7, y: 307.3},
				{x: -173.7, y: 293.5},
				{x: -182.7, y: 277.3},
				{x: -189.3, y: 260.5},
				{x: -195.3, y: 242.0},
				{x: -201.8, y: 225.2},
				{x: -209.0, y: 210.8},
				{x: -219.8, y: 197.6},
				{x: -232.4, y: 186.9},
				{x: -248.0, y: 177.9},
				{x: -267.1, y: 170.7},
				{x: -283.9, y: 163.5},
				{x: -299.5, y: 154.5},
				{x: -315.0, y: 144.3},
				{x: -329.4, y: 133.0},
				{x: -343.2, y: 119.8},
				{x: -353.4, y: 107.2},
				{x: -365.3, y: 91.6},
				{x: -373.7, y: 76.7},
				{x: -382.1, y: 60.5},
				{x: -388.7, y: 42.5},
				{x: -393.5, y: 24.6},
				{x: -397.7, y: 5.4},
				{x: -398.9, y: -13.8},

			], color: "bl", line: 7, score: 3},
			
		],
		text: [
			{x: 0, y: -5, size: 75, color: "wl", text: "V"},
			{x: 0, y: 120, size: 65, color: "wl", text: "5"},
			{x: 0, y: 250, size: 65, color: "wl", text: "4"},
			{x: 0, y: 340, size: 65, color: "bl", text: "3"},
			{x: 0, y: -280, size: 65, color: "bl", text: "3"},
		]

	};

	//Target for Brenden Hunt (Core 1200mmx1200mm) The shape in the middle is exactly twice the size of the minicore target
	targetfaces["Core"] = {
		name: "Core",
		shortname: "Core",
		dist: 500,
		dist_unit: "m",
		score: [5, "V"],
		board: {w: 1200, h: 1200, line: 10, score: 1},

		rings: [	
					
					{diam: 150, color: "wl", line: 5, score: "V"},
					{diam: 300, color: "wl", line: 5, score: 5},
					{diam: 600, color: "gl", line: 5, score: 4}, //line croses aiming mark. used Grey to make sure is was visible across whole target
					{diam: 900, color: "bl", line: 5, score: 3},
					{diam: 1200, color: "bl", line: 5, score: 2}
		],

		poly: [
					{points: [{x: -140.193*2, y: -90.6525*2}, {x: 137.957*2, y: -88.2442*2}, {x: 140.537*2, y: -35.2633*2}, 
					{x: 136.409*2, y: -8.42879*2}, {x: 126.776*2, y: 14.4493*2}, {x: 101.834*2, y: 62.0978*2}, 
					{x: 121.271*2, y: 74.655*2}, {x: 68.2904*2, y: 111.638*2}, {x:42.488*2, y: 127.464*2},
					{x: 31.995*2, y: 130.56*2}, {x: 20.8139*2, y: 133.14*2}, {x:7.39669*2, y: 133.484*2},
					{x: -11.3531*2, y: 131.936*2}, {x: -26.3185*2, y: 127.98*2}, {x:-38.0155*2, y: 122.991*2},
					{x: -55.3892*2, y: 110.262*2}, {x: -77.5792*2, y: 85.492*2}, {x:-96.329*2, y: 65.5381*2},
					{x: -102.694*2, y: 59.1735*2}, {x: -109.574*2, y: 52.6369*2}, {x:-115.595*2, y: 46.4443*2},
					{x: -107.682*2, y: 39.7357*2}, {x: -116.799*2, y: 22.1901*2}, {x:-124.368*2, y: 2.23621*2},
					{x: -131.248*2, y: -22.3621*2}, {x: -137.613*2, y: -52.9809*2}, {x:-140.365*2, y: -76.5471*2}], 
					color: "b"},
					//no points for hitting the mark in the center. scoring is entirely based on the rings
		],

		text: [
			{x: 0, y: -63+10, size: 50, color: "wl", text: "V"},
			{x: 0, y: -137+10, size: 50, color: "wl", text: "5"},
			{x: 0, y: -286+10, size: 50, color: "bl", text: "4"},
			{x: 0, y: -435+10, size: 50, color: "bl", text: "3"},
			{x: 0, y: -588+10, size: 50, color: "bl", text: "2"},
		]

	};

	targetfaces["MiniCore"] = {
		name: "Mini-Core",
		shortname: "Mini-Core",
		dist: 300,
		dist_unit: "m",
		score: [5, "V"],
		board: {w: 600, h: 600, line: 10, score: 1},

		rings: [	
					
					{diam: 75, color: "wl", line: 3, score: "V"},
					{diam: 150, color: "wl", line: 3, score: 5},
					{diam: 300, color: "gl", line: 3, score: 4},
					{diam: 450, color: "bl", line: 3, score: 3},
					{diam: 600, color: "bl", line: 3, score: 2}
		],

		poly: [
					{points: [{x: -140.193, y: -90.6525}, {x: 137.957, y: -88.2442}, {x: 140.537, y: -35.2633}, 
					{x: 136.409, y: -8.42879}, {x: 126.776, y: 14.4493}, {x: 101.834, y: 62.0978}, 
					{x: 121.271, y: 74.655}, {x: 68.2904, y: 111.638}, {x:42.488, y: 127.464},
					{x: 31.995, y: 130.56}, {x: 20.8139, y: 133.14}, {x:7.39669, y: 133.484},
					{x: -11.3531, y: 131.936}, {x: -26.3185, y: 127.98}, {x:-38.0155, y: 122.991},
					{x: -55.3892, y: 110.262}, {x: -77.5792, y: 85.492}, {x:-96.329, y: 65.5381},
					{x: -102.694, y: 59.1735}, {x: -109.574, y: 52.6369}, {x:-115.595, y: 46.4443},
					{x: -107.682, y: 39.7357}, {x: -116.799, y: 22.1901}, {x:-124.368, y: 2.23621},
					{x: -131.248, y: -22.3621}, {x: -137.613, y: -52.9809}, {x:-140.365, y: -76.5471}], 
					color: "b"},
		],

		text: [
			{x: 0, y: -26, size: 25, color: "wl", text: "V"},
			{x: 0, y: -63, size: 25, color: "wl", text: "5"},
			{x: 0, y: -138, size: 25, color: "bl", text: "4"},
			{x: 0, y: -214, size: 25, color: "bl", text: "3"},
			{x: 0, y: -286, size: 25, color: "bl", text: "2"},
		]

	};

	
	//Peter Cross Fly

	targetfaces["SSAAFly"] = {
		name: "SSAA Fly",
		shortname: "SSAA Fly",
		dist: 500,
		dist_unit: "m",
		score: [10, "X"],
		board: {w: 16.5/INCH, h: 23.4/INCH, line: 5, score: 0},


		poly_top: [

			//this is supposed to be a fly. I tried my best.
			{points: [				
				{x: -0.970, y: 9.210},
				{x: -0.431, y: 8.708},
				{x: 0.521, y: 8.636},
				{x: 1.365, y: 9.103},
				{x: 2.101, y: 8.187},
				{x: 2.891, y: 7.810},
				{x: 3.447, y: 7.235},
				{x: 3.393, y: 6.194},
				{x: 3.070, y: 5.566},
				{x: 2.855, y: 5.099},
				{x: 3.734, y: 5.117},
				{x: 4.147, y: 7.577},
				{x: 5.117, y: 9.677},
				{x: 6.446, y: 11.365},
				{x: 7.397, y: 11.473},
				{x: 7.433, y: 10.359},
				{x: 5.709, y: 7.325},
				{x: 4.884, y: 5.602},
				{x: 4.471, y: 3.716},
				{x: 4.111, y: 3.232},
				{x: 4.955, y: 2.101},
				{x: 7.218, y: 1.706},
				{x: 7.936, y: 3.088},
				{x: 8.403, y: 5.386},
				{x: 8.797, y: 6.517},
				{x: 10.036, y: 6.661},
				{x: 10.054, y: 4.040},
				{x: 9.570, y: 3.465},
				{x: 8.815, y: 0.359},
				{x: 8.187, y: -0.485},
				{x: 6.086, y: -0.144},
				{x: 5.225, y: -0.162},
				{x: 6.015, y: -3.752},
				{x: 7.325, y: -4.973},
				{x: 9.264, y: -7.074},
				{x: 10.072, y: -8.187},
				{x: 9.982, y: -8.887},
				{x: 8.618, y: -9.103},
				{x: 6.679, y: -6.212},
				{x: 6.428, y: -9.893},
				{x: 5.656, y: -10.790},
				{x: 4.848, y: -10.719},
				{x: 1.957, y: -8.600},
				{x: 0.646, y: -8.672},
				{x: -0.700, y: -8.672},
				{x: -1.400, y: -8.061},
				{x: -4.453, y: -10.719},
				{x: -5.476, y: -10.072},
				{x: -6.212, y: -7.379},
				{x: -7.882, y: -9.641},
				{x: -8.420, y: -8.959},
				{x: -7.469, y: -5.656},
				{x: -6.158, y: -4.848},
				{x: -6.679, y: -3.393},
				{x: -5.925, y: -0.700},
				{x: -5.422, y: -0.036},
				{x: -7.164, y: -0.072},
				{x: -10.144, y: 5.656},
				{x: -10.090, y: 6.894},
				{x: -9.516, y: 7.397},
				{x: -7.577, y: 6.338},
				{x: -7.433, y: 4.058},
				{x: -6.302, y: 2.406},
				{x: -4.076, y: 2.442},
				{x: -3.357, y: 3.519},
				{x: -5.709, y: 6.320},
				{x: -7.630, y: 10.144},
				{x: -7.630, y: 11.042},
				{x: -7.235, y: 11.365},
				{x: -6.481, y: 11.311},
				{x: -3.034, y: 5.027},
				{x: -2.514, y: 5.063},
				{x: -2.980, y: 5.835},
				{x: -3.268, y: 6.212},
				{x: -3.160, y: 7.200},
				{x: -2.478, y: 7.684},
				{x: -1.867, y: 8.241},
			], color: "b", line: 0, score: "X"},
		],

		rings: [
					{diam: 46.7, color: "bl", line: 0.44, score: 10},
					{diam: 65.9, color: "w", line: 0.44, score: 9},
					{diam: 85.1, color: "w", line: 0.44, score: 8},
					{diam: 104.3, color: "w", line: 0.44, score: 7},
					{diam: 123.5, color: "w", line: 0.44, score: 6},
					{diam: 142.7, color: "w", line: 0.44, score: 5},
					{diam: 161.9, color: "w", line: 0.44, score: 4},
					{diam: 181.1, color: "w", line: 0.44, score: 3},
					{diam: 200.3, color: "w", line: 0.44, score: 2},
					{diam: 219.5, color: "w", line: 1.76, score: 1},
		],


		text: [
		].concat(text_rings({x: 20, y: 0}, {x: 9.45, y: 0}, 10, 1, {size: 5, color: "gl"}))
		.concat(text_rings({x: -20, y: 0}, {x: -9.45, y: 0}, 10, 1, {size: 5, color: "gl"}))

	};

	targetfaces["LoadDev"] = {
		name: "Load Development",
		shortname: "Load Development",
		force_colors: true,
		dist: 100,
		dist_unit: "y",
		board: {w: 10/INCH, h: 7/INCH, line: 1},
		rings: [	{diam: (5/16)/INCH, color: "w", line: (1/16)/INCH, x: -3.3/INCH, y: 1.1/INCH},
					{diam: (5/16)/INCH, color: "w", line: (1/16)/INCH, x: -1.1/INCH, y: 1.1/INCH},
					{diam: (5/16)/INCH, color: "w", line: (1/16)/INCH, x: 1.1/INCH, y: 1.1/INCH},
					{diam: (5/16)/INCH, color: "w", line: (1/16)/INCH, x: 3.3/INCH, y: 1.1/INCH},
					{diam: (5/16)/INCH, color: "w", line: (1/16)/INCH, x: -3.3/INCH, y: -2.2/INCH},
					{diam: (5/16)/INCH, color: "w", line: (1/16)/INCH, x: -1.1/INCH, y: -2.2/INCH},
					{diam: (5/16)/INCH, color: "w", line: (1/16)/INCH, x: 1.1/INCH, y: -2.2/INCH},
					{diam: (5/16)/INCH, color: "w", line: (1/16)/INCH, x: 3.3/INCH, y: -2.2/INCH}
		],
		poly: [
				    {points: [{x: -3.3/INCH, y: 1.1/INCH}, {x: -3.3/INCH, y: 2.75/INCH}], color: "bl", line: 0.03/INCH},
				    {points: [{x: -1.1/INCH, y: 1.1/INCH}, {x: -1.1/INCH, y: 2.75/INCH}], color: "bl", line: 0.03/INCH},
				    {points: [{x: 1.1/INCH, y: 1.1/INCH}, {x: 1.1/INCH, y: 2.75/INCH}], color: "bl", line: 0.03/INCH},
				    {points: [{x: 3.3/INCH, y: 1.1/INCH}, {x: 3.3/INCH, y: 2.75/INCH}], color: "bl", line: 0.03/INCH},

				    {points: [{x: (-3.3-0.55)/INCH, y: 2.2/INCH}, {x: (-3.3+0.55)/INCH, y: 2.2/INCH}], color: "bl", line: 0.03/INCH},
				    {points: [{x: (-1.1-0.55)/INCH, y: 2.2/INCH}, {x: (-1.1+0.55)/INCH, y: 2.2/INCH}], color: "bl", line: 0.03/INCH},
				    {points: [{x: (1.1-0.55)/INCH, y: 2.2/INCH}, {x: (1.1+0.55)/INCH, y: 2.2/INCH}], color: "bl", line: 0.03/INCH},
				    {points: [{x: (3.3-0.55)/INCH, y: 2.2/INCH}, {x: (3.3+0.55)/INCH, y: 2.2/INCH}], color: "bl", line: 0.03/INCH},

				    {points: [{x: -1.1/INCH, y: -2.2/INCH}, {x: -1.1/INCH, y: -0.55/INCH}], color: "bl", line: 0.03/INCH},
				    {points: [{x: 1.1/INCH, y: -2.2/INCH}, {x: 1.1/INCH, y: -0.55/INCH}], color: "bl", line: 0.03/INCH},
				    {points: [{x: 3.3/INCH, y: -2.2/INCH}, {x: 3.3/INCH, y: -0.55/INCH}], color: "bl", line: 0.03/INCH},
				    {points: [{x: -3.3/INCH, y: -2.2/INCH}, {x: -3.3/INCH, y: -0.55/INCH}], color: "bl", line: 0.03/INCH},

				    {points: [{x: (-3.3-0.55)/INCH, y: -1.1/INCH}, {x: (-3.3+0.55)/INCH, y: -1.1/INCH}], color: "bl", line: 0.03/INCH},
				    {points: [{x: (-1.1-0.55)/INCH, y: -1.1/INCH}, {x: (-1.1+0.55)/INCH, y: -1.1/INCH}], color: "bl", line: 0.03/INCH},
				    {points: [{x: (1.1-0.55)/INCH, y: -1.1/INCH}, {x: (1.1+0.55)/INCH, y: -1.1/INCH}], color: "bl", line: 0.03/INCH},
				    {points: [{x: (3.3-0.55)/INCH, y: -1.1/INCH}, {x: (3.3+0.55)/INCH, y: -1.1/INCH}], color: "bl", line: 0.03/INCH},

		],
		text: [
					{x: -3.3/INCH, y: 0.8/INCH, size: 0.3/INCH, color: "bl", text: "1"},
					{x: -1.1/INCH, y: 0.8/INCH, size: 0.3/INCH, color: "bl", text: "2"},
					{x: 1.1/INCH, y: 0.8/INCH, size: 0.3/INCH, color: "bl", text: "3"},
					{x: 3.3/INCH, y: 0.8/INCH, size: 0.3/INCH, color: "bl", text: "4"},
					{x: -3.3/INCH, y: -2.5/INCH, size: 0.3/INCH, color: "bl", text: "5"},
					{x: -1.1/INCH, y: -2.5/INCH, size: 0.3/INCH, color: "bl", text: "6"},
					{x: 1.1/INCH, y: -2.5/INCH, size: 0.3/INCH, color: "bl", text: "7"},
					{x: 3.3/INCH, y: -2.5/INCH, size: 0.3/INCH, color: "bl", text: "8"},
					{x: -3.8/INCH, y: -3.4/INCH, size: 0.15/INCH, color: "bl", text: "Download PDF at theshotmarker.com"},
		]
	};

	targetfaces["Diamonds1"] = {
		name: "Diamonds (100)",
		shortname: "Diamonds (100)",
		dist: 100,
		dist_unit: "y",
		force_colors: true,
		board: {w: 9.75/INCH, h: 7/INCH, line: 1},
		rings: [
					{diam: 0.25/INCH, color: "w", line: 0.5, x: -3/INCH, y: -2/INCH},
					{diam: 0.25/INCH, color: "w", line: 0.5, x: -1/INCH, y: -2/INCH},
					{diam: 0.25/INCH, color: "w", line: 0.5, x: 1/INCH, y: -2/INCH},
					{diam: 0.25/INCH, color: "w", line: 0.5, x: 3/INCH, y: -2/INCH},
					{diam: 0.25/INCH, color: "w", line: 0.5, x: -3/INCH, y: 0/INCH},
					{diam: 0.25/INCH, color: "w", line: 0.5, x: -1/INCH, y: 0/INCH},
					{diam: 0.25/INCH, color: "w", line: 0.5, x: 1/INCH, y: 0/INCH},
					{diam: 0.25/INCH, color: "w", line: 0.5, x: 3/INCH, y: 0/INCH},
					{diam: 0.25/INCH, color: "w", line: 0.5, x: -3/INCH, y: 2/INCH},
					{diam: 0.25/INCH, color: "w", line: 0.5, x: -1/INCH, y: 2/INCH},
					{diam: 0.25/INCH, color: "w", line: 0.5, x: 1/INCH, y: 2/INCH},
					{diam: 0.25/INCH, color: "w", line: 0.5, x: 3/INCH, y: 2/INCH},

		],
		poly: [

				    {points: [{x: (-3 - 0.375)/INCH, y: (-2 + 0)/INCH}, {x: (-3 + 0)/INCH, y: (-2 + 0.375)/INCH}, {x: (-3 + 0.375)/INCH, y: (-2 + 0)/INCH}, {x: (-3 + 0)/INCH, y: (-2 + -0.375)/INCH}], color: "g", line: 1},
				    {points: [{x: (-1 - 0.375)/INCH, y: (-2 + 0)/INCH}, {x: (-1 + 0)/INCH, y: (-2 + 0.375)/INCH}, {x: (-1 + 0.375)/INCH, y: (-2 + 0)/INCH}, {x: (-1 + 0)/INCH, y: (-2 + -0.375)/INCH}], color: "g", line: 1},
				    {points: [{x: (1 - 0.375)/INCH, y: (-2 + 0)/INCH}, {x: (1 + 0)/INCH, y: (-2 + 0.375)/INCH}, {x: (1 + 0.375)/INCH, y: (-2 + 0)/INCH}, {x: (1 + 0)/INCH, y: (-2 + -0.375)/INCH}], color: "g", line: 1},
				    {points: [{x: (3 - 0.375)/INCH, y: (-2 + 0)/INCH}, {x: (3 + 0)/INCH, y: (-2 + 0.375)/INCH}, {x: (3 + 0.375)/INCH, y: (-2 + 0)/INCH}, {x: (3 + 0)/INCH, y: (-2 + -0.375)/INCH}], color: "g", line: 1},

				    {points: [{x: (-3 - 0.375)/INCH, y: (0 + 0)/INCH}, {x: (-3 + 0)/INCH, y: (0 + 0.375)/INCH}, {x: (-3 + 0.375)/INCH, y: (0 + 0)/INCH}, {x: (-3 + 0)/INCH, y: (0 + -0.375)/INCH}], color: "g", line: 1},
				    {points: [{x: (-1 - 0.375)/INCH, y: (0 + 0)/INCH}, {x: (-1 + 0)/INCH, y: (0 + 0.375)/INCH}, {x: (-1 + 0.375)/INCH, y: (0 + 0)/INCH}, {x: (-1 + 0)/INCH, y: (0 + -0.375)/INCH}], color: "g", line: 1},
				    {points: [{x: (1 - 0.375)/INCH, y: (0 + 0)/INCH}, {x: (1 + 0)/INCH, y: (0 + 0.375)/INCH}, {x: (1 + 0.375)/INCH, y: (0 + 0)/INCH}, {x: (1 + 0)/INCH, y: (0 + -0.375)/INCH}], color: "g", line: 1},
				    {points: [{x: (3 - 0.375)/INCH, y: (0 + 0)/INCH}, {x: (3 + 0)/INCH, y: (0 + 0.375)/INCH}, {x: (3 + 0.375)/INCH, y: (0 + 0)/INCH}, {x: (3 + 0)/INCH, y: (0 + -0.375)/INCH}], color: "g", line: 1},

				    {points: [{x: (-3 - 0.375)/INCH, y: (2 + 0)/INCH}, {x: (-3 + 0)/INCH, y: (2 + 0.375)/INCH}, {x: (-3 + 0.375)/INCH, y: (2 + 0)/INCH}, {x: (-3 + 0)/INCH, y: (2 + -0.375)/INCH}], color: "g", line: 1},
				    {points: [{x: (-1 - 0.375)/INCH, y: (2 + 0)/INCH}, {x: (-1 + 0)/INCH, y: (2 + 0.375)/INCH}, {x: (-1 + 0.375)/INCH, y: (2 + 0)/INCH}, {x: (-1 + 0)/INCH, y: (2 + -0.375)/INCH}], color: "g", line: 1},
				    {points: [{x: (1 - 0.375)/INCH, y: (2 + 0)/INCH}, {x: (1 + 0)/INCH, y: (2 + 0.375)/INCH}, {x: (1 + 0.375)/INCH, y: (2 + 0)/INCH}, {x: (1 + 0)/INCH, y: (2 + -0.375)/INCH}], color: "g", line: 1},
				    {points: [{x: (3 - 0.375)/INCH, y: (2 + 0)/INCH}, {x: (3 + 0)/INCH, y: (2 + 0.375)/INCH}, {x: (3 + 0.375)/INCH, y: (2 + 0)/INCH}, {x: (3 + 0)/INCH, y: (2 + -0.375)/INCH}], color: "g", line: 1},

					// grid
					{points: [{x: -4/INCH, y: -2/INCH}, {x: 4/INCH, y: -2/INCH}], color: "gl", line: 0.5},
					{points: [{x: -4/INCH, y: 0/INCH}, {x: 4/INCH, y: 0/INCH}], color: "gl", line: 0.5},
					{points: [{x: -4/INCH, y: 2/INCH}, {x: 4/INCH, y: 2/INCH}], color: "gl", line: 0.5},

					{points: [{x: -3/INCH, y: -3/INCH}, {x: -3/INCH, y: 3/INCH}], color: "gl", line: 0.5},
					{points: [{x: -1/INCH, y: -3/INCH}, {x: -1/INCH, y: 3/INCH}], color: "gl", line: 0.5},
					{points: [{x: 1/INCH, y: -3/INCH}, {x: 1/INCH, y: 3/INCH}], color: "gl", line: 0.5},
					{points: [{x: 3/INCH, y: -3/INCH}, {x: 3/INCH, y: 3/INCH}], color: "gl", line: 0.5},

		],

	};

	targetfaces["Diamonds2"] = {
		name: "Diamonds (200)",
		shortname: "Diamonds (200)",
		dist: 200,
		dist_unit: "y",
		force_colors: true,
		board: {w: 14/INCH, h: 9.75/INCH, line: 1},
		rings: [
					{diam: 0.5/INCH, color: "w", line: 1, x: -5.25/INCH, y: -3/INCH},
					{diam: 0.5/INCH, color: "w", line: 1, x: -1.75/INCH, y: -3/INCH},
					{diam: 0.5/INCH, color: "w", line: 1, x: 1.75/INCH, y: -3/INCH},
					{diam: 0.5/INCH, color: "w", line: 1, x: 5.25/INCH, y: -3/INCH},
					{diam: 0.5/INCH, color: "w", line: 1, x: -5.25/INCH, y: 0/INCH},
					{diam: 0.5/INCH, color: "w", line: 1, x: -1.75/INCH, y: 0/INCH},
					{diam: 0.5/INCH, color: "w", line: 1, x: 1.75/INCH, y: 0/INCH},
					{diam: 0.5/INCH, color: "w", line: 1, x: 5.25/INCH, y: 0/INCH},
					{diam: 0.5/INCH, color: "w", line: 1, x: -5.25/INCH, y: 3/INCH},
					{diam: 0.5/INCH, color: "w", line: 1, x: -1.75/INCH, y: 3/INCH},
					{diam: 0.5/INCH, color: "w", line: 1, x: 1.75/INCH, y: 3/INCH},
					{diam: 0.5/INCH, color: "w", line: 1, x: 5.25/INCH, y: 3/INCH},

		],
		poly: [

				    {points: [{x: (-5.25 - 0.625)/INCH, y: (-3 + 0)/INCH}, {x: (-5.25 + 0)/INCH, y: (-3 + 0.625)/INCH}, {x: (-5.25 + 0.625)/INCH, y: (-3 + 0)/INCH}, {x: (-5.25 + 0)/INCH, y: (-3 + -0.625)/INCH}], color: "g", line: 1},
				    {points: [{x: (-1.75 - 0.625)/INCH, y: (-3 + 0)/INCH}, {x: (-1.75 + 0)/INCH, y: (-3 + 0.625)/INCH}, {x: (-1.75 + 0.625)/INCH, y: (-3 + 0)/INCH}, {x: (-1.75 + 0)/INCH, y: (-3 + -0.625)/INCH}], color: "g", line: 1},
				    {points: [{x: (1.75 - 0.625)/INCH, y: (-3 + 0)/INCH}, {x: (1.75 + 0)/INCH, y: (-3 + 0.625)/INCH}, {x: (1.75 + 0.625)/INCH, y: (-3 + 0)/INCH}, {x: (1.75 + 0)/INCH, y: (-3 + -0.625)/INCH}], color: "g", line: 1},
				    {points: [{x: (5.25 - 0.625)/INCH, y: (-3 + 0)/INCH}, {x: (5.25 + 0)/INCH, y: (-3 + 0.625)/INCH}, {x: (5.25 + 0.625)/INCH, y: (-3 + 0)/INCH}, {x: (5.25 + 0)/INCH, y: (-3 + -0.625)/INCH}], color: "g", line: 1},

				    {points: [{x: (-5.25 - 0.625)/INCH, y: (0 + 0)/INCH}, {x: (-5.25 + 0)/INCH, y: (0 + 0.625)/INCH}, {x: (-5.25 + 0.625)/INCH, y: (0 + 0)/INCH}, {x: (-5.25 + 0)/INCH, y: (0 + -0.625)/INCH}], color: "g", line: 1},
				    {points: [{x: (-1.75 - 0.625)/INCH, y: (0 + 0)/INCH}, {x: (-1.75 + 0)/INCH, y: (0 + 0.625)/INCH}, {x: (-1.75 + 0.625)/INCH, y: (0 + 0)/INCH}, {x: (-1.75 + 0)/INCH, y: (0 + -0.625)/INCH}], color: "g", line: 1},
				    {points: [{x: (1.75 - 0.625)/INCH, y: (0 + 0)/INCH}, {x: (1.75 + 0)/INCH, y: (0 + 0.625)/INCH}, {x: (1.75 + 0.625)/INCH, y: (0 + 0)/INCH}, {x: (1.75 + 0)/INCH, y: (0 + -0.625)/INCH}], color: "g", line: 1},
				    {points: [{x: (5.25 - 0.625)/INCH, y: (0 + 0)/INCH}, {x: (5.25 + 0)/INCH, y: (0 + 0.625)/INCH}, {x: (5.25 + 0.625)/INCH, y: (0 + 0)/INCH}, {x: (5.25 + 0)/INCH, y: (0 + -0.625)/INCH}], color: "g", line: 1},

				    {points: [{x: (-5.25 - 0.625)/INCH, y: (3 + 0)/INCH}, {x: (-5.25 + 0)/INCH, y: (3 + 0.625)/INCH}, {x: (-5.25 + 0.625)/INCH, y: (3 + 0)/INCH}, {x: (-5.25 + 0)/INCH, y: (3 + -0.625)/INCH}], color: "g", line: 1},
				    {points: [{x: (-1.75 - 0.625)/INCH, y: (3 + 0)/INCH}, {x: (-1.75 + 0)/INCH, y: (3 + 0.625)/INCH}, {x: (-1.75 + 0.625)/INCH, y: (3 + 0)/INCH}, {x: (-1.75 + 0)/INCH, y: (3 + -0.625)/INCH}], color: "g", line: 1},
				    {points: [{x: (1.75 - 0.625)/INCH, y: (3 + 0)/INCH}, {x: (1.75 + 0)/INCH, y: (3 + 0.625)/INCH}, {x: (1.75 + 0.625)/INCH, y: (3 + 0)/INCH}, {x: (1.75 + 0)/INCH, y: (3 + -0.625)/INCH}], color: "g", line: 1},
				    {points: [{x: (5.25 - 0.625)/INCH, y: (3 + 0)/INCH}, {x: (5.25 + 0)/INCH, y: (3 + 0.625)/INCH}, {x: (5.25 + 0.625)/INCH, y: (3 + 0)/INCH}, {x: (5.25 + 0)/INCH, y: (3 + -0.625)/INCH}], color: "g", line: 1},

					// grid
					{points: [{x: -7/INCH, y: -3/INCH}, {x: 7/INCH, y: -3/INCH}], color: "gl", line: 0.5},
					{points: [{x: -7/INCH, y: 0/INCH}, {x: 7/INCH, y: 0/INCH}], color: "gl", line: 0.5},
					{points: [{x: -7/INCH, y: 3/INCH}, {x: 7/INCH, y: 3/INCH}], color: "gl", line: 0.5},

					{points: [{x: -5.25/INCH, y: -5/INCH}, {x: -5.25/INCH, y: 5/INCH}], color: "gl", line: 0.5},
					{points: [{x: -1.75/INCH, y: -5/INCH}, {x: -1.75/INCH, y: 5/INCH}], color: "gl", line: 0.5},
					{points: [{x: 1.75/INCH, y: -5/INCH}, {x: 1.75/INCH, y: 5/INCH}], color: "gl", line: 0.5},
					{points: [{x: 5.25/INCH, y: -5/INCH}, {x: 5.25/INCH, y: 5/INCH}], color: "gl", line: 0.5},

					{points: [{x: 0/INCH, y: -5/INCH}, {x: 0/INCH, y: -4/INCH}], color: "bl", line: 0.5},
					{points: [{x: 0/INCH, y: 5/INCH}, {x: 0/INCH, y: 4/INCH}], color: "bl", line: 0.5},

		],

	};

	targetfaces["Dot14"] = {
		name: "1/4\" Dot",
		shortname: "1/4\" Dot",
		dist: 100,
		dist_unit: "y",
		board: {w: 24/INCH, h: 24/INCH, line: 2},
		rings: [	{diam: (1/4)/INCH, color: "b", line: 0}
		]
	};

	targetfaces["Dot1"] = {
		name: "1\" Dot",
		shortname: "1\" Dot",
		dist: 300,
		dist_unit: "y",
		board: {w: 24/INCH, h: 24/INCH, line: 2},
		rings: [	{diam: 1/INCH, color: "b", line: 0}
		]
	};

	targetfaces["Dot2"] = {
		name: "2\" Dot",
		shortname: "2\" Dot",
		dist: 600,
		dist_unit: "y",
		board: {w: 36/INCH, h: 36/INCH, line: 2},
		rings: [	{diam: 2/INCH, color: "b", line: 0}
		]
	};

	targetfaces["Dot3"] = {
		name: "3\" Dot",
		shortname: "3\" Dot",
		dist: 1000,
		dist_unit: "y",
		board: {w: 48/INCH, h: 48/INCH, line: 2},
		rings: [	{diam: 3/INCH, color: "b", line: 0}
		]
	};

	targetfaces["Rings1"] = {
		name: "1\" Rings",
		shortname: "1\" Rings",
		dist: 100,
		dist_unit: "y",
		score: [10, "X"],
		board: {w: 24/INCH, h: 24/INCH, line: 2},
		rings: [	{diam: 1/INCH, color: "b", line: 0, score: "X"},
					{diam: 2/INCH, color: "w", line: 1, score: 10},
					{diam: 4/INCH, color: "w", line: 1, score: 9},
					{diam: 6/INCH, color: "w", line: 1, score: 8},
					{diam: 8/INCH, color: "w", line: 1, score: 7}
		],
	};

	targetfaces["Rings2"] = {
		name: "2\" Rings",
		shortname: "2\" Rings",
		dist: 300,
		dist_unit: "y",
		score: [10, "X"],
		board: {w: 36/INCH, h: 36/INCH, line: 4},
		rings: [	{diam: 2/INCH, color: "b", line: 0, score: "X"},
					{diam: 4/INCH, color: "w", line: 2, score: 10},
					{diam: 8/INCH, color: "w", line: 2, score: 9},
					{diam: 12/INCH, color: "w", line: 2, score: 8},
					{diam: 16/INCH, color: "w", line: 2, score: 7}
		],
	};

	targetfaces["Rings3"] = {
		name: "3\" Rings",
		shortname: "3\" Rings",
		dist: 600,
		dist_unit: "y",
		score: [10, "X"],
		board: {w: 48/INCH, h: 48/INCH, line: 6},
		rings: [	{diam: 3/INCH, color: "b", line: 0, score: "X"},
					{diam: 6/INCH, color: "w", line: 3, score: 10},
					{diam: 12/INCH, color: "w", line: 3, score: 9},
					{diam: 18/INCH, color: "w", line: 3, score: 8},
					{diam: 24/INCH, color: "w", line: 3, score: 7}
		],
	};
	
	targetfaces["Calibration"] = {
		name: "Calibration Target",
		shortname: "Calibration",
		dist: 100,
		dist_unit: "y",
		board: {w: 252, h: 183, line: 3},
		
		poly: [

			{points: [{x: -120, y: -80}, {x: 120, y: -80}], color: "gl", line: 1},
			{points: [{x: -120, y: -40}, {x: 120, y: -40}], color: "gl", line: 1},
			{points: [{x: -120, y: 0}, {x: 120, y: 0}], color: "gl", line: 1},
			{points: [{x: -120, y: 40}, {x: 120, y: 40}], color: "gl", line: 1},
			{points: [{x: -120, y: 80}, {x: 120, y: 80}], color: "gl", line: 1},

			{points: [{x: -120, y: -80}, {x: -120, y: 80}], color: "gl", line: 1},
			{points: [{x: -80, y: -80}, {x: -80, y: 80}], color: "gl", line: 1},
			{points: [{x: -40, y: -80}, {x: -40, y: 80}], color: "gl", line: 1},
			{points: [{x: 0, y: -80}, {x: 0, y: 80}], color: "gl", line: 1},
			{points: [{x: 40, y: -80}, {x: 40, y: 80}], color: "gl", line: 1},
			{points: [{x: 80, y: -80}, {x: 80, y: 80}], color: "gl", line: 1},
			{points: [{x: 120, y: -80}, {x: 120, y: 80}], color: "gl", line: 1},

		]

	};
	
	targetfaces["JRB"] = {
		name: "Johnny's Reloading Bench",
		shortname: "JRB",
		dist: 100,
		dist_unit: "y",
		board: {w: 22/INCH, h: 14/INCH, line: 3},
		force_colors: true,
		
		rings: [
		
			{x: -7/INCH, y: -2.25/INCH, diam: 1/INCH, color: "g", line: 1},
			{x: -7/INCH, y: 2.25/INCH, diam: 1/INCH, color: "g", line: 1},
			{x: -3.5/INCH, y: -2.25/INCH, diam: 1/INCH, color: "g", line: 1},
			{x: -3.5/INCH, y: 2.25/INCH, diam: 1/INCH, color: "g", line: 1},
			{x: 0, y: -2.25/INCH, diam: 1/INCH, color: "g", line: 1},
			{x: 0, y: 2.25/INCH, diam: 1/INCH, color: "g", line: 1},
			{x: 3.5/INCH, y: -2.25/INCH, diam: 1/INCH, color: "g", line: 1},
			{x: 3.5/INCH, y: 2.25/INCH, diam: 1/INCH, color: "g", line: 1},
			{x: 7/INCH, y: -2.25/INCH, diam: 1/INCH, color: "g", line: 1},
			{x: 7/INCH, y: 2.25/INCH, diam: 1/INCH, color: "g", line: 1},

		],
		
		poly: [

			{points: [{x: -7/INCH, y: -7/INCH}, {x: -7/INCH, y: 7/INCH}], color: "bl", line: 0.075/INCH},
			{points: [{x: -3.5/INCH, y: -7/INCH}, {x: -3.5/INCH, y: 7/INCH}], color: "bl", line: 0.075/INCH},
			{points: [{x: 0, y: -7/INCH}, {x: 0, y: 7/INCH}], color: "bl", line: 0.075/INCH},
			{points: [{x: 3.5/INCH, y: -7/INCH}, {x: 3.5/INCH, y: 7/INCH}], color: "bl", line: 0.075/INCH},
			{points: [{x: 7/INCH, y: -7/INCH}, {x: 7/INCH, y: 7/INCH}], color: "bl", line: 0.075/INCH},

			{points: [{x: -11/INCH, y: -2.25/INCH}, {x: 11/INCH, y: -2.25/INCH}], color: "bl", line: 0.075/INCH},
			{points: [{x: -11/INCH, y: 2.25/INCH}, {x: 11/INCH, y: 2.25/INCH}], color: "bl", line: 0.075/INCH},

		],
		
		poly_top: [

			{points: [{x: -7/INCH, y: -7/INCH}, {x: -7/INCH, y: 7/INCH}], color: "bl", line: 0.7},
			{points: [{x: -3.5/INCH, y: -7/INCH}, {x: -3.5/INCH, y: 7/INCH}], color: "bl", line: 0.7},
			{points: [{x: 0, y: -7/INCH}, {x: 0, y: 7/INCH}], color: "bl", line: 0.7},
			{points: [{x: 3.5/INCH, y: -7/INCH}, {x: 3.5/INCH, y: 7/INCH}], color: "bl", line: 0.7},
			{points: [{x: 7/INCH, y: -7/INCH}, {x: 7/INCH, y: 7/INCH}], color: "bl", line: 0.7},

			{points: [{x: -11/INCH, y: -2.25/INCH}, {x: 11/INCH, y: -2.25/INCH}], color: "bl", line: 0.7},
			{points: [{x: -11/INCH, y: 2.25/INCH}, {x: 11/INCH, y: 2.25/INCH}], color: "bl", line: 0.7},
			
		    {points: [{x: (0 - 0.125)/INCH, y: (-2.25 + 0)/INCH}, {x: (0 + 0)/INCH, y: (-2.25 + 0.125)/INCH}, {x: (0 + 0.125)/INCH, y: (-2.25 + 0)/INCH}, {x: (-0 + 0)/INCH, y: (-2.25 + -0.125)/INCH}], color: "b", line: 0},
		    {points: [{x: (-3.5 - 0.125)/INCH, y: (-2.25 + 0)/INCH}, {x: (-3.5 + 0)/INCH, y: (-2.25 + 0.125)/INCH}, {x: (-3.5 + 0.125)/INCH, y: (-2.25 + 0)/INCH}, {x: (-3.5 + 0)/INCH, y: (-2.25 + -0.125)/INCH}], color: "b", line: 0},
		    {points: [{x: (-7 - 0.125)/INCH, y: (-2.25 + 0)/INCH}, {x: (-7 + 0)/INCH, y: (-2.25 + 0.125)/INCH}, {x: (-7 + 0.125)/INCH, y: (-2.25 + 0)/INCH}, {x: (-7 + 0)/INCH, y: (-2.25 + -0.125)/INCH}], color: "b", line: 0},
		    {points: [{x: (3.5 - 0.125)/INCH, y: (-2.25 + 0)/INCH}, {x: (3.5 + 0)/INCH, y: (-2.25 + 0.125)/INCH}, {x: (3.5 + 0.125)/INCH, y: (-2.25 + 0)/INCH}, {x: (3.5 + 0)/INCH, y: (-2.25 + -0.125)/INCH}], color: "b", line: 0},
		    {points: [{x: (7 - 0.125)/INCH, y: (-2.25 + 0)/INCH}, {x: (7 + 0)/INCH, y: (-2.25 + 0.125)/INCH}, {x: (7 + 0.125)/INCH, y: (-2.25 + 0)/INCH}, {x: (7 + 0)/INCH, y: (-2.25 + -0.125)/INCH}], color: "b", line: 0},

		    {points: [{x: (0 - 0.125)/INCH, y: (2.25 + 0)/INCH}, {x: (0 + 0)/INCH, y: (2.25 + 0.125)/INCH}, {x: (0 + 0.125)/INCH, y: (2.25 + 0)/INCH}, {x: (-0 + 0)/INCH, y: (2.25 + -0.125)/INCH}], color: "b", line: 0},
		    {points: [{x: (-3.5 - 0.125)/INCH, y: (2.25 + 0)/INCH}, {x: (-3.5 + 0)/INCH, y: (2.25 + 0.125)/INCH}, {x: (-3.5 + 0.125)/INCH, y: (2.25 + 0)/INCH}, {x: (-3.5 + 0)/INCH, y: (2.25 + -0.125)/INCH}], color: "b", line: 0},
		    {points: [{x: (-7 - 0.125)/INCH, y: (2.25 + 0)/INCH}, {x: (-7 + 0)/INCH, y: (2.25 + 0.125)/INCH}, {x: (-7 + 0.125)/INCH, y: (2.25 + 0)/INCH}, {x: (-7 + 0)/INCH, y: (2.25 + -0.125)/INCH}], color: "b", line: 0},
		    {points: [{x: (3.5 - 0.125)/INCH, y: (2.25 + 0)/INCH}, {x: (3.5 + 0)/INCH, y: (2.25 + 0.125)/INCH}, {x: (3.5 + 0.125)/INCH, y: (2.25 + 0)/INCH}, {x: (3.5 + 0)/INCH, y: (2.25 + -0.125)/INCH}], color: "b", line: 0},
		    {points: [{x: (7 - 0.125)/INCH, y: (2.25 + 0)/INCH}, {x: (7 + 0)/INCH, y: (2.25 + 0.125)/INCH}, {x: (7 + 0.125)/INCH, y: (2.25 + 0)/INCH}, {x: (7 + 0)/INCH, y: (2.25 + -0.125)/INCH}], color: "b", line: 0},
		    

		]

	};

	targetfaces["Champion45726"] = {
		name: "Champion 45726",
		shortname: "Champion 45726",
		dist: 100,
		dist_unit: "y",
		score: [10],
		board: {w: 14/INCH, h: 18/INCH, line: 2},
		force_colors: true,
		rings: [

					{x: -4/INCH, y: -4/INCH, diam: 0.7/INCH, color: "b", line: 0, score: 10},
					{x: -4/INCH, y: -4/INCH, diam: 1.4/INCH, color: "bl", line: 0, score: 9},
					{x: -4/INCH, y: -4/INCH, diam: 2.1/INCH, color: "bl", line: 0.35/INCH, score: 8},
					{x: -4/INCH, y: -4/INCH, diam: 2.8/INCH, color: "bl", line: 0, score: 7},
					{x: -4/INCH, y: -4/INCH, diam: 3.35/INCH, color: "bl", line: 0.275/INCH, score: 6},

					{x: -4/INCH, y: 4/INCH, diam: 0.7/INCH, color: "b", line: 0, score: 10},
					{x: -4/INCH, y: 4/INCH, diam: 1.4/INCH, color: "bl", line: 0, score: 9},
					{x: -4/INCH, y: 4/INCH, diam: 2.1/INCH, color: "bl", line: 0.35/INCH, score: 8},
					{x: -4/INCH, y: 4/INCH, diam: 2.8/INCH, color: "bl", line: 0, score: 7},
					{x: -4/INCH, y: 4/INCH, diam: 3.35/INCH, color: "bl", line: 0.275/INCH, score: 6},

					{x: 4/INCH, y: -4/INCH, diam: 0.7/INCH, color: "b", line: 0, score: 10},
					{x: 4/INCH, y: -4/INCH, diam: 1.4/INCH, color: "bl", line: 0, score: 9},
					{x: 4/INCH, y: -4/INCH, diam: 2.1/INCH, color: "bl", line: 0.35/INCH, score: 8},
					{x: 4/INCH, y: -4/INCH, diam: 2.8/INCH, color: "bl", line: 0, score: 7},
					{x: 4/INCH, y: -4/INCH, diam: 3.35/INCH, color: "bl", line: 0.275/INCH, score: 6},

					{x: 4/INCH, y: 4/INCH, diam: 0.7/INCH, color: "b", line: 0, score: 10},
					{x: 4/INCH, y: 4/INCH, diam: 1.4/INCH, color: "bl", line: 0, score: 9},
					{x: 4/INCH, y: 4/INCH, diam: 2.1/INCH, color: "bl", line: 0.35/INCH, score: 8},
					{x: 4/INCH, y: 4/INCH, diam: 2.8/INCH, color: "bl", line: 0, score: 7},
					{x: 4/INCH, y: 4/INCH, diam: 3.35/INCH, color: "bl", line: 0.275/INCH, score: 6},

					{diam: 1/INCH, color: "b", line: 0, score: 10},
					{diam: 2/INCH, color: "bl", line: 0.25/INCH, score: 10},
					{diam: 4/INCH, color: "bl", line: 0.25/INCH, score: 9},
					{diam: 6/INCH, color: "bl", line: 0.25/INCH, score: 8},
					{diam: 8/INCH, color: "bl", line: 0.05/INCH, score: 7},
					{diam: 10/INCH, color: "bl", line: 0.05/INCH, score: 6},
					{diam: 12/INCH, color: "bl", line: 0.05/INCH, score: 5},
		],
		poly: [

			// grid
			{points: [{x: -6/INCH, y: -6/INCH}, {x: 6/INCH, y: -6/INCH}], color: "gl", line: 1},
			{points: [{x: -6/INCH, y: -5/INCH}, {x: 6/INCH, y: -5/INCH}], color: "gl", line: 1},
			{points: [{x: -6/INCH, y: -4/INCH}, {x: 6/INCH, y: -4/INCH}], color: "bl", line: 1},
			{points: [{x: -6/INCH, y: -3/INCH}, {x: 6/INCH, y: -3/INCH}], color: "gl", line: 1},
			{points: [{x: -6/INCH, y: -2/INCH}, {x: 6/INCH, y: -2/INCH}], color: "gl", line: 1},
			{points: [{x: -6/INCH, y: -1/INCH}, {x: 6/INCH, y: -1/INCH}], color: "gl", line: 1},
			{points: [{x: -6/INCH, y: 0/INCH}, {x: 6/INCH, y: 0/INCH}], color: "gl", line: 1},
			{points: [{x: -6/INCH, y: 1/INCH}, {x: 6/INCH, y: 1/INCH}], color: "gl", line: 1},
			{points: [{x: -6/INCH, y: 2/INCH}, {x: 6/INCH, y: 2/INCH}], color: "gl", line: 1},
			{points: [{x: -6/INCH, y: 3/INCH}, {x: 6/INCH, y: 3/INCH}], color: "gl", line: 1},
			{points: [{x: -6/INCH, y: 4/INCH}, {x: 6/INCH, y: 4/INCH}], color: "bl", line: 1},
			{points: [{x: -6/INCH, y: 5/INCH}, {x: 6/INCH, y: 5/INCH}], color: "gl", line: 1},
			{points: [{x: -6/INCH, y: 6/INCH}, {x: 6/INCH, y: 6/INCH}], color: "gl", line: 1},

			{points: [{x: -6/INCH, y: -6/INCH}, {x: -6/INCH, y: 6/INCH}], color: "gl", line: 1},
			{points: [{x: -5/INCH, y: -6/INCH}, {x: -5/INCH, y: 6/INCH}], color: "gl", line: 1},
			{points: [{x: -4/INCH, y: -6/INCH}, {x: -4/INCH, y: 6/INCH}], color: "bl", line: 1},
			{points: [{x: -3/INCH, y: -6/INCH}, {x: -3/INCH, y: 6/INCH}], color: "gl", line: 1},
			{points: [{x: -2/INCH, y: -6/INCH}, {x: -2/INCH, y: 6/INCH}], color: "gl", line: 1},
			{points: [{x: -1/INCH, y: -6/INCH}, {x: -1/INCH, y: 6/INCH}], color: "gl", line: 1},
			{points: [{x: 0/INCH, y: -6/INCH}, {x: 0/INCH, y: 6/INCH}], color: "gl", line: 1},
			{points: [{x: 1/INCH, y: -6/INCH}, {x: 1/INCH, y: 6/INCH}], color: "gl", line: 1},
			{points: [{x: 2/INCH, y: -6/INCH}, {x: 2/INCH, y: 6/INCH}], color: "gl", line: 1},
			{points: [{x: 3/INCH, y: -6/INCH}, {x: 3/INCH, y: 6/INCH}], color: "gl", line: 1},
			{points: [{x: 4/INCH, y: -6/INCH}, {x: 4/INCH, y: 6/INCH}], color: "bl", line: 1},
			{points: [{x: 5/INCH, y: -6/INCH}, {x: 5/INCH, y: 6/INCH}], color: "gl", line: 1},
			{points: [{x: 6/INCH, y: -6/INCH}, {x: 6/INCH, y: 6/INCH}], color: "gl", line: 1},
		]
	};


	targetfaces["Champion46102"] = {
		name: "Champion 46102",
		shortname: "Champion 46102",
		dist: 100,
		dist_unit: "y",
		board: {w: 14/INCH, h: 14/INCH, line: 2},
		force_colors: true,
		rings: [

					{x: -4/INCH, y: -4/INCH, diam: 0.5/INCH, color: "b", line: 0},
					{x: -4/INCH, y: -4/INCH, diam: 1.2/INCH, color: "bl", line: 1.5},
					{x: -4/INCH, y: -4/INCH, diam: 3.35/INCH, color: "w", line: 1.5},

					{x: 4/INCH, y: -4/INCH, diam: 0.5/INCH, color: "b", line: 0},
					{x: 4/INCH, y: -4/INCH, diam: 1.2/INCH, color: "bl", line: 1.5},
					{x: 4/INCH, y: -4/INCH, diam: 3.35/INCH, color: "w", line: 1.5},

					{x: -4/INCH, y: 4/INCH, diam: 0.5/INCH, color: "b", line: 0},
					{x: -4/INCH, y: 4/INCH, diam: 1.2/INCH, color: "bl", line: 1.5},
					{x: -4/INCH, y: 4/INCH, diam: 3.35/INCH, color: "w", line: 1.5},

					{x: 4/INCH, y: 4/INCH, diam: 0.5/INCH, color: "b", line: 0},
					{x: 4/INCH, y: 4/INCH, diam: 1.2/INCH, color: "bl", line: 1.5},
					{x: 4/INCH, y: 4/INCH, diam: 3.35/INCH, color: "w", line: 1.5},

					{diam: 0.5/INCH, color: "bl", line: 1.5},
					{diam: 1.2/INCH, color: "bl", line: 1.5},
					{diam: 4/INCH, color: "bl", line: 1},
					{diam: 6/INCH, color: "bl", line: 1},
					{diam: 8/INCH, color: "bl", line: 1.5},
					{diam: 10/INCH, color: "bl", line: 1.5},
					{diam: 12/INCH, color: "bl", line: 1.5},
		],
		poly: [

			// box
			{points: polybox(0, 0, 1/INCH, 12/INCH), color: "g", line: 0},
			{points: polybox(0, 0, 12/INCH, 1/INCH), color: "g", line: 0},

			// grid
			{points: [{x: -6/INCH, y: -6/INCH}, {x: 6/INCH, y: -6/INCH}], color: "gl", line: 1},
			{points: [{x: -6/INCH, y: -5/INCH}, {x: 6/INCH, y: -5/INCH}], color: "gl", line: 1},
			{points: [{x: -6/INCH, y: -4/INCH}, {x: 6/INCH, y: -4/INCH}], color: "gl", line: 1},
			{points: [{x: -6/INCH, y: -3/INCH}, {x: 6/INCH, y: -3/INCH}], color: "gl", line: 1},
			{points: [{x: -6/INCH, y: -2/INCH}, {x: 6/INCH, y: -2/INCH}], color: "gl", line: 1},
			{points: [{x: -6/INCH, y: -1/INCH}, {x: 6/INCH, y: -1/INCH}], color: "gl", line: 1},
			{points: [{x: -6/INCH, y: 0/INCH}, {x: 6/INCH, y: 0/INCH}], color: "gl", line: 1},
			{points: [{x: -6/INCH, y: 1/INCH}, {x: 6/INCH, y: 1/INCH}], color: "gl", line: 1},
			{points: [{x: -6/INCH, y: 2/INCH}, {x: 6/INCH, y: 2/INCH}], color: "gl", line: 1},
			{points: [{x: -6/INCH, y: 3/INCH}, {x: 6/INCH, y: 3/INCH}], color: "gl", line: 1},
			{points: [{x: -6/INCH, y: 4/INCH}, {x: 6/INCH, y: 4/INCH}], color: "gl", line: 1},
			{points: [{x: -6/INCH, y: 5/INCH}, {x: 6/INCH, y: 5/INCH}], color: "gl", line: 1},
			{points: [{x: -6/INCH, y: 6/INCH}, {x: 6/INCH, y: 6/INCH}], color: "gl", line: 1},

			{points: [{x: -6/INCH, y: -6/INCH}, {x: -6/INCH, y: 6/INCH}], color: "gl", line: 1},
			{points: [{x: -5/INCH, y: -6/INCH}, {x: -5/INCH, y: 6/INCH}], color: "gl", line: 1},
			{points: [{x: -4/INCH, y: -6/INCH}, {x: -4/INCH, y: 6/INCH}], color: "gl", line: 1},
			{points: [{x: -3/INCH, y: -6/INCH}, {x: -3/INCH, y: 6/INCH}], color: "gl", line: 1},
			{points: [{x: -2/INCH, y: -6/INCH}, {x: -2/INCH, y: 6/INCH}], color: "gl", line: 1},
			{points: [{x: -1/INCH, y: -6/INCH}, {x: -1/INCH, y: 6/INCH}], color: "gl", line: 1},
			{points: [{x: 0/INCH, y: -6/INCH}, {x: 0/INCH, y: 6/INCH}], color: "gl", line: 1},
			{points: [{x: 1/INCH, y: -6/INCH}, {x: 1/INCH, y: 6/INCH}], color: "gl", line: 1},
			{points: [{x: 2/INCH, y: -6/INCH}, {x: 2/INCH, y: 6/INCH}], color: "gl", line: 1},
			{points: [{x: 3/INCH, y: -6/INCH}, {x: 3/INCH, y: 6/INCH}], color: "gl", line: 1},
			{points: [{x: 4/INCH, y: -6/INCH}, {x: 4/INCH, y: 6/INCH}], color: "gl", line: 1},
			{points: [{x: 5/INCH, y: -6/INCH}, {x: 5/INCH, y: 6/INCH}], color: "gl", line: 1},
			{points: [{x: 6/INCH, y: -6/INCH}, {x: 6/INCH, y: 6/INCH}], color: "gl", line: 1},
		]
	};


	targetfaces["Champion47388"] = {
		name: "Champion 47388",
		shortname: "Champion 47388",
		dist: 100,
		dist_unit: "y",
		board: {w: 16/INCH, h: 16/INCH, line: 2},
		rings: [
					{diam: 0.5/INCH, color: "w", line: 0},
					{diam: 0.25/INCH, color: "w", line: 0, x: -4.5/INCH, y: -4.5/INCH},
					{diam: 0.25/INCH, color: "w", line: 0, x: -4.5/INCH, y: 4.5/INCH},
					{diam: 0.25/INCH, color: "w", line: 0, x: 4.5/INCH, y: -4.5/INCH},
					{diam: 0.25/INCH, color: "w", line: 0, x: 4.5/INCH, y: 4.5/INCH},
		],
		poly: [

					// grid
					{points: [{x: -6/INCH, y: -6/INCH}, {x: 6/INCH, y: -6/INCH}], color: "bl", line: 1},
					{points: [{x: -6/INCH, y: -5/INCH}, {x: 6/INCH, y: -5/INCH}], color: "bl", line: 1},
					{points: [{x: -6/INCH, y: -4/INCH}, {x: 6/INCH, y: -4/INCH}], color: "bl", line: 1},
					{points: [{x: -6/INCH, y: -3/INCH}, {x: 6/INCH, y: -3/INCH}], color: "bl", line: 1},
					{points: [{x: -6/INCH, y: -2/INCH}, {x: 6/INCH, y: -2/INCH}], color: "bl", line: 1},
					{points: [{x: -6/INCH, y: -1/INCH}, {x: 6/INCH, y: -1/INCH}], color: "bl", line: 1},
					{points: [{x: -6/INCH, y: 0/INCH}, {x: 6/INCH, y: 0/INCH}], color: "bl", line: 1},
					{points: [{x: -6/INCH, y: 1/INCH}, {x: 6/INCH, y: 1/INCH}], color: "bl", line: 1},
					{points: [{x: -6/INCH, y: 2/INCH}, {x: 6/INCH, y: 2/INCH}], color: "bl", line: 1},
					{points: [{x: -6/INCH, y: 3/INCH}, {x: 6/INCH, y: 3/INCH}], color: "bl", line: 1},
					{points: [{x: -6/INCH, y: 4/INCH}, {x: 6/INCH, y: 4/INCH}], color: "bl", line: 1},
					{points: [{x: -6/INCH, y: 5/INCH}, {x: 6/INCH, y: 5/INCH}], color: "bl", line: 1},
					{points: [{x: -6/INCH, y: 6/INCH}, {x: 6/INCH, y: 6/INCH}], color: "bl", line: 1},

					{points: [{x: -6/INCH, y: -6/INCH}, {x: -6/INCH, y: 6/INCH}], color: "bl", line: 1},
					{points: [{x: -5/INCH, y: -6/INCH}, {x: -5/INCH, y: 6/INCH}], color: "bl", line: 1},
					{points: [{x: -4/INCH, y: -6/INCH}, {x: -4/INCH, y: 6/INCH}], color: "bl", line: 1},
					{points: [{x: -3/INCH, y: -6/INCH}, {x: -3/INCH, y: 6/INCH}], color: "bl", line: 1},
					{points: [{x: -2/INCH, y: -6/INCH}, {x: -2/INCH, y: 6/INCH}], color: "bl", line: 1},
					{points: [{x: -1/INCH, y: -6/INCH}, {x: -1/INCH, y: 6/INCH}], color: "bl", line: 1},
					{points: [{x: 0/INCH, y: -6/INCH}, {x: 0/INCH, y: 6/INCH}], color: "bl", line: 1},
					{points: [{x: 1/INCH, y: -6/INCH}, {x: 1/INCH, y: 6/INCH}], color: "bl", line: 1},
					{points: [{x: 2/INCH, y: -6/INCH}, {x: 2/INCH, y: 6/INCH}], color: "bl", line: 1},
					{points: [{x: 3/INCH, y: -6/INCH}, {x: 3/INCH, y: 6/INCH}], color: "bl", line: 1},
					{points: [{x: 4/INCH, y: -6/INCH}, {x: 4/INCH, y: 6/INCH}], color: "bl", line: 1},
					{points: [{x: 5/INCH, y: -6/INCH}, {x: 5/INCH, y: 6/INCH}], color: "bl", line: 1},
					{points: [{x: 6/INCH, y: -6/INCH}, {x: 6/INCH, y: 6/INCH}], color: "bl", line: 1},

					// center
					{points: [{x: -0.5/INCH, y: 0}, {x: 0, y: 0.5/INCH}, {x: 0.5/INCH, y: 0}, {x: 0, y: -0.5/INCH}],
						color: "b", line: 0},
					{points: [{x: -1/INCH, y: 0}, {x: 0, y: 1/INCH}, {x: 1/INCH, y: 0}, {x: 0, y: -1/INCH}],
						color: "w", line: 0},
					{points: [{x: -1.5/INCH, y: 0}, {x: 0, y: 1.5/INCH}, {x: 1.5/INCH, y: 0}, {x: 0, y: -1.5/INCH}],
						color: "b", line: 0},
					{points: [{x: -2/INCH, y: 0}, {x: 0, y: 2/INCH}, {x: 2/INCH, y: 0}, {x: 0, y: -2/INCH}],
						color: "w", line: 0},
					{points: [{x: -3/INCH, y: 0}, {x: 0, y: 3/INCH}, {x: 3/INCH, y: 0}, {x: 0, y: -3/INCH}],
						color: "b", line: 0},

					// bottom left
					{points: [{x: (-4.5 + -0.25)/INCH, y: -4.5/INCH}, {x: -4.5/INCH, y: (-4.5 + 0.25)/INCH}, {x: (-4.5 + 0.25)/INCH, y: -4.5/INCH}, {x: -4.5/INCH, y: (-4.5 + -0.25)/INCH}],
						color: "b", line: 0},
					{points: [{x: (-4.5 + -0.5)/INCH, y: -4.5/INCH}, {x: -4.5/INCH, y: (-4.5 + 0.5)/INCH}, {x: (-4.5 + 0.5)/INCH, y: -4.5/INCH}, {x: -4.5/INCH, y: (-4.5 + -0.5)/INCH}],
						color: "w", line: 0},
					{points: [{x: (-4.5 + -0.75)/INCH, y: -4.5/INCH}, {x: -4.5/INCH, y: (-4.5 + 0.75)/INCH}, {x: (-4.5 + 0.75)/INCH, y: -4.5/INCH}, {x: -4.5/INCH, y: (-4.5 + -0.75)/INCH}],
						color: "b", line: 0},
					{points: [{x: (-4.5 + -1)/INCH, y: -4.5/INCH}, {x: -4.5/INCH, y: (-4.5 + 1)/INCH}, {x: (-4.5 + 1)/INCH, y: -4.5/INCH}, {x: -4.5/INCH, y: (-4.5 + -1)/INCH}],
						color: "w", line: 0},
					{points: [{x: (-4.5 + -1.5)/INCH, y: -4.5/INCH}, {x: -4.5/INCH, y: (-4.5 + 1.5)/INCH}, {x: (-4.5 + 1.5)/INCH, y: -4.5/INCH}, {x: -4.5/INCH, y: (-4.5 + -1.5)/INCH}],
						color: "b", line: 0},

					// top left
					{points: [{x: (-4.5 + -0.25)/INCH, y: 4.5/INCH}, {x: -4.5/INCH, y: (4.5 + 0.25)/INCH}, {x: (-4.5 + 0.25)/INCH, y: 4.5/INCH}, {x: -4.5/INCH, y: (4.5 + -0.25)/INCH}],
						color: "b", line: 0},
					{points: [{x: (-4.5 + -0.5)/INCH, y: 4.5/INCH}, {x: -4.5/INCH, y: (4.5 + 0.5)/INCH}, {x: (-4.5 + 0.5)/INCH, y: 4.5/INCH}, {x: -4.5/INCH, y: (4.5 + -0.5)/INCH}],
						color: "w", line: 0},
					{points: [{x: (-4.5 + -0.75)/INCH, y: 4.5/INCH}, {x: -4.5/INCH, y: (4.5 + 0.75)/INCH}, {x: (-4.5 + 0.75)/INCH, y: 4.5/INCH}, {x: -4.5/INCH, y: (4.5 + -0.75)/INCH}],
						color: "b", line: 0},
					{points: [{x: (-4.5 + -1)/INCH, y: 4.5/INCH}, {x: -4.5/INCH, y: (4.5 + 1)/INCH}, {x: (-4.5 + 1)/INCH, y: 4.5/INCH}, {x: -4.5/INCH, y: (4.5 + -1)/INCH}],
						color: "w", line: 0},
					{points: [{x: (-4.5 + -1.5)/INCH, y: 4.5/INCH}, {x: -4.5/INCH, y: (4.5 + 1.5)/INCH}, {x: (-4.5 + 1.5)/INCH, y: 4.5/INCH}, {x: -4.5/INCH, y: (4.5 + -1.5)/INCH}],
						color: "b", line: 0},

					// bottom right
					{points: [{x: (4.5 + -0.25)/INCH, y: -4.5/INCH}, {x: 4.5/INCH, y: (-4.5 + 0.25)/INCH}, {x: (4.5 + 0.25)/INCH, y: -4.5/INCH}, {x: 4.5/INCH, y: (-4.5 + -0.25)/INCH}],
						color: "b", line: 0},
					{points: [{x: (4.5 + -0.5)/INCH, y: -4.5/INCH}, {x: 4.5/INCH, y: (-4.5 + 0.5)/INCH}, {x: (4.5 + 0.5)/INCH, y: -4.5/INCH}, {x: 4.5/INCH, y: (-4.5 + -0.5)/INCH}],
						color: "w", line: 0},
					{points: [{x: (4.5 + -0.75)/INCH, y: -4.5/INCH}, {x: 4.5/INCH, y: (-4.5 + 0.75)/INCH}, {x: (4.5 + 0.75)/INCH, y: -4.5/INCH}, {x: 4.5/INCH, y: (-4.5 + -0.75)/INCH}],
						color: "b", line: 0},
					{points: [{x: (4.5 + -1)/INCH, y: -4.5/INCH}, {x: 4.5/INCH, y: (-4.5 + 1)/INCH}, {x: (4.5 + 1)/INCH, y: -4.5/INCH}, {x: 4.5/INCH, y: (-4.5 + -1)/INCH}],
						color: "w", line: 0},
					{points: [{x: (4.5 + -1.5)/INCH, y: -4.5/INCH}, {x: 4.5/INCH, y: (-4.5 + 1.5)/INCH}, {x: (4.5 + 1.5)/INCH, y: -4.5/INCH}, {x: 4.5/INCH, y: (-4.5 + -1.5)/INCH}],
						color: "b", line: 0},

					// top right
					{points: [{x: (4.5 + -0.25)/INCH, y: 4.5/INCH}, {x: 4.5/INCH, y: (4.5 + 0.25)/INCH}, {x: (4.5 + 0.25)/INCH, y: 4.5/INCH}, {x: 4.5/INCH, y: (4.5 + -0.25)/INCH}],
						color: "b", line: 0},
					{points: [{x: (4.5 + -0.5)/INCH, y: 4.5/INCH}, {x: 4.5/INCH, y: (4.5 + 0.5)/INCH}, {x: (4.5 + 0.5)/INCH, y: 4.5/INCH}, {x: 4.5/INCH, y: (4.5 + -0.5)/INCH}],
						color: "w", line: 0},
					{points: [{x: (4.5 + -0.75)/INCH, y: 4.5/INCH}, {x: 4.5/INCH, y: (4.5 + 0.75)/INCH}, {x: (4.5 + 0.75)/INCH, y: 4.5/INCH}, {x: 4.5/INCH, y: (4.5 + -0.75)/INCH}],
						color: "b", line: 0},
					{points: [{x: (4.5 + -1)/INCH, y: 4.5/INCH}, {x: 4.5/INCH, y: (4.5 + 1)/INCH}, {x: (4.5 + 1)/INCH, y: 4.5/INCH}, {x: 4.5/INCH, y: (4.5 + -1)/INCH}],
						color: "w", line: 0},
					{points: [{x: (4.5 + -1.5)/INCH, y: 4.5/INCH}, {x: 4.5/INCH, y: (4.5 + 1.5)/INCH}, {x: (4.5 + 1.5)/INCH, y: 4.5/INCH}, {x: 4.5/INCH, y: (4.5 + -1.5)/INCH}],
						color: "b", line: 0},

					// boxes
					{points: [{x: -0.5/INCH, y: 3/INCH}, {x: 0.5/INCH, y: 3/INCH}, {x: 0.5/INCH, y: 6.5/INCH}, {x: -0.5/INCH, y: 6.5/INCH}],
						color: "b", line: 0},
					{points: [{x: -0.5/INCH, y: -3/INCH}, {x: 0.5/INCH, y: -3/INCH}, {x: 0.5/INCH, y: -6.5/INCH}, {x: -0.5/INCH, y: -6.5/INCH}],
						color: "b", line: 0},
					{points: [{x: -3/INCH, y: -0.5/INCH}, {x: -3/INCH, y: 0.5/INCH}, {x: -6.5/INCH, y: 0.5/INCH}, {x: -6.5/INCH, y: -0.5/INCH}],
						color: "b", line: 0},
					{points: [{x: 3/INCH, y: -0.5/INCH}, {x: 3/INCH, y: 0.5/INCH}, {x: 6.5/INCH, y: 0.5/INCH}, {x: 6.5/INCH, y: -0.5/INCH}],
						color: "b", line: 0},
		],

		text: [
		].concat(text_rings({x: 6.5/INCH, y: 6/INCH}, {x: 0, y: -1/INCH}, 6, 1, {size: 20, color: "gl"}))
		.concat(text_rings({x: 6.5/INCH, y: -6/INCH}, {x: 0, y: 1/INCH}, 6, 1, {size: 20, color: "gl"}))
		.concat(text_rings({x: -6/INCH, y: 6.5/INCH}, {x: 1/INCH, y: 0}, 6, 1, {size: 20, color: "gl"}))
		.concat(text_rings({x: 6/INCH, y: 6.5/INCH}, {x: -1/INCH, y: 0}, 6, 1, {size: 20, color: "gl"}))

	};

	// Splatterburst
	targetfaces["Splat1218"] = {
		name: "Splatterburst 12x18",
		shortname: "Splatterburst 12x18",
		dist: 100,
		dist_unit: "y",
		board: {w: 12.5/INCH, h: 18/INCH, line: 2},

		poly: [

					// grid
					{points: [{x: -6/INCH, y: -7/INCH}, {x: 6/INCH, y: -7/INCH}], color: "bl", line: 0.5},
					{points: [{x: -6/INCH, y: -6/INCH}, {x: 6/INCH, y: -6/INCH}], color: "bl", line: 0.5},
					{points: [{x: -6/INCH, y: -5/INCH}, {x: 6/INCH, y: -5/INCH}], color: "bl", line: 0.5},
					{points: [{x: -6/INCH, y: -4/INCH}, {x: 6/INCH, y: -4/INCH}], color: "bl", line: 0.5},
					{points: [{x: -6/INCH, y: -3/INCH}, {x: 6/INCH, y: -3/INCH}], color: "bl", line: 0.5},
					{points: [{x: -6/INCH, y: -2/INCH}, {x: 6/INCH, y: -2/INCH}], color: "bl", line: 0.5},
					{points: [{x: -6/INCH, y: -1/INCH}, {x: 6/INCH, y: -1/INCH}], color: "bl", line: 0.5},
					{points: [{x: -6/INCH, y: 0/INCH}, {x: 6/INCH, y: 0/INCH}], color: "bl", line: 0.5},
					{points: [{x: -6/INCH, y: 1/INCH}, {x: 6/INCH, y: 1/INCH}], color: "bl", line: 0.5},
					{points: [{x: -6/INCH, y: 2/INCH}, {x: 6/INCH, y: 2/INCH}], color: "bl", line: 0.5},
					{points: [{x: -6/INCH, y: 3/INCH}, {x: 6/INCH, y: 3/INCH}], color: "bl", line: 0.5},
					{points: [{x: -6/INCH, y: 4/INCH}, {x: 6/INCH, y: 4/INCH}], color: "bl", line: 0.5},
					{points: [{x: -6/INCH, y: 5/INCH}, {x: 6/INCH, y: 5/INCH}], color: "bl", line: 0.5},
					{points: [{x: -6/INCH, y: 6/INCH}, {x: 6/INCH, y: 6/INCH}], color: "bl", line: 0.5},
					{points: [{x: -6/INCH, y: 7/INCH}, {x: 6/INCH, y: 7/INCH}], color: "bl", line: 0.5},

					{points: [{x: -5/INCH, y: -8/INCH}, {x: -5/INCH, y: 8/INCH}], color: "bl", line: 0.5},
					{points: [{x: -4/INCH, y: -8/INCH}, {x: -4/INCH, y: 8/INCH}], color: "bl", line: 0.5},
					{points: [{x: -3/INCH, y: -8/INCH}, {x: -3/INCH, y: 8/INCH}], color: "bl", line: 0.5},
					{points: [{x: -2/INCH, y: -8/INCH}, {x: -2/INCH, y: 8/INCH}], color: "bl", line: 0.5},
					{points: [{x: -1/INCH, y: -8/INCH}, {x: -1/INCH, y: 8/INCH}], color: "bl", line: 0.5},
					{points: [{x: 0/INCH, y: -8/INCH}, {x: 0/INCH, y: 8/INCH}], color: "bl", line: 0.5},
					{points: [{x: 1/INCH, y: -8/INCH}, {x: 1/INCH, y: 8/INCH}], color: "bl", line: 0.5},
					{points: [{x: 2/INCH, y: -8/INCH}, {x: 2/INCH, y: 8/INCH}], color: "bl", line: 0.5},
					{points: [{x: 3/INCH, y: -8/INCH}, {x: 3/INCH, y: 8/INCH}], color: "bl", line: 0.5},
					{points: [{x: 4/INCH, y: -8/INCH}, {x: 4/INCH, y: 8/INCH}], color: "bl", line: 0.5},
					{points: [{x: 5/INCH, y: -8/INCH}, {x: 5/INCH, y: 8/INCH}], color: "bl", line: 0.5},
					
					{points: polybox(0, 0, 4/INCH, 4/INCH), color: "bl", line: 2},
					{points: polybox(-2.5/INCH, 4.5/INCH, 3/INCH, 3/INCH), color: "bl", line: 2},
					{points: polybox(2.5/INCH, 4.5/INCH, 3/INCH, 3/INCH), color: "bl", line: 2},
					{points: polybox(-2.5/INCH, -4.5/INCH, 3/INCH, 3/INCH), color: "bl", line: 2},
					{points: polybox(2.5/INCH, -4.5/INCH, 3/INCH, 3/INCH), color: "bl", line: 2},
					
		],
		
		poly_top: [
					
					{points: polybox(0, 0, 2/INCH, 2/INCH), color: "g", line: 2},
					{points: polybox(-2.5/INCH, 4.5/INCH, 1/INCH, 1/INCH), color: "g", line: 2},
					{points: polybox(2.5/INCH, 4.5/INCH, 1/INCH, 1/INCH), color: "g", line: 2},
					{points: polybox(-2.5/INCH, -4.5/INCH, 1/INCH, 1/INCH), color: "g", line: 2},
					{points: polybox(2.5/INCH, -4.5/INCH, 1/INCH, 1/INCH), color: "g", line: 2},

		],

	};	


	// NASS
	targetfaces["NASS"] = {
		name: "TaskForceTargets NASS",
		shortname: "NASS",
		dist: 100,
		dist_unit: "m",
		board: {w: 23/INCH, h: 35/INCH, line: 2},
		score: [10],
		rings: [

					{diam: 2/INCH, color: "bl", line: 2, x: 5/INCH, y: 10/INCH, score: 10},
					{diam: 4/INCH, color: "bl", line: 2, x: 5/INCH, y: 10/INCH, score: 9},
					{diam: 6/INCH, color: "bl", line: 2, x: 5/INCH, y: 10/INCH, score: 8},
					{diam: 8/INCH, color: "bl", line: 2, x: 5/INCH, y: 10/INCH, score: 7},

					{diam: 2/INCH, color: "bl", line: 2, x: 5/INCH, y: 0/INCH, score: 10},
					{diam: 4/INCH, color: "bl", line: 2, x: 5/INCH, y: 0/INCH, score: 9},
					{diam: 6/INCH, color: "bl", line: 2, x: 5/INCH, y: 0/INCH, score: 8},
					{diam: 8/INCH, color: "bl", line: 2, x: 5/INCH, y: 0/INCH, score: 7},

					{diam: 2/INCH, color: "bl", line: 2, x: 5/INCH, y: -10/INCH, score: 10},
					{diam: 4/INCH, color: "bl", line: 2, x: 5/INCH, y: -10/INCH, score: 9},
					{diam: 6/INCH, color: "bl", line: 2, x: 5/INCH, y: -10/INCH, score: 8},
					{diam: 8/INCH, color: "bl", line: 2, x: 5/INCH, y: -10/INCH, score: 7},

					{diam: 2/INCH, color: "bl", line: 2, x: -5/INCH, y: 10/INCH, score: 10},
					{diam: 4/INCH, color: "bl", line: 2, x: -5/INCH, y: 10/INCH, score: 9},
					{diam: 6/INCH, color: "bl", line: 2, x: -5/INCH, y: 10/INCH, score: 8},
					{diam: 8/INCH, color: "bl", line: 2, x: -5/INCH, y: 10/INCH, score: 7},

					{diam: 2/INCH, color: "bl", line: 2, x: -5/INCH, y: 0/INCH, score: 10},
					{diam: 4/INCH, color: "bl", line: 2, x: -5/INCH, y: 0/INCH, score: 9},
					{diam: 6/INCH, color: "bl", line: 2, x: -5/INCH, y: 0/INCH, score: 8},
					{diam: 8/INCH, color: "bl", line: 2, x: -5/INCH, y: 0/INCH, score: 7},

					{diam: 2/INCH, color: "bl", line: 2, x: -5/INCH, y: -10/INCH, score: 10},
					{diam: 4/INCH, color: "bl", line: 2, x: -5/INCH, y: -10/INCH, score: 9},
					{diam: 6/INCH, color: "bl", line: 2, x: -5/INCH, y: -10/INCH, score: 8},
					{diam: 8/INCH, color: "bl", line: 2, x: -5/INCH, y: -10/INCH, score: 7},

		],

		poly: [

					{points: [{x: (-5 - 1)/INCH, y: (10 - 1)/INCH}, {x: (-5 + 1)/INCH, y: (10 - 1)/INCH}, {x: (-5 + 1)/INCH, y: (10 + 1)/INCH}, {x: (-5 - 1)/INCH, y: (10 + 1)/INCH}],
						color: "w", line: 0},
					{points: [{x: (-5 - 2)/INCH, y: (10 - 2)/INCH}, {x: (-5 + 2)/INCH, y: (10 - 2)/INCH}, {x: (-5 + 2)/INCH, y: (10 + 2)/INCH}, {x: (-5 - 2)/INCH, y: (10 + 2)/INCH}],
						color: "g", line: 0},

					{points: [{x: (-5 - 1)/INCH, y: (0 - 1)/INCH}, {x: (-5 + 1)/INCH, y: (0 - 1)/INCH}, {x: (-5 + 1)/INCH, y: (0 + 1)/INCH}, {x: (-5 - 1)/INCH, y: (0 + 1)/INCH}],
						color: "w", line: 0},
					{points: [{x: (-5 - 2)/INCH, y: (0 - 2)/INCH}, {x: (-5 + 2)/INCH, y: (0 - 2)/INCH}, {x: (-5 + 2)/INCH, y: (0 + 2)/INCH}, {x: (-5 - 2)/INCH, y: (0 + 2)/INCH}],
						color: "g", line: 0},

					{points: [{x: (-5 - 1)/INCH, y: (-10 - 1)/INCH}, {x: (-5 + 1)/INCH, y: (-10 - 1)/INCH}, {x: (-5 + 1)/INCH, y: (-10 + 1)/INCH}, {x: (-5 - 1)/INCH, y: (-10 + 1)/INCH}],
						color: "w", line: 0},
					{points: [{x: (-5 - 2)/INCH, y: (-10 - 2)/INCH}, {x: (-5 + 2)/INCH, y: (-10 - 2)/INCH}, {x: (-5 + 2)/INCH, y: (-10 + 2)/INCH}, {x: (-5 - 2)/INCH, y: (-10 + 2)/INCH}],
						color: "g", line: 0},

					{points: [{x: (5 - 1)/INCH, y: (10 - 1)/INCH}, {x: (5 + 1)/INCH, y: (10 - 1)/INCH}, {x: (5 + 1)/INCH, y: (10 + 1)/INCH}, {x: (5 - 1)/INCH, y: (10 + 1)/INCH}],
						color: "w", line: 0},
					{points: [{x: (5 - 2)/INCH, y: (10 - 2)/INCH}, {x: (5 + 2)/INCH, y: (10 - 2)/INCH}, {x: (5 + 2)/INCH, y: (10 + 2)/INCH}, {x: (5 - 2)/INCH, y: (10 + 2)/INCH}],
						color: "g", line: 0},

					{points: [{x: (5 - 1)/INCH, y: (0 - 1)/INCH}, {x: (5 + 1)/INCH, y: (0 - 1)/INCH}, {x: (5 + 1)/INCH, y: (0 + 1)/INCH}, {x: (5 - 1)/INCH, y: (0 + 1)/INCH}],
						color: "w", line: 0},
					{points: [{x: (5 - 2)/INCH, y: (0 - 2)/INCH}, {x: (5 + 2)/INCH, y: (0 - 2)/INCH}, {x: (5 + 2)/INCH, y: (0 + 2)/INCH}, {x: (5 - 2)/INCH, y: (0 + 2)/INCH}],
						color: "g", line: 0},

					{points: [{x: (5 - 1)/INCH, y: (-10 - 1)/INCH}, {x: (5 + 1)/INCH, y: (-10 - 1)/INCH}, {x: (5 + 1)/INCH, y: (-10 + 1)/INCH}, {x: (5 - 1)/INCH, y: (-10 + 1)/INCH}],
						color: "w", line: 0},
					{points: [{x: (5 - 2)/INCH, y: (-10 - 2)/INCH}, {x: (5 + 2)/INCH, y: (-10 - 2)/INCH}, {x: (5 + 2)/INCH, y: (-10 + 2)/INCH}, {x: (5 - 2)/INCH, y: (-10 + 2)/INCH}],
						color: "g", line: 0},

		],

		text: [     {x: 0, y: -4/INCH, size: 0.5/INCH, color: "bl", text: "SP / RINGS (NASS)"},
					{x: 0, y: -4.5/INCH, size: 0.5/INCH, color: "bl", text: "TaskForceTargets.com"}
		]


	};


	targetfaces["ISSFC50"] = {
		name: "ISSF C50",
		shortname: "ISSF C50",
		dist: 100,
		dist_unit: "m",
		score: [10, "X"],
		board: {w: 520, h: 520, line: 3, score: 0},

		rings: [	{diam: 25, color: "b", line: 0.5, score: "X"},
					{diam: 50, color: "b", line: 0.5, score: 10},
					{diam: 100, color: "b", line: 0.5, score: 9},
					{diam: 150, color: "b", line: 0.5, score: 8},
					{diam: 200, color: "b", line: 0.5, score: 7},
					{diam: 250, color: "w", line: 0.5, score: 6},
					{diam: 300, color: "w", line: 0.5, score: 5},
					{diam: 350, color: "w", line: 0.5, score: 4},
					{diam: 400, color: "w", line: 0.5, score: 3},
					{diam: 450, color: "w", line: 0.5, score: 2},
					{diam: 500, color: "w", line: 0.5, score: 1}
		],

		text: [
		].concat(text_rings({x: 37.5, y: 0}, {x: 25, y: 0}, 9, 1, {size: 15, color: "gl"}))
		.concat(text_rings({x: -37.5, y: 0}, {x: -25, y: 0}, 9, 1, {size: 15, color: "gl"}))
		.concat(text_rings({x: 0, y: 37.5}, {x: 0, y: 25}, 9, 1, {size: 15, color: "gl"}))
		.concat(text_rings({x: 0, y: -37.5}, {x: 0, y: -25}, 9, 1, {size: 15, color: "gl"}))

	};


	targetfaces["ISSFC200"] = {
		name: "ISSF C200",
		shortname: "ISSF C200",
		dist: 200,
		dist_unit: "m",
		score: [10],
		board: {w: 850, h: 850, line: 5, score: 0},

		rings: [	{diam: 80, color: "b", line: 2.5, score: 10},
					{diam: 160, color: "b", line: 2.5, score: 9},
					{diam: 240, color: "b", line: 2.5, score: 8},
					{diam: 320, color: "b", line: 2.5, score: 7},
					{diam: 400, color: "b", line: 2.5, score: 6},
					{diam: 480, color: "w", line: 2.5, score: 5},
					{diam: 560, color: "w", line: 2.5, score: 4},
					{diam: 640, color: "w", line: 2.5, score: 3},
					{diam: 720, color: "w", line: 2.5, score: 2},
					{diam: 800, color: "w", line: 2.5, score: 1}
		],

		text: [
		].concat(text_rings({x: 100, y: 0}, {x: 40, y: 0}, 8, 1, {size: 20, color: "gl"}))
		.concat(text_rings({x: -100, y: 0}, {x: -40, y: 0}, 8, 1, {size: 20, color: "gl"}))
		.concat(text_rings({x: 0, y: 100}, {x: 0, y: 40}, 8, 1, {size: 20, color: "gl"}))
		.concat(text_rings({x: 0, y: -100}, {x: 0, y: -40}, 8, 1, {size: 20, color: "gl"}))

	};

	targetfaces["ISSF300"] = {
		name: "ISSF 300m",
		shortname: "ISSF 300m",
		dist: 300,
		dist_unit: "m",
		score: [10, "X"],
		board: {w: 1300, h: 1300, line: 10, score: 0},

		rings: [	{diam: 50, color: "b", line: 1, score: "X"},
					{diam: 100, color: "b", line: 1.5, score: 10},
					{diam: 200, color: "b", line: 1.5, score: 9},
					{diam: 300, color: "b", line: 1.5, score: 8},
					{diam: 400, color: "b", line: 1.5, score: 7},
					{diam: 500, color: "b", line: 1.5, score: 6},
					{diam: 600, color: "b", line: 1.5, score: 5},
					{diam: 700, color: "w", line: 1.5, score: 4},
					{diam: 800, color: "w", line: 1.5, score: 3},
					{diam: 900, color: "w", line: 1.5, score: 2},
					{diam: 1000, color: "w", line: 1.5, score: 1}
		],
/*
		text: [
		].concat(text_rings({x: 75*DIAG, y: 75*DIAG}, {x: 50*DIAG, y: 50*DIAG}, 9, 1, {size: 30, color: "gl", angle: 45}))
		.concat(text_rings({x: 75*DIAG, y: -75*DIAG}, {x: 50*DIAG, y: -50*DIAG}, 9, 1, {size: 30, color: "gl", angle: 135}))
		.concat(text_rings({x: -75*DIAG, y: -75*DIAG}, {x: -50*DIAG, y: -50*DIAG}, 9, 1, {size: 30, color: "gl", angle: 225}))
		.concat(text_rings({x: -75*DIAG, y: 75*DIAG}, {x: -50*DIAG, y: 50*DIAG}, 9, 1, {size: 30, color: "gl", angle: 315}))
*/
		default_ring_text: true,
	};


	targetfaces["ISSF300x15"] = {
		name: "ISSF 300m +50%",
		shortname: "ISSF 300m +50%",
		dist: 300,
		dist_unit: "m",
		score: [10, "X"],
		board: {w: 1800, h: 1800, line: 10, score: 0},

		rings: [	{diam: 75, color: "b", line: 1, score: "X"},
					{diam: 150, color: "b", line: 1.5, score: 10},
					{diam: 300, color: "b", line: 1.5, score: 9},
					{diam: 450, color: "b", line: 1.5, score: 8},
					{diam: 600, color: "b", line: 1.5, score: 7},
					{diam: 750, color: "b", line: 1.5, score: 6},
					{diam: 900, color: "b", line: 1.5, score: 5},
					{diam: 1050, color: "w", line: 1.5, score: 4},
					{diam: 1200, color: "w", line: 1.5, score: 3},
					{diam: 1350, color: "w", line: 1.5, score: 2},
					{diam: 1500, color: "w", line: 1.5, score: 1}
		],

		text: [
		].concat(text_rings({x: 112.5*DIAG, y: 112.5*DIAG}, {x: 75*DIAG, y: 75*DIAG}, 9, 1, {size: 40, color: "gl", angle: 45}))
		.concat(text_rings({x: 112.5*DIAG, y: -112.5*DIAG}, {x: 75*DIAG, y: -75*DIAG}, 9, 1, {size: 40, color: "gl", angle: 135}))
		.concat(text_rings({x: -112.5*DIAG, y: -112.5*DIAG}, {x: -75*DIAG, y: -75*DIAG}, 9, 1, {size: 40, color: "gl", angle: 225}))
		.concat(text_rings({x: -112.5*DIAG, y: 112.5*DIAG}, {x: -75*DIAG, y: 75*DIAG}, 9, 1, {size: 40, color: "gl", angle: 315}))

	};







	// 303 British (Peter Dobson)

	targetfaces["303B200"] = {
		name: "303 British 200",
		shortname: "303 British 200",
		dist: 200,
		dist_unit: "m",
		score: [5],
		board: {w: 1800, h: 1800, line: 10, score: 0},

		rings: [	{diam: 7/INCH, color: "w", line: 2, score: 5},
					{diam: 14/INCH, color: "w", line: 2, score: 4},
					{diam: 28/INCH, color: "w", line: 2, score: 3},
					{diam: 55/INCH, color: "w", line: 2, score: 2}
		],


		poly: [
			{ points: polyarc(0, 0, 14/2/INCH, 0, 180, 5), color: "g", line: 0}
		],

	};

	targetfaces["303B300"] = {
		name: "303 British 300",
		shortname: "303 British 300",
		dist: 300,
		dist_unit: "m",
		score: [5],
		board: {w: 1800, h: 1800, line: 10, score: 0},

		rings: [	{diam: 10/INCH, color: "w", line: 3, score: 5},
					{diam: 21/INCH, color: "w", line: 3, score: 4},
					{diam: 40/INCH, color: "w", line: 3, score: 3},
					{diam: 55/INCH, color: "w", line: 3, score: 2}
		],

		poly: [
			{ points: polyarc(0, 0, 21/2/INCH, 0, 180, 5), color: "g", line: 0}
		],

	};

	targetfaces["303B500"] = {
		name: "303 British 500",
		shortname: "303 British 500",
		dist: 500,
		dist_unit: "m",
		score: [5],
		board: {w: 1800, h: 1800, line: 10, score: 2},

		rings: [	{diam: 21/INCH, color: "w", line: 5, score: 5},
					{diam: 41/INCH, color: "w", line: 5, score: 4},
					{diam: 55/INCH, color: "w", line: 5, score: 3}
		],

		poly: [
			{ points: polyarc(0, 0, 35/2/INCH, 0, 180, 5), color: "g", line: 0}
		],

	};

	// Swiss

	targetfaces["SW_A10"] = {
		name: "Swiss A10",
		shortname: "Swiss A10",
		dist: 300,
		dist_unit: "m",
		score: [10, "X"],
		board: {w: 1500, h: 1650, line: 10, score: 0},
		rings: [	{diam: 50, color: "b", line: 1.5, score: "X"},
					{diam: 100, color: "b", line: 1.5, score: 10},
					{diam: 200, color: "b", line: 1.5, score: 9},
					{diam: 300, color: "b", line: 1.5, score: 8},
					{diam: 400, color: "b", line: 1.5, score: 7},
					{diam: 500, color: "b", line: 1.5, score: 6},
					{diam: 600, color: "b", line: 1.5, score: 5},
					{diam: 700, color: "w", line: 1.5, score: 4},
					{diam: 800, color: "w", line: 1.5, score: 3},
					{diam: 900, color: "w", line: 1.5, score: 2},
					{diam: 1000, color: "w", line: 1.5, score: 1}
		],

		text: [
		].concat(text_rings({x: 75*DIAG, y: 75*DIAG}, {x: 50*DIAG, y: 50*DIAG}, 9, 1, {size: 30, color: "gl", angle: 45}))
		.concat(text_rings({x: 75*DIAG, y: -75*DIAG}, {x: 50*DIAG, y: -50*DIAG}, 9, 1, {size: 30, color: "gl", angle: 135}))
		.concat(text_rings({x: -75*DIAG, y: -75*DIAG}, {x: -50*DIAG, y: -50*DIAG}, 9, 1, {size: 30, color: "gl", angle: 225}))
		.concat(text_rings({x: -75*DIAG, y: 75*DIAG}, {x: -50*DIAG, y: 50*DIAG}, 9, 1, {size: 30, color: "gl", angle: 315}))

	};

	targetfaces["SW_A5"] = {
		name: "Swiss A5",
		shortname: "Swiss A5",
		dist: 300,
		dist_unit: "m",
		score: [5],
		board: {w: 1500, h: 1650, line: 10, score: 0},
		rings: [	{diam: 200, color: "b", line: 1.5, score: 5},
					{diam: 400, color: "b", line: 1.5, score: 4},
					{diam: 600, color: "b", line: 1.5, score: 3},
					{diam: 800, color: "w", line: 1.5, score: 2},
					{diam: 1000, color: "w", line: 1.5, score: 1}
		],

		text: [
		].concat(text_rings({x: 50*DIAG, y: 50*DIAG}, {x: 100*DIAG, y: 100*DIAG}, 5, 1, {size: 75, color: "gl", angle: 45}))
		.concat(text_rings({x: -50*DIAG, y: -50*DIAG}, {x: -100*DIAG, y: -100*DIAG}, 5, 1, {size: 75, color: "gl", angle: 45}))
		.concat(text_rings({x: -50*DIAG, y: 50*DIAG}, {x: -100*DIAG, y: 100*DIAG}, 5, 1, {size: 75, color: "gl", angle: -45}))
		.concat(text_rings({x: 50*DIAG, y: -50*DIAG}, {x: 100*DIAG, y: -100*DIAG}, 5, 1, {size: 75, color: "gl", angle: -45}))
	};

	targetfaces["SW_B4"] = {
		name: "Swiss B4",
		shortname: "Swiss B4",
		dist: 300,
		dist_unit: "m",
		score: [4],
		board: {w: 1500, h: 1650, line: 10, score: 0},

		rings_top: [	{diam: 100, color: "gl", line: 1.5},
						{diam: 200, color: "wl", line: 3, score: 4},
						{diam: 300, color: "gl", line: 1.5},
						{diam: 400, color: "gl", line: 1.5},
						{diam: 500, color: "gl", line: 1.5},
						{diam: 600, color: "gl", line: 1.5},
		],

		poly_top: [
					{points: [{x: -225, y: -200}, {x: -225, y: 200}, {x: -100, y: 210}, {x: -100, y: 300}, {x: 100, y: 300}, {x: 100, y: 210}, {x: 225, y: 200}, {x: 225, y: -200}], color: "b", score: 3},
		],

		rings: [
					{diam: 700, color: "bl", line: 3, score: 2},
					{diam: 800, color: "gl", line: 1.5},
					{diam: 900, color: "gl", line: 1.5},
					{diam: 1000, color: "bl", line: 3, score: 1}
		],

		text: [
			{x: 0, y: 50, size: 100, color: "gl", text: "4"},
			{x: 0, y: 225, size: 100, color: "gl", text: "3"},
			{x: -175, y: 0, size: 100, color: "gl", text: "3", angle: -90},
			{x: 175, y: 0, size: 100, color: "gl", text: "3", angle: 90},
			{x: -275, y: 0, size: 100, color: "gl", text: "2", angle: -90},
			{x: 275, y: 0, size: 100, color: "gl", text: "2", angle: 90},
			{x: -425, y: 0, size: 100, color: "gl", text: "1", angle: -90},
			{x: 425, y: 0, size: 100, color: "gl", text: "1", angle: 90},
		]

	};
	
	targetfaces["SW_B4_200"] = {
		name: "Swiss B4-200",
		shortname: "Swiss B4-200",
		dist: 200,
		dist_unit: "y",
		score: [4],
		board: {w: 1500, h: 1650, line: 10, score: 0},

		rings_top: [	{diam: 100/1.64, color: "gl", line: 1},
						{diam: 200/1.64, color: "wl", line: 2, score: 4},
						{diam: 300/1.64, color: "gl", line: 1},
						{diam: 400/1.64, color: "gl", line: 1},
						{diam: 500/1.64, color: "gl", line: 1},
						{diam: 600/1.64, color: "gl", line: 1},
		],

		poly_top: [
					{points: [{x: -225/1.64, y: -200/1.64}, {x: -225/1.64, y: 200/1.64}, {x: -100/1.64, y: 210/1.64}, {x: -100/1.64, y: 300/1.64}, {x: 100/1.64, y: 300/1.64}, {x: 100/1.64, y: 210/1.64}, {x: 225/1.64, y: 200/1.64}, {x: 225/1.64, y: -200/1.64}], color: "b", score: 3},
		],

		rings: [
					{diam: 700/1.64, color: "bl", line: 2, score: 2},
					{diam: 800/1.64, color: "gl", line: 1},
					{diam: 900/1.64, color: "gl", line: 1},
					{diam: 1000/1.64, color: "bl", line: 2, score: 1}
		],

		text: [
			{x: 0, y: 50/1.64, size: 60, color: "gl", text: "4"},
			{x: 0, y: 225/1.64, size: 60, color: "gl", text: "3"},
			{x: -175/1.64, y: 0, size: 60, color: "gl", text: "3", angle: -90},
			{x: 175/1.64, y: 0, size: 60, color: "gl", text: "3", angle: 90},
			{x: -275/1.64, y: 0, size: 60, color: "gl", text: "2", angle: -90},
			{x: 275/1.64, y: 0, size: 60, color: "gl", text: "2", angle: 90},
			{x: -425/1.64, y: 0, size: 60, color: "gl", text: "1", angle: -90},
			{x: 425/1.64, y: 0, size: 60, color: "gl", text: "1", angle: 90},
		]

	};

	targetfaces["SW_A100"] = {
		name: "Swiss A100",
		shortname: "Swiss A100",
		dist: 300,
		dist_unit: "m",
		score: [100],
		board: { w: 1300, h: 1300, line: 10, score: 0 },
		rings: [
			{ diam: 10, color: "b", line: 0, score: 100 },
			{ diam: 20, color: "b", line: 0, score: 99 },
			{ diam: 30, color: "b", line: 0, score: 98 },
			{ diam: 40, color: "b", line: 0, score: 97 },
			{ diam: 50, color: "b", line: 1, score: 96 },
			{ diam: 60, color: "b", line: 0, score: 95 },
			{ diam: 70, color: "b", line: 0, score: 94 },
			{ diam: 80, color: "b", line: 0, score: 93 },
			{ diam: 90, color: "b", line: 0, score: 92 },
			{ diam: 100, color: "b", line: 1.5, score: 91 },
			{ diam: 110, color: "b", line: 0, score: 90 },
			{ diam: 120, color: "b", line: 0, score: 89 },
			{ diam: 130, color: "b", line: 0, score: 88 },
			{ diam: 140, color: "b", line: 0, score: 87 },
			{ diam: 150, color: "b", line: 0, score: 86 },
			{ diam: 160, color: "b", line: 0, score: 85 },
			{ diam: 170, color: "b", line: 0, score: 84 },
			{ diam: 180, color: "b", line: 0, score: 83 },
			{ diam: 190, color: "b", line: 0, score: 82 },
			{ diam: 200, color: "b", line: 1.5, score: 81 },
			{ diam: 210, color: "b", line: 0, score: 80 },
			{ diam: 220, color: "b", line: 0, score: 79 },
			{ diam: 230, color: "b", line: 0, score: 78 },
			{ diam: 240, color: "b", line: 0, score: 77 },
			{ diam: 250, color: "b", line: 0, score: 76 },
			{ diam: 260, color: "b", line: 0, score: 75 },
			{ diam: 270, color: "b", line: 0, score: 74 },
			{ diam: 280, color: "b", line: 0, score: 73 },
			{ diam: 290, color: "b", line: 0, score: 72 },
			{ diam: 300, color: "b", line: 1.5, score: 71 },
			{ diam: 310, color: "b", line: 0, score: 70 },
			{ diam: 320, color: "b", line: 0, score: 69 },
			{ diam: 330, color: "b", line: 0, score: 68 },
			{ diam: 340, color: "b", line: 0, score: 67 },
			{ diam: 350, color: "b", line: 0, score: 66 },
			{ diam: 360, color: "b", line: 0, score: 65 },
			{ diam: 370, color: "b", line: 0, score: 64 },
			{ diam: 380, color: "b", line: 0, score: 63 },
			{ diam: 390, color: "b", line: 0, score: 62 },
			{ diam: 400, color: "b", line: 1.5, score: 61 },
			{ diam: 410, color: "b", line: 0, score: 60 },
			{ diam: 420, color: "b", line: 0, score: 59 },
			{ diam: 430, color: "b", line: 0, score: 58 },
			{ diam: 440, color: "b", line: 0, score: 57 },
			{ diam: 450, color: "b", line: 0, score: 56 },
			{ diam: 460, color: "b", line: 0, score: 55 },
			{ diam: 470, color: "b", line: 0, score: 54 },
			{ diam: 480, color: "b", line: 0, score: 53 },
			{ diam: 490, color: "b", line: 0, score: 52 },
			{ diam: 500, color: "b", line: 1.5, score: 51 },
			{ diam: 510, color: "b", line: 0, score: 50 },
			{ diam: 520, color: "b", line: 0, score: 49 },
			{ diam: 530, color: "b", line: 0, score: 48 },
			{ diam: 540, color: "b", line: 0, score: 47 },
			{ diam: 550, color: "b", line: 0, score: 46 },
			{ diam: 560, color: "b", line: 0, score: 45 },
			{ diam: 570, color: "b", line: 0, score: 44 },
			{ diam: 580, color: "b", line: 0, score: 43 },
			{ diam: 590, color: "b", line: 0, score: 42 },
			{ diam: 600, color: "b", line: 1.5, score: 41 },
			{ diam: 610, color: "w", line: 0, score: 40 },
			{ diam: 620, color: "w", line: 0, score: 39 },
			{ diam: 630, color: "w", line: 0, score: 38 },
			{ diam: 640, color: "w", line: 0, score: 37 },
			{ diam: 650, color: "w", line: 0, score: 36 },
			{ diam: 660, color: "w", line: 0, score: 35 },
			{ diam: 670, color: "w", line: 0, score: 34 },
			{ diam: 680, color: "w", line: 0, score: 33 },
			{ diam: 690, color: "w", line: 0, score: 32 },
			{ diam: 700, color: "w", line: 1.5, score: 31 },
			{ diam: 710, color: "w", line: 0, score: 30 },
			{ diam: 720, color: "w", line: 0, score: 29 },
			{ diam: 730, color: "w", line: 0, score: 28 },
			{ diam: 740, color: "w", line: 0, score: 27 },
			{ diam: 750, color: "w", line: 0, score: 26 },
			{ diam: 760, color: "w", line: 0, score: 25 },
			{ diam: 770, color: "w", line: 0, score: 24 },
			{ diam: 780, color: "w", line: 0, score: 23 },
			{ diam: 790, color: "w", line: 0, score: 22 },
			{ diam: 800, color: "w", line: 1.5, score: 21 },
			{ diam: 810, color: "w", line: 0, score: 20 },
			{ diam: 820, color: "w", line: 0, score: 19 },
			{ diam: 830, color: "w", line: 0, score: 18 },
			{ diam: 840, color: "w", line: 0, score: 17 },
			{ diam: 850, color: "w", line: 0, score: 16 },
			{ diam: 860, color: "w", line: 0, score: 15 },
			{ diam: 870, color: "w", line: 0, score: 14 },
			{ diam: 880, color: "w", line: 0, score: 13 },
			{ diam: 890, color: "w", line: 0, score: 12 },
			{ diam: 900, color: "w", line: 1.5, score: 11 },
			{ diam: 910, color: "w", line: 0, score: 10 },
			{ diam: 920, color: "w", line: 0, score: 9 },
			{ diam: 930, color: "w", line: 0, score: 8 },
			{ diam: 940, color: "w", line: 0, score: 7 },
			{ diam: 950, color: "w", line: 0, score: 6 },
			{ diam: 960, color: "w", line: 0, score: 5 },
			{ diam: 970, color: "w", line: 0, score: 4 },
			{ diam: 980, color: "w", line: 0, score: 3 },
			{ diam: 990, color: "w", line: 0, score: 2 },
			{ diam: 1000, color: "w", line: 1.5, score: 1 },
		],

		text: [].concat(text_rings({x: 75*DIAG, y: 75*DIAG}, {x: 50*DIAG, y: 50*DIAG}, 8, 0, {size: 30, color: "gl", angle: 45}))
				.concat(text_rings({x: 75*DIAG, y: -75*DIAG}, {x: 50*DIAG, y: -50*DIAG}, 8, 0, {size: 30, color: "gl", angle: 135}))
				.concat(text_rings({x: -75*DIAG, y: -75*DIAG}, {x: -50*DIAG, y: -50*DIAG}, 8, 0, {size: 30, color: "gl", angle: 225}))
				.concat(text_rings({x: -75*DIAG, y: 75*DIAG}, {x: -50*DIAG, y: 50*DIAG}, 8, 0, {size: 30, color: "gl", angle: 315})),
	};

	targetfaces["SW_A100_200Y"] = {
		name: "Swiss A100 (200y)",
		shortname: "Swiss A100 (200y)",
		dist: 200,
		dist_unit: "y",
		score: [100],
		board: { w: 1300, h: 1300, line: 10, score: 0 },
		rings: [
			{ diam: 0.24/INCH, color: "b", line: 0, score: 100 },
			{ diam: 0.48/INCH, color: "b", line: 0, score: 99 },
			{ diam: 0.72/INCH, color: "b", line: 0, score: 98 },
			{ diam: 0.96/INCH, color: "b", line: 0, score: 97 },
			{ diam: 1.2/INCH, color: "b", line: 1, score: 96 },
			{ diam: 1.44/INCH, color: "b", line: 0, score: 95 },
			{ diam: 1.68/INCH, color: "b", line: 0, score: 94 },
			{ diam: 1.92/INCH, color: "b", line: 0, score: 93 },
			{ diam: 2.16/INCH, color: "b", line: 0, score: 92 },
			{ diam: 2.4/INCH, color: "b", line: 1.5, score: 91 },
			{ diam: 2.64/INCH, color: "b", line: 0, score: 90 },
			{ diam: 2.88/INCH, color: "b", line: 0, score: 89 },
			{ diam: 3.12/INCH, color: "b", line: 0, score: 88 },
			{ diam: 3.36/INCH, color: "b", line: 0, score: 87 },
			{ diam: 3.6/INCH, color: "b", line: 0, score: 86 },
			{ diam: 3.84/INCH, color: "b", line: 0, score: 85 },
			{ diam: 4.08/INCH, color: "b", line: 0, score: 84 },
			{ diam: 4.32/INCH, color: "b", line: 0, score: 83 },
			{ diam: 4.56/INCH, color: "b", line: 0, score: 82 },
			{ diam: 4.8/INCH, color: "b", line: 1.5, score: 81 },
			{ diam: 5.04/INCH, color: "b", line: 0, score: 80 },
			{ diam: 5.28/INCH, color: "b", line: 0, score: 79 },
			{ diam: 5.52/INCH, color: "b", line: 0, score: 78 },
			{ diam: 5.76/INCH, color: "b", line: 0, score: 77 },
			{ diam: 6/INCH, color: "b", line: 0, score: 76 },
			{ diam: 6.24/INCH, color: "b", line: 0, score: 75 },
			{ diam: 6.48/INCH, color: "b", line: 0, score: 74 },
			{ diam: 6.72/INCH, color: "b", line: 0, score: 73 },
			{ diam: 6.96/INCH, color: "b", line: 0, score: 72 },
			{ diam: 7.2/INCH, color: "b", line: 1.5, score: 71 },
			{ diam: 7.44/INCH, color: "b", line: 0, score: 70 },
			{ diam: 7.68/INCH, color: "b", line: 0, score: 69 },
			{ diam: 7.92/INCH, color: "b", line: 0, score: 68 },
			{ diam: 8.16/INCH, color: "b", line: 0, score: 67 },
			{ diam: 8.4/INCH, color: "b", line: 0, score: 66 },
			{ diam: 8.64/INCH, color: "b", line: 0, score: 65 },
			{ diam: 8.88/INCH, color: "b", line: 0, score: 64 },
			{ diam: 9.12/INCH, color: "b", line: 0, score: 63 },
			{ diam: 9.36/INCH, color: "b", line: 0, score: 62 },
			{ diam: 9.6/INCH, color: "b", line: 1.5, score: 61 },
			{ diam: 9.84/INCH, color: "b", line: 0, score: 60 },
			{ diam: 10.08/INCH, color: "b", line: 0, score: 59 },
			{ diam: 10.32/INCH, color: "b", line: 0, score: 58 },
			{ diam: 10.56/INCH, color: "b", line: 0, score: 57 },
			{ diam: 10.8/INCH, color: "b", line: 0, score: 56 },
			{ diam: 11.04/INCH, color: "b", line: 0, score: 55 },
			{ diam: 11.28/INCH, color: "b", line: 0, score: 54 },
			{ diam: 11.52/INCH, color: "b", line: 0, score: 53 },
			{ diam: 11.76/INCH, color: "b", line: 0, score: 52 },
			{ diam: 12/INCH, color: "b", line: 1.5, score: 51 },
			{ diam: 12.24/INCH, color: "b", line: 0, score: 50 },
			{ diam: 12.48/INCH, color: "b", line: 0, score: 49 },
			{ diam: 12.72/INCH, color: "b", line: 0, score: 48 },
			{ diam: 12.96/INCH, color: "b", line: 0, score: 47 },
			{ diam: 13.2/INCH, color: "b", line: 0, score: 46 },
			{ diam: 13.44/INCH, color: "b", line: 0, score: 45 },
			{ diam: 13.68/INCH, color: "b", line: 0, score: 44 },
			{ diam: 13.92/INCH, color: "b", line: 0, score: 43 },
			{ diam: 14.16/INCH, color: "b", line: 0, score: 42 },
			{ diam: 14.4/INCH, color: "b", line: 1.5, score: 41 },
			{ diam: 14.64/INCH, color: "w", line: 0, score: 40 },
			{ diam: 14.88/INCH, color: "w", line: 0, score: 39 },
			{ diam: 15.12/INCH, color: "w", line: 0, score: 38 },
			{ diam: 15.36/INCH, color: "w", line: 0, score: 37 },
			{ diam: 15.6/INCH, color: "w", line: 0, score: 36 },
			{ diam: 15.84/INCH, color: "w", line: 0, score: 35 },
			{ diam: 16.08/INCH, color: "w", line: 0, score: 34 },
			{ diam: 16.32/INCH, color: "w", line: 0, score: 33 },
			{ diam: 16.56/INCH, color: "w", line: 0, score: 32 },
			{ diam: 16.8/INCH, color: "w", line: 1.5, score: 31 },
			{ diam: 17.04/INCH, color: "w", line: 0, score: 30 },
			{ diam: 17.28/INCH, color: "w", line: 0, score: 29 },
			{ diam: 17.52/INCH, color: "w", line: 0, score: 28 },
			{ diam: 17.76/INCH, color: "w", line: 0, score: 27 },
			{ diam: 18/INCH, color: "w", line: 0, score: 26 },
			{ diam: 18.24/INCH, color: "w", line: 0, score: 25 },
			{ diam: 18.48/INCH, color: "w", line: 0, score: 24 },
			{ diam: 18.72/INCH, color: "w", line: 0, score: 23 },
			{ diam: 18.96/INCH, color: "w", line: 0, score: 22 },
			{ diam: 19.2/INCH, color: "w", line: 1.5, score: 21 },
			{ diam: 19.44/INCH, color: "w", line: 0, score: 20 },
			{ diam: 19.68/INCH, color: "w", line: 0, score: 19 },
			{ diam: 19.92/INCH, color: "w", line: 0, score: 18 },
			{ diam: 20.16/INCH, color: "w", line: 0, score: 17 },
			{ diam: 20.4/INCH, color: "w", line: 0, score: 16 },
			{ diam: 20.64/INCH, color: "w", line: 0, score: 15 },
			{ diam: 20.88/INCH, color: "w", line: 0, score: 14 },
			{ diam: 21.12/INCH, color: "w", line: 0, score: 13 },
			{ diam: 21.36/INCH, color: "w", line: 0, score: 12 },
			{ diam: 21.6/INCH, color: "w", line: 1.5, score: 11 },
			{ diam: 21.84/INCH, color: "w", line: 0, score: 10 },
			{ diam: 22.08/INCH, color: "w", line: 0, score: 9 },
			{ diam: 22.32/INCH, color: "w", line: 0, score: 8 },
			{ diam: 22.56/INCH, color: "w", line: 0, score: 7 },
			{ diam: 22.8/INCH, color: "w", line: 0, score: 6 },
			{ diam: 23.04/INCH, color: "w", line: 0, score: 5 },
			{ diam: 23.28/INCH, color: "w", line: 0, score: 4 },
			{ diam: 23.52/INCH, color: "w", line: 0, score: 3 },
			{ diam: 23.76/INCH, color: "w", line: 0, score: 2 },
			{ diam: 24/INCH, color: "w", line: 1.5, score: 1 },
		],
		text: [
		].concat(text_rings({x: (1.8/INCH)*DIAG, y: (1.8/INCH)*DIAG}, {x: (1.2/INCH)*DIAG, y: (1.2/INCH)*DIAG}, 8, 0, {size: 20, color: "gl", angle: 45}))
		.concat(text_rings({x: (1.8/INCH)*DIAG, y: (-1.8/INCH)*DIAG}, {x: (1.2/INCH)*DIAG, y: (-1.2/INCH)*DIAG}, 8, 0, {size: 20, color: "gl", angle: 135}))
		.concat(text_rings({x: (-1.8/INCH)*DIAG, y: (-1.8/INCH)*DIAG}, {x: (-1.2/INCH)*DIAG, y: (-1.2/INCH)*DIAG}, 8, 0, {size: 20, color: "gl", angle: 225}))
		.concat(text_rings({x: (-1.8/INCH)*DIAG, y: (1.8/INCH)*DIAG}, {x: (-1.2/INCH)*DIAG, y: (1.2/INCH)*DIAG}, 8, 0, {size: 20, color: "gl", angle: 315}))

	};

	targetfaces["SW_A5_200Y"] = {
		name: "Swiss A5 (200y)",
		shortname: "Swiss A5 (200y)",
		dist: 200,
		dist_unit: "y",
		score: [5],
		board: {w: 1300, h: 1300, line: 10, score: 0},
		rings: [
			{diam: 4.8/INCH, color: "b", line: 1.5, score: 5},
			{diam: 9.6/INCH, color: "b", line: 1.5, score: 4},
			{diam: 14.4/INCH, color: "b", line: 1.5, score: 3},
			{diam: 19.2/INCH, color: "w", line: 1.5, score: 2},
			{diam: 24/INCH, color: "w", line: 1.5, score: 1}
		],
		text: [
		].concat(text_rings({x: (1.1/INCH)*DIAG, y: (1.1/INCH)*DIAG}, {x: (2.4/INCH)*DIAG, y: (2.4/INCH)*DIAG}, 5, 1, {size: 20, color: "gl", angle: 45}))
		.concat(text_rings({x: (1.1/INCH)*DIAG, y: (-1.1/INCH)*DIAG}, {x: (2.4/INCH)*DIAG, y: (-2.4/INCH)*DIAG}, 5, 1, {size: 20, color: "gl", angle: 135}))
		.concat(text_rings({x: (-1.1/INCH)*DIAG, y: (-1.1/INCH)*DIAG}, {x: (-2.4/INCH)*DIAG, y: (-2.4/INCH)*DIAG}, 5, 1, {size: 20, color: "gl", angle: 225}))
		.concat(text_rings({x: (-1.1/INCH)*DIAG, y: (1.1/INCH)*DIAG}, {x: (-2.4/INCH)*DIAG, y: (2.4/INCH)*DIAG}, 5, 1, {size: 20, color: "gl", angle: 315}))
	};


	targetfaces["NALRSA"] = {
		name: "NALRSA",
		shortname: "NALRSA",
		dist: 1000,
		dist_unit: "y",
		score: [10],
		board: {w: 48/INCH, h: 48/INCH, line: 10, score: 0},
		rings: [	{diam: 3/INCH, color: "b", line: 0, score: 10},
					{diam: 6/INCH, color: "w", line: 0, score: 8},
					{diam: 9/INCH, color: "b", line: 0, score: 6},
					{diam: 12/INCH, color: "w", line: 2, score: 5}
		],
		default_ring_text: true,
	};

	// Norway

	targetfaces["NOR200"] = {
		name: "Norway F-Class 200",
		shortname: "NOR FC 200",
		dist: 200,
		dist_unit: "m",
		score: [10, "X"],
		board: {w: 297, h: 420, line: 2, score: 5},

		rings: [	{diam: 29, color: "w", line: 1, score: "X"},
					{diam: 58, color: "b", line: 1, score: 10},
					{diam: 116, color: "w", line: 1, score: 9},
					{diam: 174, color: "w", line: 1, score: 8},
					{diam: 232, color: "w", line: 1, score: 7},
					{diam: 290, color: "w", line: 1, score: 6}
		],

		text: [
			{x: 0, y: 0, text: "X", size: 20, color: "gl"},
			{x: 0, y: 21, text: "10", size: 12, color: "gl"},
		].concat(text_rings({x: 0, y: 43}, {x: 0, y: 29}, 9, 6, {size: 12, color: "gl"}))

	};

	targetfaces["NOR300"] = {
		name: "Norway F-Class 300",
		shortname: "NOR FC 300",
		dist: 300,
		dist_unit: "m",
		score: [10, "X"],
		board: {w: 460, h: 610, line: 2, score: 5},

		rings: [	{diam: 44, color: "w", line: 1, score: "X"},
					{diam: 88, color: "b", line: 1, score: 10},
					{diam: 176, color: "w", line: 1, score: 9},
					{diam: 264, color: "w", line: 1, score: 8},
					{diam: 352, color: "w", line: 1, score: 7},
					{diam: 440, color: "w", line: 1, score: 6}
		],

		text: [
			{x: 0, y: 0, text: "X", size: 25, color: "gl"},
			{x: 0, y: 32, text: "10", size: 18, color: "gl"},
		].concat(text_rings({x: 0, y: 65}, {x: 0, y: 44}, 9, 6, {size: 18, color: "gl"}))

	};

	targetfaces["NOR500"] = {
		name: "Norway F-Class 500",
		shortname: "NOR FC 500",
		dist: 500,
		dist_unit: "m",
		score: [10, "X"],
		board: {w: 557, h: 642, line: 2, score: 5},

		rings: [	{diam: 73, color: "w", line: 1, score: "X"},
					{diam: 146, color: "b", line: 1, score: 10},
					{diam: 292, color: "w", line: 1, score: 9},
					{diam: 438, color: "w", line: 1, score: 8},
					{diam: 584, color: "w", line: 1, score: 7},
					{diam: 730, color: "w", line: 1, score: 6}
		],

		text: [
			{x: 0, y: 0, text: "X", size: 40, color: "gl"},
			{x: 0, y: 54, text: "10", size: 30, color: "gl"},
		].concat(text_rings({x: 0, y: 108}, {x: 0, y: 73}, 9, 6, {size: 30, color: "gl"}))

	};

	targetfaces["NOR500UNL"] = {
		name: "Norway UNL 500",
		shortname: "NOR UNL 500",
		dist: 500,
		dist_unit: "m",
		score: [10, "X"],
		board: {w: 557, h: 642, line: 2, score: 5},

		rings_top: [	{diam: 32, color: "bl", line: 1, score: "X"}
		],

		poly_top: [		{points: polybox(0, 0, 56, 56), color: "w", line: 0}
		],

		rings: [		{diam: 97, color: "b", line: 1, score: 10},
						{diam: 181, color: "w", line: 1, score: 9},
						{diam: 263, color: "w", line: 1, score: 8},
						{diam: 345, color: "w", line: 1, score: 7},
						{diam: 427, color: "w", line: 1, score: 6},
						{diam: 509, color: "w", line: 1, score: 5}
		],

		poly: [			{points: polybox(0, 198, 60, 60), color: "w", line: 0},
						{points: polybox(0, 198, 130, 130), color: "g", line: 0}
		],

		text: [
			{x: 0, y: 0, text: "X", size: 30, color: "gl"},
			{x: 0, y: 37, text: "10", size: 20, color: "gl"},
			{x: 0, y: 67, text: "9", size: 20, color: "gl"},
			{x: 0, y: 108, text: "8", size: 20, color: "gl"},
			{x: 0, y: 149, text: "7", size: 20, color: "wl"},
			{x: 0, y: 190, text: "6", size: 20, color: "gl"},
			{x: 0, y: 240, text: "5", size: 20, color: "wl"},
		]

	};


	targetfaces["NOR1000"] = {
		name: "Norway F-Class 1000",
		shortname: "NOR FC 1000",
		dist: 1000,
		dist_unit: "m",
		score: [10, "X"],
		board: {w: 1114, h: 1284, line: 4, score: 5},

		rings: [	{diam: 146, color: "w", line: 2, score: "X"},
					{diam: 292, color: "b", line: 2, score: 10},
					{diam: 584, color: "w", line: 2, score: 9},
					{diam: 876, color: "w", line: 2, score: 8},
					{diam: 1168, color: "w", line: 2, score: 7},
					{diam: 1460, color: "w", line: 2, score: 6}
		],

		text: [
			{x: 0, y: 0, text: "X", size: 80, color: "gl"},
			{x: 0, y: 108, text: "10", size: 60, color: "gl"},
		].concat(text_rings({x: 0, y: 216}, {x: 0, y: 146}, 9, 6, {size: 60, color: "gl"}))

	};
	
	// MSSA Core, Mini-Core

	targetfaces["SSAACore"] = {
		name: "SSAA Core",
		shortname: "SSAA Core",
		dist: 600,
		dist_unit: "m",
		score: [5, "V"],
		board: {w: 1200, h: 1200, line: 20, score: 1},
		rings: [	{diam: 150, color: "b", line: 4, score: "V"},
					{diam: 300, color: "b", line: 4, score: 5},
					{diam: 600, color: "w", line: 4, score: 4},
					{diam: 900, color: "w", line: 4, score: 3},
					{diam: 1200, color: "w", line: 4, score: 2}
		],
		default_ring_text: true,
	};
	
	targetfaces["SSAAMiniCore"] = {
		name: "SSAA Mini Core",
		shortname: "SSAA Mini Core",
		dist: 400,
		dist_unit: "m",
		score: [5, "V"],
		board: {w: 600, h: 600, line: 10, score: 1},
		rings: [	{diam: 75, color: "b", line: 2, score: "V"},
					{diam: 150, color: "b", line: 2, score: 5},
					{diam: 300, color: "w", line: 2, score: 4},
					{diam: 450, color: "w", line: 2, score: 3},
					{diam: 600, color: "w", line: 2, score: 2}
		],
		default_ring_text: true,
	};
	
	
	// American S1 sight in

	targetfaces["AmericanS1"] = {
		name: "American S-1",
		shortname: "American S-1",
		dist: 100,
		dist_unit: "y",
		board: {w: 360, h: 360, line: 3},

		rings: [	{diam: 2/INCH, color: "w", line: 1.5},
					{diam: 2.75/INCH, color: "b", line: 1.5},
					{diam: 4/INCH, color: "b", line: 1.5},
					{diam: 6/INCH, color: "b", line: 1.5},
					{diam: 8/INCH, color: "w", line: 1.5},
					{diam: 10/INCH, color: "w", line: 1.5},
					{diam: 12/INCH, color: "w", line: 1.5}
		],
		
		poly_top: [

			{points: [{x: -5/INCH, y: -5/INCH}, {x: 5/INCH, y: -5/INCH}], color: "gl", line: 0.5},
			{points: [{x: -5/INCH, y: -4/INCH}, {x: 5/INCH, y: -4/INCH}], color: "gl", line: 0.5},
			{points: [{x: -5/INCH, y: -3/INCH}, {x: 5/INCH, y: -3/INCH}], color: "gl", line: 0.5},
			{points: [{x: -5/INCH, y: -2/INCH}, {x: 5/INCH, y: -2/INCH}], color: "gl", line: 0.5},
			{points: [{x: -5/INCH, y: -1/INCH}, {x: 5/INCH, y: -1/INCH}], color: "gl", line: 0.5},
			{points: [{x: -5/INCH, y: 0/INCH}, {x: 5/INCH, y: 0/INCH}], color: "gl", line: 0.5},
			{points: [{x: -5/INCH, y: 1/INCH}, {x: 5/INCH, y: 1/INCH}], color: "gl", line: 0.5},
			{points: [{x: -5/INCH, y: 2/INCH}, {x: 5/INCH, y: 2/INCH}], color: "gl", line: 0.5},
			{points: [{x: -5/INCH, y: 3/INCH}, {x: 5/INCH, y: 3/INCH}], color: "gl", line: 0.5},
			{points: [{x: -5/INCH, y: 4/INCH}, {x: 5/INCH, y: 4/INCH}], color: "gl", line: 0.5},
			{points: [{x: -5/INCH, y: 5/INCH}, {x: 5/INCH, y: 5/INCH}], color: "gl", line: 0.5},

			{points: [{x: -5/INCH, y: -5/INCH}, {x: -5/INCH, y: 5/INCH}], color: "gl", line: 0.5},
			{points: [{x: -4/INCH, y: -5/INCH}, {x: -4/INCH, y: 5/INCH}], color: "gl", line: 0.5},
			{points: [{x: -3/INCH, y: -5/INCH}, {x: -3/INCH, y: 5/INCH}], color: "gl", line: 0.5},
			{points: [{x: -2/INCH, y: -5/INCH}, {x: -2/INCH, y: 5/INCH}], color: "gl", line: 0.5},
			{points: [{x: -1/INCH, y: -5/INCH}, {x: -1/INCH, y: 5/INCH}], color: "gl", line: 0.5},
			{points: [{x: 0/INCH, y: -5/INCH}, {x: 0/INCH, y: 5/INCH}], color: "gl", line: 0.5},
			{points: [{x: 1/INCH, y: -5/INCH}, {x: 1/INCH, y: 5/INCH}], color: "gl", line: 0.5},
			{points: [{x: 2/INCH, y: -5/INCH}, {x: 2/INCH, y: 5/INCH}], color: "gl", line: 0.5},
			{points: [{x: 3/INCH, y: -5/INCH}, {x: 3/INCH, y: 5/INCH}], color: "gl", line: 0.5},
			{points: [{x: 4/INCH, y: -5/INCH}, {x: 4/INCH, y: 5/INCH}], color: "gl", line: 0.5},
			{points: [{x: 5/INCH, y: -5/INCH}, {x: 5/INCH, y: 5/INCH}], color: "gl", line: 0.5},
		]

	};

	// Austria 600m for Tom Karner
	targetfaces["AT_600"] = {
		name: "Austria 600",
		shortname: "Austria 600",
		dist: 600,
		dist_unit: "m",
		score: [10],
		board: {w: 800, h: 800, line: 1, score: 0},
		rings: [	{diam: 0.5*174.6, color: "b", line: 2, score: 10},
					{diam: 1.0*174.6, color: "g", line: 2, score: 9},
					{diam: 1.5*174.6, color: "b", line: 2, score: 8},
					{diam: 2.0*174.6, color: "w", line: 2, score: 7},
					{diam: 2.5*174.6, color: "w", line: 2, score: 6},
		],
	};
	
	// scaled NRA LR for practice
	targetfaces["NRA_LR_800"] = {
		name: "NRA LR at 0.8 Scale",
		shortname: "NRA LR x0.8",
		dist: 800,
		dist_unit: "y",
		score: [10, "X"],
		board: {w: 72*0.8/INCH, h: 72*0.8/INCH, line: 20*0.8, score: 6},
		rings: [	{diam: 10*0.8/INCH, color: "b", line: 10*0.8, score: "X"},
					{diam: 20*0.8/INCH, color: "b", line: 10*0.8, score: 10},
					{diam: 30*0.8/INCH, color: "b", line: 10*0.8, score: 9},
					{diam: 44*0.8/INCH, color: "b", line: 10*0.8, score: 8},
					{diam: 60*0.8/INCH, color: "w", line: 10*0.8, score: 7},
		],
		default_ring_text: true,
	};

	targetfaces["NRA_LRFC_800"] = {
		name: "NRA LFRC at 0.8 Scale",
		shortname: "NRA LRFC x0.8",
		dist: 800,
		dist_unit: "y",
		score: [10, "X"],
		board: {w: 72*0.8/INCH, h: 72*0.8/INCH, line: 20*0.8, score: 5},
		rings: [	{diam: 5*0.8/INCH, color: "b", line: 5*0.8, score: "X"},
					{diam: 10*0.8/INCH, color: "b", line: 10*0.8, score: 10},
					{diam: 20*0.8/INCH, color: "b", line: 10*0.8, score: 9},
					{diam: 30*0.8/INCH, color: "b", line: 10*0.8, score: 8},
					{diam: 44*0.8/INCH, color: "b", line: 10*0.8, score: 7},
					{diam: 60*0.8/INCH, color: "w", line: 10*0.8, score: 6}
		],
		default_ring_text: true,
	};
	
	targetfaces["FCSA_MR1"] = {
		name: "FCSA MR-1",
		shortname: "FCSA MR-1",
		dist: 1000,
		dist_unit: "y",
		score: [10, "X"],
		board: {w: 72/INCH, h: 67/INCH, line: 20},
		rings: [	{diam: 6/INCH, color: "b", line: 8, score: "X"},
					{diam: 12/INCH, color: "b", line: 8, score: 10},
					{diam: 18/INCH, color: "b", line: 8, score: 9},
					{diam: 24/INCH, color: "b", line: 8, score: 8},
					{diam: 36/INCH, color: "w", line: 8, score: 7},
					{diam: 48/INCH, color: "w", line: 8, score: 6},
					{diam: 60/INCH, color: "w", line: 8, score: 5}
		],
		poly_top: [
			{points: polybox(0, 0, 3/INCH, 3/INCH), color: "w", line: 0},
		],
		
		default_ring_text: true,
	};

	targetfaces["NRA_MR1_400"] = {
		name: "NRA MR-1 at 2/3 Scale",
		shortname: "MR-1 x2/3",
		dist: 400,
		dist_unit: "y",
		score: [10, "X"],
		board: {w: 1800, h: 1800, line: 20},
		rings: [	{diam: 4/INCH, color: "b", line: 6, score: "X"},
					{diam: 8/INCH, color: "b", line: 6, score: 10},
					{diam: 12/INCH, color: "b", line: 6, score: 9},
					{diam: 16/INCH, color: "b", line: 6, score: 8},
					{diam: 24/INCH, color: "b", line: 6, score: 7},
					{diam: 32/INCH, color: "w", line: 6, score: 6},
					{diam: 40/INCH, color: "w", line: 6, score: 5}
		],
		default_ring_text: true,
	};
	

	// NRA smallbore 100yd
	targetfaces["NRA_A33"] = {
		name: "NRA A-33",
		shortname: "NRA A-33",
		dist: 100,
		dist_unit: "y",
		score: [10],
		board: {w: 331, h: 1027, line: 5, score: 0},
		
		force_colors: true,

		rings: [
					{diam: 1.045/INCH, color: "b", line: 1, score: 10},
					{diam: 2.245/INCH, color: "b", line: 1, score: 9},
					{diam: 3.445/INCH, color: "b", line: 1, score: 8},
					{diam: 4.645/INCH, color: "b", line: 1, score: 7},
					{diam: 5.845/INCH, color: "b", line: 1, score: 6},
					{diam: 7.045/INCH, color: "b", line: 1, score: 5},
					{diam: 8.245/INCH, color: "b", line: 1, score: 4},
					{diam: 9.445/INCH, color: "w", line: 1, score: 3},
					{diam: 10.645/INCH, color: "w", line: 1, score: 2},
					{diam: 11.845/INCH, color: "w", line: 1, score: 1},
		],

	};
	
	// Australian Match Rifle
	
	targetfaces["AU_MR"] = {
		name: "Australian Match Rifle",
		shortname: "Australian MR",
		dist: 1000,
		dist_unit: "y",
		score: [5, "V"],
		board: {w: 2400, h: 1800, line: 10, score: 2},
		rings: [	{diam: 305, color: "b", line: 10, score: "V"},
					{diam: 610, color: "b", line: 10, score: 5},
					{diam: 1020, color: "b", line: 0, score: 4},
					{diam: 1220, color: "w", line: 10, score: 4},
					{diam: 1800, color: "w", line: 10, score: 3}
		],
	};
	
	targetfaces["AU_MRFC"] = {
		name: "Australian Match Rifle FC)",
		shortname: "Australian MR (FC)",
		dist: 1000,
		dist_unit: "y",
		score: [6, "X"],
		board: {w: 2400, h: 1800, line: 10, score: 2},
		rings: [	{diam: 127, color: "b", line: 10, score: "X"},
					{diam: 305, color: "b", line: 10, score: 6},
					{diam: 610, color: "b", line: 10, score: 5},
					{diam: 1020, color: "b", line: 0, score: 4},
					{diam: 1220, color: "w", line: 10, score: 4},
					{diam: 1800, color: "w", line: 10, score: 3}
		],
	};


	// NRA High Power / International

	targetfaces["NRA_C1"] = {
		name: "NRA C-1",
		shortname: "C-1 (300m)",
		dist: 300,
		dist_unit: "m",
		score: [10, "X"],
		board: {w: 1300, h: 1300, line: 10, score: 0},

		rings: [	{diam: 50, color: "b", line: 1.5, score: "X"},
					{diam: 100, color: "b", line: 1.5, score: 10},
					{diam: 200, color: "b", line: 1.5, score: 9},
					{diam: 300, color: "b", line: 1.5, score: 8},
					{diam: 400, color: "b", line: 1.5, score: 7},
					{diam: 500, color: "b", line: 1.5, score: 6},
					{diam: 600, color: "b", line: 1.5, score: 5},
					{diam: 700, color: "w", line: 1.5, score: 4},
					{diam: 800, color: "w", line: 1.5, score: 3},
					{diam: 900, color: "w", line: 1.5, score: 2},
					{diam: 1000, color: "w", line: 1.5, score: 1}
		],

		text: [
		].concat(text_rings({x: 75*DIAG, y: 75*DIAG}, {x: 50*DIAG, y: 50*DIAG}, 9, 1, {size: 30, color: "gl", angle: 45}))
		.concat(text_rings({x: 75*DIAG, y: -75*DIAG}, {x: 50*DIAG, y: -50*DIAG}, 9, 1, {size: 30, color: "gl", angle: 135}))
		.concat(text_rings({x: -75*DIAG, y: -75*DIAG}, {x: -50*DIAG, y: -50*DIAG}, 9, 1, {size: 30, color: "gl", angle: 225}))
		.concat(text_rings({x: -75*DIAG, y: 75*DIAG}, {x: -50*DIAG, y: 50*DIAG}, 9, 1, {size: 30, color: "gl", angle: 315}))

	};

	targetfaces["NRA_C2"] = {
		name: "NRA C-2",
		shortname: "C-2 (200y)",
		dist: 200,
		dist_unit: "y",
		score: [10, "X"],
		board: {w: 1300, h: 1300, line: 10, score: 0},

		rings: [	{diam: 1.2/INCH, color: "b", line: 1.5, score: "X"},
					{diam: 2.4/INCH, color: "b", line: 1.5, score: 10},
					{diam: 4.8/INCH, color: "b", line: 1.5, score: 9},
					{diam: 7.2/INCH, color: "b", line: 1.5, score: 8},
					{diam: 9.6/INCH, color: "b", line: 1.5, score: 7},
					{diam: 12/INCH, color: "b", line: 1.5, score: 6},
					{diam: 14.4/INCH, color: "b", line: 1.5, score: 5},
					{diam: 16.8/INCH, color: "w", line: 1.5, score: 4},
					{diam: 19.2/INCH, color: "w", line: 1.5, score: 3},
					{diam: 21.6/INCH, color: "w", line: 1.5, score: 2},
					{diam: 24/INCH, color: "w", line: 1.5, score: 1}
		],

		text: [
		].concat(text_rings({x: (1.8/INCH)*DIAG, y: (1.8/INCH)*DIAG}, {x: (1.2/INCH)*DIAG, y: (1.2/INCH)*DIAG}, 9, 1, {size: 20, color: "gl", angle: 45}))
		.concat(text_rings({x: (1.8/INCH)*DIAG, y: (-1.8/INCH)*DIAG}, {x: (1.2/INCH)*DIAG, y: (-1.2/INCH)*DIAG}, 9, 1, {size: 20, color: "gl", angle: 135}))
		.concat(text_rings({x: (-1.8/INCH)*DIAG, y: (-1.8/INCH)*DIAG}, {x: (-1.2/INCH)*DIAG, y: (-1.2/INCH)*DIAG}, 9, 1, {size: 20, color: "gl", angle: 225}))
		.concat(text_rings({x: (-1.8/INCH)*DIAG, y: (1.8/INCH)*DIAG}, {x: (-1.2/INCH)*DIAG, y: (1.2/INCH)*DIAG}, 9, 1, {size: 20, color: "gl", angle: 315}))

	};

	targetfaces["NRA_C3"] = {
		name: "NRA C-3",
		shortname: "C-3 (300y)",
		dist: 300,
		dist_unit: "y",
		score: [10, "X"],
		board: {w: 1300, h: 1300, line: 10, score: 0},

		rings: [	{diam: 1.8/INCH, color: "b", line: 1.5, score: "X"},
					{diam: 3.6/INCH, color: "b", line: 1.5, score: 10},
					{diam: 7.2/INCH, color: "b", line: 1.5, score: 9},
					{diam: 10.8/INCH, color: "b", line: 1.5, score: 8},
					{diam: 14.4/INCH, color: "b", line: 1.5, score: 7},
					{diam: 18/INCH, color: "b", line: 1.5, score: 6},
					{diam: 21.6/INCH, color: "b", line: 1.5, score: 5},
					{diam: 25.2/INCH, color: "w", line: 1.5, score: 4},
					{diam: 28.8/INCH, color: "w", line: 1.5, score: 3},
					{diam: 32.4/INCH, color: "w", line: 1.5, score: 2},
					{diam: 36/INCH, color: "w", line: 1.5, score: 1}
		],

		text: [
		].concat(text_rings({x: (2.7/INCH)*DIAG, y: (2.7/INCH)*DIAG}, {x: (1.8/INCH)*DIAG, y: (1.8/INCH)*DIAG}, 9, 1, {size: 30, color: "gl", angle: 45}))
		.concat(text_rings({x: (2.7/INCH)*DIAG, y: (-2.7/INCH)*DIAG}, {x: (1.8/INCH)*DIAG, y: (-1.8/INCH)*DIAG}, 9, 1, {size: 30, color: "gl", angle: 135}))
		.concat(text_rings({x: (-2.7/INCH)*DIAG, y: (-2.7/INCH)*DIAG}, {x: (-1.8/INCH)*DIAG, y: (-1.8/INCH)*DIAG}, 9, 1, {size: 30, color: "gl", angle: 225}))
		.concat(text_rings({x: (-2.7/INCH)*DIAG, y: (2.7/INCH)*DIAG}, {x: (-1.8/INCH)*DIAG, y: (1.8/INCH)*DIAG}, 9, 1, {size: 30, color: "gl", angle: 315}))

	};

	targetfaces["NRA_SR1"] = {
		name: "NRA SR-1",
		shortname: "SR-1 (100)",
		dist: 100,
		dist_unit: "y",
		score: [10, "X"],
		board: {w: 1200, h: 1200, line: 20},
		rings: [	{diam: 1.35/INCH, color: "b", line: 1, score: "X"},
					{diam: 3.35/INCH, color: "b", line: 2, score: 10},
					{diam: 6.35/INCH, color: "b", line: 2, score: 9},
					{diam: 9.35/INCH, color: "w", line: 2, score: 8},
					{diam: 12.35/INCH, color: "w", line: 2, score: 7},
					{diam: 15.35/INCH, color: "w", line: 2, score: 6},
					{diam: 18.35/INCH, color: "w", line: 2, score: 5}
		],
		default_ring_text: true,
	};

	targetfaces["NRA_SR21"] = {
		name: "NRA SR-21",
		shortname: "SR-21 (100)",
		dist: 100,
		dist_unit: "y",
		score: [10, "X"],
		board: {w: 1200, h: 1200, line: 20},
		rings: [	{diam: 0.79/INCH, color: "b", line: 1, score: "X"},
					{diam: 2.12/INCH, color: "b", line: 2, score: 10},
					{diam: 4.12/INCH, color: "b", line: 2, score: 9},
					{diam: 6.12/INCH, color: "b", line: 2, score: 8},
					{diam: 8.12/INCH, color: "w", line: 2, score: 7},
					{diam: 10.12/INCH, color: "w", line: 2, score: 6},
					{diam: 12.12/INCH, color: "w", line: 2, score: 5}
		],
		default_ring_text: true,
	};

	targetfaces["NRA_MR31"] = {
		name: "NRA MR-31",
		shortname: "MR-31 (100)",
		dist: 100,
		dist_unit: "y",
		score: [10, "X"],
		board: {w: 1200, h: 1200, line: 20},
		rings: [	{diam: 0.75/INCH, color: "b", line: 1, score: "X"},
					{diam: 1.75/INCH, color: "b", line: 2, score: 10},
					{diam: 2.75/INCH, color: "b", line: 2, score: 9},
					{diam: 3.75/INCH, color: "b", line: 2, score: 8},
					{diam: 5.75/INCH, color: "b", line: 2, score: 7},
					{diam: 7.75/INCH, color: "w", line: 2, score: 6},
					{diam: 9.75/INCH, color: "w", line: 2, score: 5}
		],
		default_ring_text: true,
	};

	targetfaces["NRA_SR"] = {
		name: "NRA SR",
		shortname: "SR (200)",
		dist: 200,
		dist_unit: "y",
		score: [10, "X"],
		board: {w: 1200, h: 1200, line: 20},
		rings: [	{diam: 3/INCH, color: "b", line: 0.182/INCH, score: "X"},
					{diam: 7/INCH, color: "b", line: 0.182/INCH, score: 10},
					{diam: 13/INCH, color: "b", line: 0.182/INCH, score: 9},
					{diam: 19/INCH, color: "w", line: 0.182/INCH, score: 8},
					{diam: 25/INCH, color: "w", line: 0.182/INCH, score: 7},
					{diam: 31/INCH, color: "w", line: 0.182/INCH, score: 6},
					{diam: 37/INCH, color: "w", line: 0.182/INCH, score: 5}
		],
		default_ring_text: true,
	};

	targetfaces["NRA_SR42"] = {
		name: "NRA SR-42",
		shortname: "SR-42 (200)",
		dist: 200,
		dist_unit: "y",
		score: [10, "X"],
		board: {w: 1200, h: 1200, line: 20},
		rings: [	{diam: 1.9/INCH, color: "b", line: 2, score: "X"},
					{diam: 4.56/INCH, color: "b", line: 4, score: 10},
					{diam: 8.56/INCH, color: "b", line: 4, score: 9},
					{diam: 12.56/INCH, color: "b", line: 4, score: 8},
					{diam: 16.56/INCH, color: "w", line: 4, score: 7},
					{diam: 20.56/INCH, color: "w", line: 4, score: 6},
					{diam: 24.56/INCH, color: "w", line: 4, score: 5}
		],
		default_ring_text: true,
	};

	targetfaces["NRA_MR52"] = {
		name: "NRA MR-52",
		shortname: "MR-52 (200)",
		dist: 200,
		dist_unit: "y",
		score: [10, "X"],
		board: {w: 1200, h: 1200, line: 20},
		rings: [	{diam: 1.79/INCH, color: "b", line: 2, score: "X"},
					{diam: 3.79/INCH, color: "b", line: 4, score: 10},
					{diam: 5.79/INCH, color: "b", line: 4, score: 9},
					{diam: 7.79/INCH, color: "b", line: 4, score: 8},
					{diam: 11.79/INCH, color: "b", line: 4, score: 7},
					{diam: 15.79/INCH, color: "w", line: 4, score: 6},
					{diam: 19.79/INCH, color: "w", line: 4, score: 5}
		],
		default_ring_text: true,
	};

	targetfaces["NRA_SR5"] = {
		name: "NRA SR-5",
		shortname: "SR-5 (200)",
		dist: 200,
		dist_unit: "y",
		score: [10, "X"],
		board: {w: 1200, h: 1200, line: 20},
		rings: [	{diam: 3/INCH, color: "b", line: 2, score: "X"},
					{diam: 7/INCH, color: "b", line: 4, score: 10},
					{diam: 13/INCH, color: "b", line: 4, score: 9},
					{diam: 19/INCH, color: "w", line: 4, score: 8},
					{diam: 25/INCH, color: "w", line: 4, score: 7},
		],
		default_ring_text: true,
	};

	targetfaces["NRA_SR3"] = {
		name: "NRA SR-3",
		shortname: "SR-3 (300)",
		dist: 300,
		dist_unit: "y",
		score: [10, "X"],
		board: {w: 1200, h: 1200, line: 20},
		rings: [	{diam: 3/INCH, color: "b", line: 0.25/INCH, score: "X"},
					{diam: 7/INCH, color: "b", line: 0.25/INCH, score: 10},
					{diam: 13/INCH, color: "b", line: 0.25/INCH, score: 9},
					{diam: 19/INCH, color: "b", line: 0.25/INCH, score: 8},
					{diam: 25/INCH, color: "w", line: 0.25/INCH, score: 7},
					{diam: 31/INCH, color: "w", line: 0.25/INCH, score: 6},
					{diam: 37/INCH, color: "w", line: 0.25/INCH, score: 5}
		],
		default_ring_text: true,
	};

	targetfaces["NRA_MR63"] = {
		name: "NRA MR-63",
		shortname: "MR-63 (300)",
		dist: 300,
		dist_unit: "y",
		score: [10, "X"],
		board: {w: 1200, h: 1200, line: 20},
		rings: [	{diam: 2.85/INCH, color: "b", line: 3, score: "X"},
					{diam: 5.85/INCH, color: "b", line: 6, score: 10},
					{diam: 8.85/INCH, color: "b", line: 6, score: 9},
					{diam: 11.85/INCH, color: "b", line: 6, score: 8},
					{diam: 17.85/INCH, color: "b", line: 6, score: 7},
					{diam: 23.85/INCH, color: "w", line: 6, score: 6},
					{diam: 29.85/INCH, color: "w", line: 6, score: 5}
		],
		default_ring_text: true,
	};

	targetfaces["NRA_MR63FC"] = {
		name: "NRA MR-63FC",
		shortname: "MR-63FC (300)",
		dist: 300,
		dist_unit: "y",
		score: [10, "X"],
		board: {w: 1200, h: 1200, line: 20},
		rings: [	{diam: 1.42/INCH, color: "b", line: 3, score: "X"},
					{diam: 2.85/INCH, color: "b", line: 6, score: 10},
					{diam: 5.85/INCH, color: "b", line: 6, score: 9},
					{diam: 8.85/INCH, color: "b", line: 6, score: 8},
					{diam: 11.85/INCH, color: "b", line: 6, score: 7},
					{diam: 17.85/INCH, color: "b", line: 6, score: 6},
					{diam: 23.85/INCH, color: "w", line: 6, score: 5}
		],
		default_ring_text: true,
	};

	targetfaces["NRA_MR"] = {
		name: "NRA MR",
		shortname: "MR (500)",
		dist: 500,
		dist_unit: "y",
		score: [10, "X"],
		board: {w: 1800, h: 1800, line: 20},
		rings: [	{diam: 5/INCH, color: "b", line: 8, score: "X"},
					{diam: 10/INCH, color: "b", line: 8, score: 10},
					{diam: 15/INCH, color: "b", line: 8, score: 9},
					{diam: 20/INCH, color: "b", line: 8, score: 8},
					{diam: 25/INCH, color: "b", line: 8, score: 7},
					{diam: 30/INCH, color: "b", line: 8, score: 6},
					{diam: 36/INCH, color: "w", line: 8, score: 5}
		],
		default_ring_text: true,
	};

	targetfaces["NRA_MR65FC"] = {
		name: "NRA MR-65FC",
		shortname: "MR-65FC (500)",
		dist: 500,
		dist_unit: "y",
		score: [10, "X"],
		board: {w: 1800, h: 1800, line: 20},
		rings: [	{diam: 2.5/INCH, color: "b", line: 4, score: "X"},
					{diam: 5/INCH, color: "b", line: 8, score: 10},
					{diam: 10/INCH, color: "b", line: 8, score: 9},
					{diam: 15/INCH, color: "b", line: 8, score: 8},
					{diam: 20/INCH, color: "b", line: 8, score: 7},
					{diam: 25/INCH, color: "b", line: 8, score: 6},
					{diam: 30/INCH, color: "b", line: 8, score: 5}
		],
		default_ring_text: true,
	};

	targetfaces["NRA_MR1"] = {
		name: "NRA MR-1",
		shortname: "MR-1 (600)",
		dist: 600,
		dist_unit: "y",
		score: [10, "X"],
		board: {w: 1800, h: 1800, line: 20},
		rings: [	{diam: 6/INCH, color: "b", line: 8, score: "X"},
					{diam: 12/INCH, color: "b", line: 8, score: 10},
					{diam: 18/INCH, color: "b", line: 8, score: 9},
					{diam: 24/INCH, color: "b", line: 8, score: 8},
					{diam: 36/INCH, color: "b", line: 8, score: 7},
					{diam: 48/INCH, color: "w", line: 8, score: 6},
					{diam: 60/INCH, color: "w", line: 8, score: 5}
		],
		default_ring_text: true,
	};

	targetfaces["NRA_MR1FC"] = {
		name: "NRA MR-1FC",
		shortname: "MR-1FC (600)",
		dist: 600,
		dist_unit: "y",
		score: [10, "X"],
		board: {w: 1800, h: 1800, line: 20},
		rings: [	{diam: 3/INCH, color: "b", line: 4, score: "X"},
					{diam: 6/INCH, color: "b", line: 8, score: 10},
					{diam: 12/INCH, color: "b", line: 8, score: 9},
					{diam: 18/INCH, color: "b", line: 8, score: 8},
					{diam: 24/INCH, color: "b", line: 8, score: 7},
					{diam: 36/INCH, color: "b", line: 8, score: 6},
					{diam: 48/INCH, color: "w", line: 8, score: 5}
		],
		default_ring_text: true,
	};

	targetfaces["NRA_MR1FCA"] = {
		name: "NRA MR-1FCA",
		shortname: "MR-1FCA (600)",
		dist: 600,
		dist_unit: "y",
		score: [10, "X"],
		board: {w: 1800, h: 1800, line: 20},
		rings: [	{diam: 3/INCH, color: "b", line: 4, score: "X"},
					{diam: 6/INCH, color: "b", line: 8, score: 10},
					{diam: 12/INCH, color: "b", line: 8, score: 9},
					{diam: 18/INCH, color: "b", line: 8, score: 8},
					{diam: 24/INCH, color: "b", line: 8, score: 7},
					{diam: 30/INCH, color: "b", line: 8, score: 6},
					{diam: 36/INCH, color: "b", line: 8, score: 5}
		],
		default_ring_text: true,
	};

	targetfaces["NRA_LR"] = {
		name: "NRA Long Range",
		shortname: "LR (800-1000)",
		dist: 1000,
		dist_unit: "y",
		score: [10, "X"],
		board: {w: 72/INCH, h: 72/INCH, line: 20, score: 6},
		rings: [	{diam: 10/INCH, color: "b", line: 10, score: "X"},
					{diam: 20/INCH, color: "b", line: 10, score: 10},
					{diam: 30/INCH, color: "b", line: 10, score: 9},
					{diam: 44/INCH, color: "b", line: 10, score: 8},
					{diam: 60/INCH, color: "w", line: 10, score: 7},
		],
		default_ring_text: true,
	};

	targetfaces["NRA_LRFC"] = {
		name: "NRA Long Range FC",
		shortname: "LRFC (800-1000)",
		dist: 1000,
		dist_unit: "y",
		score: [10, "X"],
		board: {w: 72/INCH, h: 72/INCH, line: 20, score: 5},
		rings: [	{diam: 5/INCH, color: "b", line: 5, score: "X"},
					{diam: 10/INCH, color: "b", line: 10, score: 10},
					{diam: 20/INCH, color: "b", line: 10, score: 9},
					{diam: 30/INCH, color: "b", line: 10, score: 8},
					{diam: 44/INCH, color: "b", line: 10, score: 7},
					{diam: 60/INCH, color: "w", line: 10, score: 6}
		],
		default_ring_text: true,
	};




	// ICFRA F-Class 2014 (V)

	targetfaces["IF300y"] = {
		name: "ICFRA F-Class 300y",
		shortname: "FC 300y",
		dist: 300,
		dist_unit: "y",
		score: [5, "V"],
		board: {w: 1200, h: 1200, line: 20, score: 1},
		rings: [	{diam: 32, color: "b", line: 2, score: "V"},
					{diam: 65, color: "b", line: 4, score: 5},
					{diam: 130, color: "b", line: 4, score: 4},
					{diam: 260, color: "b", line: 4, score: 3},
					{diam: 390, color: "b", line: 4, score: 2},
					{diam: 560, color: "b", line: 0, score: 1}
		],
		default_ring_text: true,
	};

	targetfaces["IF300m"] = {
		name: "ICFRA F-Class 300m",
		shortname: "FC 300m",
		dist: 300,
		dist_unit: "m",
		score: [5, "V"],
		board: {w: 1200, h: 1200, line: 20, score: 1},
		rings: [	{diam: 35, color: "b", line: 2, score: "V"},
					{diam: 70, color: "b", line: 4, score: 5},
					{diam: 140, color: "b", line: 4, score: 4},
					{diam: 280, color: "b", line: 4, score: 3},
					{diam: 420, color: "b", line: 4, score: 2},
					{diam: 600, color: "b", line: 0, score: 1}
		],
		default_ring_text: true,
	};

	targetfaces["IF400y"] = {
		name: "ICFRA F-Class 400y",
		shortname: "FC 400y",
		dist: 400,
		dist_unit: "y",
		score: [5, "V"],
		board: {w: 1800, h: 1800, line: 20, score: 1},
		rings: [	{diam: 43, color: "b", line: 2, score: "V"},
					{diam: 85, color: "b", line: 4, score: 5},
					{diam: 175, color: "b", line: 4, score: 4},
					{diam: 350, color: "b", line: 4, score: 3},
					{diam: 520, color: "b", line: 4, score: 2},
					{diam: 745, color: "b", line: 0, score: 1}
		],
		default_ring_text: true,
	};

	targetfaces["IF400m"] = {
		name: "ICFRA F-Class 400m",
		shortname: "FC 400m",
		dist: 400,
		dist_unit: "m",
		score: [5, "V"],
		board: {w: 1800, h: 1800, line: 20, score: 1},
		rings: [	{diam: 47, color: "b", line: 2, score: "V"},
					{diam: 95, color: "b", line: 4, score: 5},
					{diam: 185, color: "b", line: 4, score: 4},
					{diam: 375, color: "b", line: 4, score: 3},
					{diam: 560, color: "b", line: 4, score: 2},
					{diam: 800, color: "b", line: 0, score: 1}
		],
		default_ring_text: true,
	};

	targetfaces["IF500y"] = {
		name: "ICFRA F-Class 500y",
		shortname: "FC 500y",
		dist: 500,
		dist_unit: "y",
		score: [5, "V"],
		board: {w: 1800, h: 1800, line: 20, score: 1},
		rings: [	{diam: 65, color: "b", line: 3, score: "V"},
					{diam: 130, color: "b", line: 6, score: 5},
					{diam: 260, color: "b", line: 6, score: 4},
					{diam: 600, color: "b", line: 6, score: 3},
					{diam: 915, color: "b", line: 0, score: 2}
		],
		default_ring_text: true,
	};

	targetfaces["IF500m"] = {
		name: "ICFRA F-Class 500m",
		shortname: "FC 500m",
		dist: 500,
		dist_unit: "m",
		score: [5, "V"],
		board: {w: 1800, h: 1800, line: 20, score: 1},
		rings: [	{diam: 72, color: "b", line: 3, score: "V"},
					{diam: 145, color: "b", line: 6, score: 5},
					{diam: 290, color: "b", line: 6, score: 4},
					{diam: 660, color: "b", line: 6, score: 3},
					{diam: 1000, color: "b", line: 0, score: 2}
		],
		default_ring_text: true,
	};

	targetfaces["IF600y"] = {
		name: "ICFRA F-Class 600y",
		shortname: "FC 600y",
		dist: 600,
		dist_unit: "y",
		score: [5, "V"],
		board: {w: 1800, h: 1800, line: 20, score: 1},
		rings: [	{diam: 72, color: "b", line: 3, score: "V"},
					{diam: 145, color: "b", line: 6, score: 5},
					{diam: 290, color: "b", line: 6, score: 4},
					{diam: 600, color: "b", line: 6, score: 3},
					{diam: 915, color: "b", line: 0, score: 2}
		],
		default_ring_text: true,
	};

	targetfaces["IF600m"] = {
		name: "ICFRA F-Class 600m/700y",
		shortname: "FC 600m/700y",
		dist: 600,
		dist_unit: "m",
		score: [5, "V"],
		board: {w: 1800, h: 1800, line: 20, score: 1},
		rings: [	{diam: 80, color: "b", line: 3, score: "V"},
					{diam: 160, color: "b", line: 6, score: 5},
					{diam: 320, color: "b", line: 6, score: 4},
					{diam: 660, color: "b", line: 6, score: 3},
					{diam: 1000, color: "b", line: 0, score: 2}
		],
		default_ring_text: true,
	};

	targetfaces["IFLR"] = {
		name: "ICFRA F-Class Long Range",
		shortname: "FC Long Range",
		dist: 900,
		dist_unit: "m",
		score: [5, "V"],
		board: {w: 2400, h: 1800, line: 20, score: 1},
		rings: [	{diam: 128, color: "b", line: 8, score: "V"},
					{diam: 254, color: "b", line: 12, score: 5},
					{diam: 508, color: "b", line: 12, score: 4},
					{diam: 815, color: "b", line: 12, score: 3},
					{diam: 1118, color: "b", line: 0, score: 2}
		],
		default_ring_text: true,
	};


	// ICFRA F-Class 2008 (X, 6)

	targetfaces["IFX300y"] = {
		name: "ICFRA-2008 F-Class 300y",
		shortname: "FC 300y",
		dist: 300,
		dist_unit: "y",
		score: [6, "X"],
		board: {w: 1200, h: 1200, line: 20, score: 1},
		rings: [	{diam: 32, color: "b", line: 2, score: "X"},
					{diam: 65, color: "b", line: 4, score: 6},
					{diam: 130, color: "b", line: 4, score: 5},
					{diam: 260, color: "b", line: 4, score: 4},
					{diam: 390, color: "b", line: 4, score: 3},
					{diam: 560, color: "b", line: 0, score: 2}
		],
		default_ring_text: true,
	};

	targetfaces["IFX300m"] = {
		name: "ICFRA-2008 F-Class 300m",
		shortname: "FC 300m",
		dist: 300,
		dist_unit: "m",
		score: [6, "X"],
		board: {w: 1200, h: 1200, line: 20, score: 1},
		rings: [	{diam: 35, color: "b", line: 2, score: "X"},
					{diam: 70, color: "b", line: 4, score: 6},
					{diam: 140, color: "b", line: 4, score: 5},
					{diam: 280, color: "b", line: 4, score: 4},
					{diam: 420, color: "b", line: 4, score: 3},
					{diam: 600, color: "b", line: 0, score: 2}
		],
		default_ring_text: true,
	};

	targetfaces["IFX400y"] = {
		name: "ICFRA-2008 F-Class 400y",
		shortname: "FC 400y",
		dist: 400,
		dist_unit: "y",
		score: [6, "X"],
		board: {w: 1200, h: 1200, line: 20, score: 1},
		rings: [	{diam: 43, color: "b", line: 2, score: "X"},
					{diam: 86, color: "b", line: 4, score: 6},
					{diam: 173, color: "b", line: 4, score: 5},
					{diam: 346, color: "b", line: 4, score: 4},
					{diam: 520, color: "b", line: 4, score: 3},
					{diam: 746, color: "b", line: 0, score: 2}
		],
		default_ring_text: true,
	};

	targetfaces["IFX400m"] = {
		name: "ICFRA-2008 F-Class 400m",
		shortname: "FC 400m",
		dist: 400,
		dist_unit: "m",
		score: [6, "X"],
		board: {w: 1200, h: 1200, line: 20, score: 1},
		rings: [	{diam: 46, color: "b", line: 2, score: "X"},
					{diam: 93, color: "b", line: 4, score: 6},
					{diam: 186, color: "b", line: 4, score: 5},
					{diam: 373, color: "b", line: 4, score: 4},
					{diam: 560, color: "b", line: 4, score: 3},
					{diam: 800, color: "b", line: 0, score: 2}
		],
		default_ring_text: true,
	};

	targetfaces["IFX500y"] = {
		name: "ICFRA-2008 F-Class 500y",
		shortname: "FC 500y",
		dist: 500,
		dist_unit: "y",
		score: [6, "X"],
		board: {w: 1800, h: 1800, line: 20, score: 1},
		rings: [	{diam: 65, color: "b", line: 3, score: "X"},
					{diam: 130, color: "b", line: 6, score: 6},
					{diam: 260, color: "b", line: 6, score: 5},
					{diam: 600, color: "b", line: 6, score: 4},
					{diam: 915, color: "b", line: 0, score: 3},
					{diam: 1320, color: "w", line: 6, score: 2}
		],
		default_ring_text: true,
	};

	targetfaces["IFX500m"] = {
		name: "ICFRA-2008 F-Class 500m",
		shortname: "FC 500m",
		dist: 500,
		dist_unit: "m",
		score: [6, "X"],
		board: {w: 1800, h: 1800, line: 20, score: 1},
		rings: [	{diam: 72, color: "b", line: 3, score: "X"},
					{diam: 145, color: "b", line: 6, score: 6},
					{diam: 290, color: "b", line: 6, score: 5},
					{diam: 660, color: "b", line: 6, score: 4},
					{diam: 1000, color: "b", line: 0, score: 3},
					{diam: 1320, color: "w", line: 6, score: 2}
		],
		default_ring_text: true,
	};

	targetfaces["IFX600y"] = {
		name: "ICFRA-2008 F-Class 600y",
		shortname: "FC 600y",
		dist: 600,
		dist_unit: "y",
		score: [6, "X"],
		board: {w: 1800, h: 1800, line: 20, score: 1},
		rings: [	{diam: 72, color: "b", line: 3, score: "X"},
					{diam: 145, color: "b", line: 6, score: 6},
					{diam: 290, color: "b", line: 6, score: 5},
					{diam: 600, color: "b", line: 6, score: 4},
					{diam: 915, color: "b", line: 0, score: 3},
					{diam: 1320, color: "w", line: 6, score: 2}
		],
		default_ring_text: true,
	};

	targetfaces["IFX600m"] = {
		name: "ICFRA-2008 F-Class 600m/700y",
		shortname: "FC 600m/700y",
		dist: 600,
		dist_unit: "m",
		score: [6, "X"],
		board: {w: 1800, h: 1800, line: 20, score: 1},
		rings: [	{diam: 80, color: "b", line: 3, score: "X"},
					{diam: 160, color: "b", line: 6, score: 6},
					{diam: 320, color: "b", line: 6, score: 5},
					{diam: 660, color: "b", line: 6, score: 4},
					{diam: 1000, color: "b", line: 0, score: 3},
					{diam: 1320, color: "w", line: 6, score: 2}
		],
		default_ring_text: true,
	};

	targetfaces["IFXLR"] = {
		name: "ICFRA-2008 F-Class Long Range",
		shortname: "FC Long Range",
		dist: 900,
		dist_unit: "m",
		score: [6, "X"],
		board: {w: 2400, h: 1800, line: 20, score: 1},
		rings: [	{diam: 127, color: "b", line: 8, score: "X"},
					{diam: 255, color: "b", line: 12, score: 6},
					{diam: 510, color: "b", line: 12, score: 5},
					{diam: 815, color: "b", line: 12, score: 4},
					{diam: 1120, color: "b", line: 0, score: 3},
					{diam: 1830, color: "w", line: 12, score: 2}
		],
		default_ring_text: true,
	};




	// ICFRA Target Rifle


	targetfaces["IS300y"] = {
		name: "ICFRA Target Rifle 300y",
		shortname: "TR 300y",
		dist: 300,
		dist_unit: "y",
		score: [5, "V"],
		board: {w: 1200, h: 1200, line: 20, score: 1},
		rings: [	{diam: 65, color: "b", line: 4, score: "V"},
					{diam: 130, color: "b", line: 4, score: 5},
					{diam: 260, color: "b", line: 4, score: 4},
					{diam: 390, color: "b", line: 4, score: 3},
					{diam: 560, color: "b", line: 0, score: 2}
		],
		default_ring_text: true,
	};

	targetfaces["IS300m"] = {
		name: "ICFRA Target Rifle 300m",
		shortname: "TR 300m",
		dist: 300,
		dist_unit: "m",
		score: [5, "V"],
		board: {w: 1200, h: 1200, line: 20, score: 1},
		rings: [	{diam: 70, color: "b", line: 4, score: "V"},
					{diam: 140, color: "b", line: 4, score: 5},
					{diam: 280, color: "b", line: 4, score: 4},
					{diam: 420, color: "b", line: 4, score: 3},
					{diam: 600, color: "b", line: 0, score: 2}
		],
		default_ring_text: true,
	};

	targetfaces["IS400y"] = {
		name: "ICFRA Target Rifle 400y",
		shortname: "TR 400y",
		dist: 400,
		dist_unit: "y",
		score: [5, "V"],
		board: {w: 1800, h: 1800, line: 20, score: 1},
		rings: [	{diam: 85, color: "b", line: 4, score: "V"},
					{diam: 175, color: "b", line: 4, score: 5},
					{diam: 350, color: "b", line: 4, score: 4},
					{diam: 520, color: "b", line: 4, score: 3},
					{diam: 745, color: "b", line: 0, score: 2}
		],
		default_ring_text: true,
	};

	targetfaces["IS400m"] = {
		name: "ICFRA Target Rifle 400m",
		shortname: "TR 400m",
		dist: 400,
		dist_unit: "m",
		score: [5, "V"],
		board: {w: 1800, h: 1800, line: 20, score: 1},
		rings: [	{diam: 95, color: "b", line: 4, score: "V"},
					{diam: 185, color: "b", line: 4, score: 5},
					{diam: 375, color: "b", line: 4, score: 4},
					{diam: 560, color: "b", line: 4, score: 3},
					{diam: 800, color: "b", line: 0, score: 2}
		],
		default_ring_text: true,
	};

	targetfaces["IS500y"] = {
		name: "ICFRA Target Rifle 500y",
		shortname: "TR 500y",
		dist: 500,
		dist_unit: "y",
		score: [5, "V"],
		board: {w: 1800, h: 1800, line: 20, score: 1},
		rings: [	{diam: 130, color: "b", line: 6, score: "V"},
					{diam: 260, color: "b", line: 6, score: 5},
					{diam: 600, color: "b", line: 6, score: 4},
					{diam: 915, color: "b", line: 0, score: 3},
					{diam: 1320, color: "w", line: 6, score: 2}
		],
		default_ring_text: true,
	};

	targetfaces["IS500m"] = {
		name: "ICFRA Target Rifle 500m",
		shortname: "TR 500m",
		dist: 500,
		dist_unit: "m",
		score: [5, "V"],
		board: {w: 1800, h: 1800, line: 20, score: 1},
		rings: [	{diam: 145, color: "b", line: 6, score: "V"},
					{diam: 290, color: "b", line: 6, score: 5},
					{diam: 660, color: "b", line: 6, score: 4},
					{diam: 1000, color: "b", line: 0, score: 3},
					{diam: 1320, color: "w", line: 6, score: 2}
		],
		default_ring_text: true,
	};

	targetfaces["IS600y"] = {
		name: "ICFRA Target Rifle 600y",
		shortname: "TR 600y",
		dist: 600,
		dist_unit: "y",
		score: [5, "V"],
		board: {w: 1800, h: 1800, line: 20, score: 1},
		rings: [	{diam: 145, color: "b", line: 6, score: "V"},
					{diam: 290, color: "b", line: 6, score: 5},
					{diam: 600, color: "b", line: 6, score: 4},
					{diam: 915, color: "b", line: 0, score: 3},
					{diam: 1320, color: "w", line: 6, score: 2}
		],
		default_ring_text: true,
	};

	targetfaces["IS600m"] = {
		name: "ICFRA Target Rifle 600m/700y",
		shortname: "TR 600m/700y",
		dist: 600,
		dist_unit: "m",
		score: [5, "V"],
		board: {w: 1800, h: 1800, line: 20, score: 1},
		rings: [	{diam: 160, color: "b", line: 6, score: "V"},
					{diam: 320, color: "b", line: 6, score: 5},
					{diam: 660, color: "b", line: 6, score: 4},
					{diam: 1000, color: "b", line: 0, score: 3},
					{diam: 1320, color: "w", line: 6, score: 2}
		],
		default_ring_text: true,
	};

	targetfaces["ISLR"] = {
		name: "ICFRA Target Rifle Long Range",
		shortname: "TR Long Range",
		dist: 900,
		dist_unit: "m",
		score: [5, "V"],
		board: {w: 2400, h: 1800, line: 20, score: 1},
		rings: [	{diam: 255, color: "b", line: 12, score: "V"},
					{diam: 510, color: "b", line: 12, score: 5},
					{diam: 815, color: "b", line: 12, score: 4},
					{diam: 1120, color: "b", line: 0, score: 3},
					{diam: 1830, color: "w", line: 12, score: 2}
		],
		default_ring_text: true,
	};




	// DCRA F-Class


	targetfaces["DF100y"] = {
		name: "DCRA F-Class 100y",
		shortname: "FC 100y",
		dist: 100,
		dist_unit: "y",
		score: [5, "V"],
		board: {w: 46/INCH, h: 46/INCH, line: 20, score: 1},
		rings: [	{diam: 0.4375/INCH, color: "b", line: 1, score: "V"},
					{diam: 0.875/INCH, color: "b", line: 2, score: 5},
					{diam: 1.75/INCH, color: "b", line: 2, score: 4},
					{diam: 3.5/INCH, color: "b", line: 2, score: 3},
					{diam: 5.25/INCH, color: "b", line: 2, score: 2},
					{diam: 8/INCH, color: "b", line: 0, score: 1}
		],
		default_ring_text: true,
	};

	targetfaces["DF200y"] = {
		name: "DCRA F-Class 200y",
		shortname: "FC 200y",
		dist: 200,
		dist_unit: "y",
		score: [5, "V"],
		board: {w: 46/INCH, h: 46/INCH, line: 20, score: 1},
		rings: [	{diam: 0.875/INCH, color: "b", line: 1, score: "V"},
					{diam: 1.75/INCH, color: "b", line: 2, score: 5},
					{diam: 3.5/INCH, color: "b", line: 2, score: 4},
					{diam: 7/INCH, color: "b", line: 2, score: 3},
					{diam: 10.5/INCH, color: "b", line: 2, score: 2},
					{diam: 16/INCH, color: "b", line: 0, score: 1}
		],
		default_ring_text: true,
	};

	targetfaces["DF300y"] = {
		name: "DCRA F-Class 300y",
		shortname: "FC 300y",
		dist: 300,
		dist_unit: "y",
		score: [5, "V"],
		board: {w: 46/INCH, h: 46/INCH, line: 20, score: 1},
		rings: [	{diam: 1.375/INCH, color: "b", line: 2, score: "V"},
					{diam: 2.75/INCH, color: "b", line: 4, score: 5},
					{diam: 5.5/INCH, color: "b", line: 4, score: 4},
					{diam: 11/INCH, color: "b", line: 4, score: 3},
					{diam: 16.5/INCH, color: "b", line: 4, score: 2},
					{diam: 22/INCH, color: "b", line: 0, score: 1}
		],
		default_ring_text: true,
	};

	targetfaces["DF300m"] = {
		name: "DCRA F-Class 300m",
		shortname: "FC 300m",
		dist: 300,
		dist_unit: "m",
		score: [5, "V"],
		board: {w: 46/INCH, h: 46/INCH, line: 20, score: 1},
		rings: [	{diam: 1.5625/INCH, color: "b", line: 2, score: "V"},
					{diam: 3.125/INCH, color: "b", line: 4, score: 5},
					{diam: 6.25/INCH, color: "b", line: 4, score: 4},
					{diam: 11.25/INCH, color: "b", line: 4, score: 3},
					{diam: 16.5/INCH, color: "b", line: 4, score: 2},
					{diam: 22/INCH, color: "b", line: 0, score: 1}
		],
		default_ring_text: true,
	};

	targetfaces["DF400y"] = {
		name: "DCRA F-Class 400y",
		shortname: "FC 400y",
		dist: 400,
		dist_unit: "y",
		score: [5, "V"],
		board: {w: 70/INCH, h: 70/INCH, line: 20, score: 1},
		rings: [	{diam: 2/INCH, color: "b", line: 2, score: "V"},
					{diam: 4/INCH, color: "b", line: 4, score: 5},
					{diam: 8/INCH, color: "b", line: 4, score: 4},
					{diam: 15.25/INCH, color: "b", line: 4, score: 3},
					{diam: 22.25/INCH, color: "b", line: 4, score: 2},
					{diam: 30/INCH, color: "b", line: 0, score: 1}
		],
		default_ring_text: true,
	};

	targetfaces["DF400m"] = {
		name: "DCRA F-Class 400m",
		shortname: "FC 400m",
		dist: 400,
		dist_unit: "m",
		score: [5, "V"],
		board: {w: 70/INCH, h: 70/INCH, line: 20, score: 1},
		rings: [	{diam: 2.0625/INCH, color: "b", line: 2, score: "V"},
					{diam: 4.125/INCH, color: "b", line: 4, score: 5},
					{diam: 8.25/INCH, color: "b", line: 4, score: 4},
					{diam: 15.25/INCH, color: "b", line: 4, score: 3},
					{diam: 22.25/INCH, color: "b", line: 4, score: 2},
					{diam: 30/INCH, color: "b", line: 0, score: 1}
		],
		default_ring_text: true,
	};


	targetfaces["DF500y"] = {
		name: "DCRA F-Class 500y",
		shortname: "FC 500y",
		dist: 500,
		dist_unit: "y",
		score: [5, "V"],
		board: {w: 70/INCH, h: 70/INCH, line: 20, score: 1},
		rings: [	{diam: 2.625/INCH, color: "b", line: 3, score: "V"},
					{diam: 5.25/INCH, color: "b", line: 6, score: 5},
					{diam: 10.5/INCH, color: "b", line: 6, score: 4},
					{diam: 26/INCH, color: "b", line: 6, score: 3},
					{diam: 39/INCH, color: "b", line: 0, score: 2},
					{diam: 52/INCH, color: "w", line: 6, score: 1}
		],
		default_ring_text: true,
	};

	targetfaces["DF500m"] = {
		name: "DCRA F-Class 500m",
		shortname: "FC 500m",
		dist: 500,
		dist_unit: "m",
		score: [5, "V"],
		board: {w: 70/INCH, h: 70/INCH, line: 20, score: 1},
		rings: [	{diam: 2.9375/INCH, color: "b", line: 3, score: "V"},
					{diam: 5.875/INCH, color: "b", line: 6, score: 5},
					{diam: 11.75/INCH, color: "b", line: 6, score: 4},
					{diam: 26/INCH, color: "b", line: 6, score: 3},
					{diam: 39/INCH, color: "b", line: 0, score: 2},
					{diam: 52/INCH, color: "w", line: 6, score: 1}
		],
		default_ring_text: true,
	};

	targetfaces["DF600y"] = {
		name: "DCRA F-Class 600y",
		shortname: "FC 600y",
		dist: 600,
		dist_unit: "y",
		score: [5, "V"],
		board: {w: 70/INCH, h: 70/INCH, line: 20, score: 1},
		rings: [	{diam: 3.25/INCH, color: "b", line: 3, score: "V"},
					{diam: 6.5/INCH, color: "b", line: 6, score: 5},
					{diam: 13/INCH, color: "b", line: 6, score: 4},
					{diam: 26/INCH, color: "b", line: 6, score: 3},
					{diam: 39/INCH, color: "b", line: 0, score: 2},
					{diam: 52/INCH, color: "w", line: 6, score: 1}
		],
		default_ring_text: true,
	};

	targetfaces["DF600m"] = {
		name: "DCRA F-Class 600m",
		shortname: "FC 600m",
		dist: 600,
		dist_unit: "m",
		score: [5, "V"],
		board: {w: 70/INCH, h: 70/INCH, line: 20, score: 1},
		rings: [	{diam: 3.625/INCH, color: "b", line: 3, score: "V"},
					{diam: 7.25/INCH, color: "b", line: 6, score: 5},
					{diam: 14.5/INCH, color: "b", line: 6, score: 4},
					{diam: 26/INCH, color: "b", line: 6, score: 3},
					{diam: 39/INCH, color: "b", line: 0, score: 2},
					{diam: 52/INCH, color: "w", line: 6, score: 1}
		],
		default_ring_text: true,
	};

	targetfaces["DFLR"] = {
		name: "DCRA F-Class Long Range",
		shortname: "FC Long Range",
		dist: 900,
		dist_unit: "m",
		score: [5, "V"],
		board: {w: 94/INCH, h: 70/INCH, line: 20, score: 1},
		rings: [	{diam: 6/INCH, color: "b", line: 8, score: "V"},
					{diam: 12/INCH, color: "b", line: 12, score: 5},
					{diam: 24/INCH, color: "b", line: 12, score: 4},
					{diam: 48/INCH, color: "b", line: 0, score: 3},
					{diam: 72/INCH, color: "w", line: 12, score: 2},
					{diam: 96/INCH, color: "w", line: 12, score: 1}
		],
		default_ring_text: true,
	};




	// DCRA Target Rifle


	targetfaces["DS100y"] = {
		name: "DCRA Target Rifle 100y",
		shortname: "TR 100y",
		dist: 100,
		dist_unit: "y",
		score: [5, "V"],
		board: {w: 46/INCH, h: 46/INCH, line: 20, score: 1},
		rings: [	{diam: 0.875/INCH, color: "b", line: 2, score: "V"},
					{diam: 1.75/INCH, color: "b", line: 2, score: 5},
					{diam: 3.5/INCH, color: "b", line: 2, score: 4},
					{diam: 5.25/INCH, color: "b", line: 2, score: 3},
					{diam: 8/INCH, color: "b", line: 0, score: 2}
		],
		default_ring_text: true,
	};

	targetfaces["DS200y"] = {
		name: "DCRA Target Rifle 200y",
		shortname: "TR 200y",
		dist: 200,
		dist_unit: "y",
		score: [5, "V"],
		board: {w: 46/INCH, h: 46/INCH, line: 20, score: 1},
		rings: [	{diam: 1.75/INCH, color: "b", line: 2, score: "V"},
					{diam: 3.5/INCH, color: "b", line: 2, score: 5},
					{diam: 7/INCH, color: "b", line: 2, score: 4},
					{diam: 10.5/INCH, color: "b", line: 2, score: 3},
					{diam: 16/INCH, color: "b", line: 0, score: 2}
		],
		default_ring_text: true,
	};

	targetfaces["DS300y"] = {
		name: "DCRA Target Rifle 300y",
		shortname: "TR 300y",
		dist: 300,
		dist_unit: "y",
		score: [5, "V"],
		board: {w: 46/INCH, h: 46/INCH, line: 20, score: 1},
		rings: [	{diam: 2.75/INCH, color: "b", line: 4, score: "V"},
					{diam: 5.5/INCH, color: "b", line: 4, score: 5},
					{diam: 11/INCH, color: "b", line: 4, score: 4},
					{diam: 16.5/INCH, color: "b", line: 4, score: 3},
					{diam: 22/INCH, color: "b", line: 0, score: 2}
		],
		default_ring_text: true,
	};

	targetfaces["DS300m"] = {
		name: "DCRA Target Rifle 300m",
		shortname: "TR 300m",
		dist: 300,
		dist_unit: "m",
		score: [5, "V"],
		board: {w: 46/INCH, h: 46/INCH, line: 20, score: 1},
		rings: [	{diam: 3.125/INCH, color: "b", line: 4, score: "V"},
					{diam: 6.25/INCH, color: "b", line: 4, score: 5},
					{diam: 11.25/INCH, color: "b", line: 4, score: 4},
					{diam: 16.5/INCH, color: "b", line: 4, score: 3},
					{diam: 22/INCH, color: "b", line: 0, score: 2}
		],
		default_ring_text: true,
	};

	targetfaces["DS400y"] = {
		name: "DCRA Target Rifle 400y",
		shortname: "TR 400y",
		dist: 400,
		dist_unit: "y",
		score: [5, "V"],
		board: {w: 70/INCH, h: 70/INCH, line: 20, score: 1},
		rings: [	{diam: 4/INCH, color: "b", line: 4, score: "V"},
					{diam: 8/INCH, color: "b", line: 4, score: 5},
					{diam: 15.25/INCH, color: "b", line: 4, score: 4},
					{diam: 22.25/INCH, color: "b", line: 4, score: 3},
					{diam: 30/INCH, color: "b", line: 0, score: 2}
		],
		default_ring_text: true,
	};

	targetfaces["DS400m"] = {
		name: "DCRA Target Rifle 400m",
		shortname: "TR 400m",
		dist: 400,
		dist_unit: "m",
		score: [5, "V"],
		board: {w: 70/INCH, h: 70/INCH, line: 20, score: 1},
		rings: [	{diam: 4.125/INCH, color: "b", line: 4, score: "V"},
					{diam: 8.25/INCH, color: "b", line: 4, score: 5},
					{diam: 15.25/INCH, color: "b", line: 4, score: 4},
					{diam: 22.25/INCH, color: "b", line: 4, score: 3},
					{diam: 30/INCH, color: "b", line: 0, score: 2}
		],
		default_ring_text: true,
	};


	targetfaces["DS500y"] = {
		name: "DCRA Target Rifle 500y",
		shortname: "TR 500y",
		dist: 500,
		dist_unit: "y",
		score: [5, "V"],
		board: {w: 70/INCH, h: 70/INCH, line: 20, score: 1},
		rings: [	{diam: 5.25/INCH, color: "b", line: 6, score: "V"},
					{diam: 10.5/INCH, color: "b", line: 6, score: 5},
					{diam: 26/INCH, color: "b", line: 6, score: 4},
					{diam: 39/INCH, color: "b", line: 0, score: 3},
					{diam: 52/INCH, color: "w", line: 6, score: 2}
		],
		default_ring_text: true,
	};

	targetfaces["DS500m"] = {
		name: "DCRA Target Rifle 500m",
		shortname: "TR 500m",
		dist: 500,
		dist_unit: "m",
		score: [5, "V"],
		board: {w: 70/INCH, h: 70/INCH, line: 20, score: 1},
		rings: [	{diam: 5.875/INCH, color: "b", line: 6, score: "V"},
					{diam: 11.75/INCH, color: "b", line: 6, score: 5},
					{diam: 26/INCH, color: "b", line: 6, score: 4},
					{diam: 39/INCH, color: "b", line: 0, score: 3},
					{diam: 52/INCH, color: "w", line: 6, score: 2}
		],
		default_ring_text: true,
	};

	targetfaces["DS600y"] = {
		name: "DCRA Target Rifle 600y",
		shortname: "TR 600y",
		dist: 600,
		dist_unit: "y",
		score: [5, "V"],
		board: {w: 70/INCH, h: 70/INCH, line: 20, score: 1},
		rings: [	{diam: 6.5/INCH, color: "b", line: 6, score: "V"},
					{diam: 13/INCH, color: "b", line: 6, score: 5},
					{diam: 26/INCH, color: "b", line: 6, score: 4},
					{diam: 39/INCH, color: "b", line: 0, score: 3},
					{diam: 52/INCH, color: "w", line: 6, score: 2}
		],
		default_ring_text: true,
	};

	targetfaces["DS600m"] = {
		name: "DCRA Target Rifle 600m",
		shortname: "TR 600m",
		dist: 600,
		dist_unit: "m",
		score: [5, "V"],
		board: {w: 70/INCH, h: 70/INCH, line: 20, score: 1},
		rings: [	{diam: 7.25/INCH, color: "b", line: 6, score: "V"},
					{diam: 14.5/INCH, color: "b", line: 6, score: 5},
					{diam: 26/INCH, color: "b", line: 6, score: 4},
					{diam: 39/INCH, color: "b", line: 0, score: 3},
					{diam: 52/INCH, color: "w", line: 6, score: 2}
		],
		default_ring_text: true,
	};

	targetfaces["DSLR"] = {
		name: "DCRA Target Rifle Long Range",
		shortname: "TR Long Range",
		dist: 900,
		dist_unit: "m",
		score: [5, "V"],
		board: {w: 94/INCH, h: 70/INCH, line: 20, score: 1},
		rings: [	{diam: 12/INCH, color: "b", line: 12, score: "V"},
					{diam: 24/INCH, color: "b", line: 12, score: 5},
					{diam: 48/INCH, color: "b", line: 0, score: 4},
					{diam: 72/INCH, color: "w", line: 12, score: 3},
					{diam: 96/INCH, color: "w", line: 12, score: 2}
		],
		default_ring_text: true,
	};

	// NRA UK (Bisley) Target Rifle

	targetfaces["UKTR200"] = {
		name: "Bisley Target Rifle 200y",
		shortname: "TR 200y",
		dist: 200,
		dist_unit: "y",
		score: [5, "V"],
		board: {w: 46/INCH, h: 46/INCH, line: 20, score: 1},
		rings: [	{diam: 2.1/INCH, color: "b", line: 2, score: "V"},
					{diam: 3.5/INCH, color: "b", line: 2, score: 5},
					{diam: 7/INCH, color: "b", line: 2, score: 4},
					{diam: 10.5/INCH, color: "b", line: 2, score: 3},
					{diam: 16/INCH, color: "b", line: 0, score: 2}
		],
		default_ring_text: true,
	};

	targetfaces["UKFC200"] = {
		name: "Bisley F-Class 200y",
		shortname: "FC 200y",
		dist: 200,
		dist_unit: "y",
		score: [5, "V"],
		board: {w: 46/INCH, h: 46/INCH, line: 20, score: 0},
		rings: [	{diam: 1/INCH, color: "w", line: 0, score: "V"},
					{diam: 2/INCH, color: "b", line: 2, score: 5},
					{diam: 4/INCH, color: "b", line: 2, score: 4},
					{diam: 6/INCH, color: "b", line: 2, score: 3},
					{diam: 8/INCH, color: "b", line: 0, score: 2},
					{diam: 10/INCH, color: "w", line: 2, score: 1}
		],
		default_ring_text: true,
	};

	targetfaces["UKTR300"] = {
		name: "Bisley Target Rifle 300y",
		shortname: "TR 300y",
		dist: 300,
		dist_unit: "y",
		score: [5, "V"],
		board: {w: 46/INCH, h: 46/INCH, line: 20, score: 1},
		rings: [	{diam: 3.3/INCH, color: "b", line: 4, score: "V"},
					{diam: 5.5/INCH, color: "b", line: 4, score: 5},
					{diam: 11/INCH, color: "b", line: 4, score: 4},
					{diam: 16.5/INCH, color: "b", line: 4, score: 3},
					{diam: 22/INCH, color: "b", line: 0, score: 2}
		],
		default_ring_text: true,
	};

	targetfaces["UKFC300"] = {
		name: "Bisley F-Class 300y",
		shortname: "FC 300y",
		dist: 300,
		dist_unit: "y",
		score: [5, "V"],
		board: {w: 46/INCH, h: 46/INCH, line: 20, score: 0},
		rings: [	{diam: 1.5/INCH, color: "w", line: 0, score: "V"},
					{diam: 3/INCH, color: "b", line: 4, score: 5},
					{diam: 6/INCH, color: "b", line: 4, score: 4},
					{diam: 9/INCH, color: "b", line: 4, score: 3},
					{diam: 12/INCH, color: "b", line: 0, score: 2},
					{diam: 15/INCH, color: "w", line: 4, score: 1}
		],
		default_ring_text: true,
	};

	targetfaces["UKTR400"] = {
		name: "Bisley Target Rifle 400y",
		shortname: "TR 400y",
		dist: 400,
		dist_unit: "y",
		score: [5, "V"],
		board: {w: 46/INCH, h: 46/INCH, line: 20, score: 1},
		rings: [	{diam: 4.8/INCH, color: "b", line: 4, score: "V"},
					{diam: 8/INCH, color: "b", line: 4, score: 5},
					{diam: 16/INCH, color: "b", line: 4, score: 4},
					{diam: 24/INCH, color: "b", line: 4, score: 3},
					{diam: 32/INCH, color: "b", line: 0, score: 2}
		],
		default_ring_text: true,
	};

	targetfaces["UKFC400"] = {
		name: "Bisley F-Class 400y",
		shortname: "FC 400y",
		dist: 400,
		dist_unit: "y",
		score: [5, "V"],
		board: {w: 46/INCH, h: 46/INCH, line: 20, score: 0},
		rings: [	{diam: 2/INCH, color: "w", line: 0, score: "V"},
					{diam: 4/INCH, color: "b", line: 4, score: 5},
					{diam: 8/INCH, color: "b", line: 4, score: 4},
					{diam: 12/INCH, color: "b", line: 4, score: 3},
					{diam: 16/INCH, color: "b", line: 0, score: 2},
					{diam: 20/INCH, color: "w", line: 4, score: 1}
		],
		default_ring_text: true,
	};

	targetfaces["UKTR500"] = {
		name: "Bisley Target Rifle 500y",
		shortname: "TR 500y",
		dist: 500,
		dist_unit: "y",
		score: [5, "V"],
		board: {w: 70/INCH, h: 60/INCH, line: 20, score: 1},
		rings: [	{diam: 6.3/INCH, color: "b", line: 6, score: "V"},
					{diam: 10.5/INCH, color: "b", line: 6, score: 5},
					{diam: 26/INCH, color: "b", line: 6, score: 4},
					{diam: 39/INCH, color: "b", line: 0, score: 3},
					{diam: 52/INCH, color: "w", line: 6, score: 2}
		],
		default_ring_text: true,
	};

	targetfaces["UKFC500"] = {
		name: "Bisley F-Class 500y",
		shortname: "FC 500y",
		dist: 500,
		dist_unit: "y",
		score: [5, "V"],
		board: {w: 70/INCH, h: 60/INCH, line: 20, score: 0},
		rings: [	{diam: 2.5/INCH, color: "w", line: 0, score: "V"},
					{diam: 5/INCH, color: "b", line: 6, score: 5},
					{diam: 10/INCH, color: "b", line: 6, score: 4},
					{diam: 15/INCH, color: "b", line: 6, score: 3},
					{diam: 20/INCH, color: "b", line: 0, score: 2},
					{diam: 25/INCH, color: "w", line: 6, score: 1}
		],
		default_ring_text: true,
	};

	targetfaces["UKTR600"] = {
		name: "Bisley Target Rifle 600y",
		shortname: "TR 600y",
		dist: 600,
		dist_unit: "y",
		score: [5, "V"],
		board: {w: 70/INCH, h: 60/INCH, line: 20, score: 1},
		rings: [	{diam: 7.8/INCH, color: "b", line: 6, score: "V"},
					{diam: 13/INCH, color: "b", line: 6, score: 5},
					{diam: 26/INCH, color: "b", line: 6, score: 4},
					{diam: 39/INCH, color: "b", line: 0, score: 3},
					{diam: 52/INCH, color: "w", line: 6, score: 2}
		],
		default_ring_text: true,
	};

	targetfaces["UKFC600"] = {
		name: "Bisley F-Class 600y",
		shortname: "FC 600y",
		dist: 600,
		dist_unit: "y",
		score: [5, "V"],
		board: {w: 70/INCH, h: 60/INCH, line: 20, score: 0},
		rings: [	{diam: 3/INCH, color: "w", line: 0, score: "V"},
					{diam: 6/INCH, color: "b", line: 6, score: 5},
					{diam: 12/INCH, color: "b", line: 6, score: 4},
					{diam: 18/INCH, color: "b", line: 6, score: 3},
					{diam: 24/INCH, color: "b", line: 0, score: 2},
					{diam: 30/INCH, color: "w", line: 6, score: 1}
		],
		default_ring_text: true,
	};

	targetfaces["UKTRLR"] = {
		name: "Bisley Target Rifle Long Range",
		shortname: "TR Long Range",
		dist: 1000,
		dist_unit: "y",
		score: [5, "V"],
		board: {w: 118/INCH, h: 70/INCH, line: 20, score: 1},
		rings: [	{diam: 14.4/INCH, color: "b", line: 12, score: "V"},
					{diam: 24/INCH, color: "b", line: 12, score: 5},
					{diam: 48/INCH, color: "b", line: 0, score: 4},
					{diam: 72/INCH, color: "w", line: 12, score: 3},
					{diam: 96/INCH, color: "w", line: 12, score: 2}
		],
		default_ring_text: true,
	};

	targetfaces["UKFCLR"] = {
		name: "Bisley F-Class Long Range",
		shortname: "FC Long Range",
		dist: 1000,
		dist_unit: "y",
		score: [5, "V"],
		board: {w: 118/INCH, h: 70/INCH, line: 20, score: 0},
		rings: [	{diam: 5/INCH, color: "w", line: 0, score: "V"},
					{diam: 10/INCH, color: "b", line: 6, score: 5},
					{diam: 20/INCH, color: "b", line: 6, score: 4},
					{diam: 32/INCH, color: "b", line: 6, score: 3},
					{diam: 44/INCH, color: "b", line: 0, score: 2},
					{diam: 72/INCH, color: "w", line: 6, score: 1}
		],
		default_ring_text: true,
	};


	// SABU

	targetfaces["SASRTR"] = {
		name: "SABU Target Rifle Short Range",
		shortname: "TR Short Range",
		dist: 300,
		dist_unit: "m",
		score: [5, "V"],
		board: {w: 1200, h: 1200, line: 20, score: 2},
		rings: [	{diam: 70, color: "b", line: 4, score: "V"},
					{diam: 140, color: "b", line: 4, score: 5},
					{diam: 370, color: "b", line: 4, score: 4},
					{diam: 600, color: "b", line: 0, score: 3}
		],
		default_ring_text: true,
	};


	targetfaces["SASRFC"] = {
		name: "SABU F-Class Short Range",
		shortname: "FC Short Range",
		dist: 300,
		dist_unit: "m",
		score: [5, "V"],
		board: {w: 1200, h: 1200, line: 20, score: 1},
		rings: [	{diam: 35, color: "b", line: 2, score: "V"},
					{diam: 70, color: "b", line: 4, score: 5},
					{diam: 140, color: "b", line: 4, score: 4},
					{diam: 370, color: "b", line: 4, score: 3},
					{diam: 600, color: "b", line: 0, score: 2}
		],
		default_ring_text: true,
	};


	targetfaces["SAMRTR"] = {
		name: "SABU Target Rifle Mid Range",
		shortname: "TR Mid Range",
		dist: 600,
		dist_unit: "m",
		score: [5, "V"],
		board: {w: 1800, h: 1800, line: 20, score: 2},
		rings: [	{diam: 160, color: "b", line: 6, score: "V"},
					{diam: 320, color: "b", line: 6, score: 5},
					{diam: 660, color: "b", line: 6, score: 4},
					{diam: 1000, color: "b", line: 0, score: 3}
		],
		default_ring_text: true,
	};

	targetfaces["SAMRFC"] = {
		name: "SABU F-Class Mid Range",
		shortname: "FC Mid Range",
		dist: 600,
		dist_unit: "m",
		score: [5, "V"],
		board: {w: 1800, h: 1800, line: 20, score: 1},
		rings: [	{diam: 80, color: "b", line: 3, score: "V"},
					{diam: 160, color: "b", line: 6, score: 5},
					{diam: 320, color: "b", line: 6, score: 4},
					{diam: 660, color: "b", line: 6, score: 3},
					{diam: 1000, color: "b", line: 0, score: 2}
		],
		default_ring_text: true,
	};

	targetfaces["SALRTR"] = {
		name: "SABU Target Rifle Long Range",
		shortname: "TR Long Range",
		dist: 900,
		dist_unit: "m",
		score: [5, "V"],
		board: {w: 2400, h: 1800, line: 20, score: 2},
		rings: [	{diam: 254, color: "b", line: 12, score: "V"},
					{diam: 508, color: "b", line: 12, score: 5},
					{diam: 1117.6, color: "b", line: 0, score: 4},
					{diam: 1524, color: "w", line: 12, score: 3}
		],
		default_ring_text: true,
	};

	targetfaces["SALRFC"] = {
		name: "SABU F-Class Long Range",
		shortname: "FC Long Range",
		dist: 900,
		dist_unit: "m",
		score: [5, "V"],
		board: {w: 2400, h: 1800, line: 20, score: 1},
		rings: [	{diam: 127, color: "b", line: 6, score: "V"},
					{diam: 254, color: "b", line: 12, score: 5},
					{diam: 508, color: "b", line: 12, score: 4},
					{diam: 1117.6, color: "b", line: 0, score: 3},
					{diam: 1524, color: "w", line: 12, score: 2}
		],
		default_ring_text: true,
	};

	targetfaces["SASRVX"] = {
		name: "SABU Short Range V-X",
		shortname: "SABU SR V-X",
		dist: 300,
		dist_unit: "y",
		score: [5, "V", "X"],
		board: {w: 1200, h: 1200, line: 20, score: 1},
		rings: [	{diam: 32, color: "b", line: 2, score: "X"},
					{diam: 65, color: "b", line: 4, score: "V"},
					{diam: 130, color: "b", line: 4, score: 5},
					{diam: 260, color: "b", line: 4, score: 4},
					{diam: 390, color: "b", line: 4, score: 3},
					{diam: 560, color: "b", line: 0, score: 2}
		],
		default_ring_text: true,
	};

	targetfaces["SAMRVX"] = {
		name: "SABU Mid Range V-X",
		shortname: "SABU MR V-X",
		dist: 600,
		dist_unit: "y",
		score: [5, "V", "X"],
		board: {w: 1800, h: 1800, line: 20, score: 1},
		rings: [	{diam: 72, color: "b", line: 3, score: "X"},
					{diam: 145, color: "b", line: 6, score: "V"},
					{diam: 290, color: "b", line: 6, score: 5},
					{diam: 600, color: "b", line: 6, score: 4},
					{diam: 915, color: "b", line: 6, score: 3},
					{diam: 1320, color: "w", line: 6, score: 2}
		],
		default_ring_text: true,
	};	

	targetfaces["SALRVX"] = {
		name: "SABU Long Range V-X",
		shortname: "SABU LR V-X",
		dist: 900,
		dist_unit: "m",
		score: [5, "V", "X"],
		board: {w: 2400, h: 1800, line: 20, score: 2},
		rings: [	{diam: 127, color: "b", line: 6, score: "X"},
					{diam: 254, color: "b", line: 12, score: "V"},
					{diam: 508, color: "b", line: 12, score: 5},
					{diam: 1117.6, color: "b", line: 0, score: 4},
					{diam: 1524, color: "w", line: 12, score: 3}
		],
		default_ring_text: true,
	};


	// Benchrest

	var res = 0.5;
	var dy1 = 4.24;
	var dy2 = -4.11;
	targetfaces["IBS100BR"] = {
		name: "IBS 100yd BR",
		shortname: "IBS 100 BR",
		dist: 100,
		dist_unit: "y",
		score: [10],
		force_colors: true,

		board: {w: 7.8/INCH, h: 14/INCH, line: 2},

		rings: [
					{diam: res*1/INCH, color: "w", line: 0.08/INCH, x: res*2.5*DIAG/INCH, y: (dy2-res*2.5*DIAG)/INCH, score: 10},
					{diam: res*2/INCH, color: "w", line: 0.05/INCH, x: res*2.5*DIAG/INCH, y: (dy2-res*2.5*DIAG)/INCH, score: 9},

					{diam: res*1/INCH, color: "w", line: 0.08/INCH, x: -res*2.5*DIAG/INCH, y: (dy2-res*2.5*DIAG)/INCH, score: 10},
					{diam: res*2/INCH, color: "w", line: 0.05/INCH, x: -res*2.5*DIAG/INCH, y: (dy2-res*2.5*DIAG)/INCH, score: 9},

					{diam: res*1/INCH, color: "bl", line: 0.08/INCH, x: 0, y: dy1/INCH, score: 10},
					{diam: res*2/INCH, color: "bl", line: 0.05/INCH, x: 0, y: dy1/INCH, score: 9},
					{diam: res*3/INCH, color: "bl", line: 0.05/INCH, x: 0, y: dy1/INCH, score: 8},
					{diam: res*4/INCH, color: "bl", line: 0.05/INCH, x: 0, y: dy1/INCH, score: 7},
					{diam: res*5/INCH, color: "bl", line: 0.05/INCH, x: 0, y: dy1/INCH, score: 6},

					{diam: res*1/INCH, color: "bl", line: 0.08/INCH, x: 0, y: dy2/INCH, score: 10},
					{diam: res*2/INCH, color: "bl", line: 0.05/INCH, x: 0, y: dy2/INCH, score: 9},
					{diam: res*3/INCH, color: "bl", line: 0.05/INCH, x: 0, y: dy2/INCH, score: 8},
					{diam: res*4/INCH, color: "bl", line: 0.05/INCH, x: 0, y: dy2/INCH, score: 7},
					{diam: res*5/INCH, color: "bl", line: 0.05/INCH, x: 0, y: dy2/INCH, score: 6},
		],

		poly: [
					{points: polybox(0, 4.32/INCH, 3.5/INCH, 4.75/INCH), color: "bl", line: 0.05/INCH},
					{points: polybox(0, -4.00/INCH, 3.5/INCH, 4.75/INCH), color: "bl", line: 0.05/INCH},
		],

		poly_top: [
					{points: polybox(0, (dy1+res*2.5)/INCH, res/INCH, res/INCH), color: "w", line: 0},
					{points: polybox(0, (dy1+res*2.5)/INCH, res*2/INCH, res*2/INCH), color: "b", line: 0, score: 0},
					{points: polybox(0, (dy2+res*2.5)/INCH, res/INCH, res/INCH), color: "w", line: 0, score: 0},
					{points: polybox(0, (dy2+res*2.5)/INCH, res*2/INCH, res*2/INCH), color: "b", line: 0, score: 0},
		],

		text: [     {x: 1.5/INCH, y: -2/INCH, size: 0.5/INCH, color: "bl", text: "S"},
					{x: -1.5/INCH, y: -2/INCH, size: 0.5/INCH, color: "bl", text: "S"}
		]
	};

	var res = 1;
	var dy1 = 4.09;
	var dy2 = -4.51;
	targetfaces["IBS200BR"] = {
		name: "IBS 200yd BR",
		shortname: "IBS 200 BR",
		dist: 200,
		dist_unit: "y",
		score: [10],
		force_colors: true,

		board: {w: 8.25/INCH, h: 16/INCH, line: 2},

		rings: [
					{diam: res*1/INCH, color: "w", line: 0.125/INCH, x: res*2.5*DIAG/INCH, y: (dy2-res*2.5*DIAG)/INCH, score: 10},
					{diam: res*2/INCH, color: "w", line: 0.062/INCH, x: res*2.5*DIAG/INCH, y: (dy2-res*2.5*DIAG)/INCH, score: 9},

					{diam: res*1/INCH, color: "w", line: 0.125/INCH, x: -res*2.5*DIAG/INCH, y: (dy2-res*2.5*DIAG)/INCH, score: 10},
					{diam: res*2/INCH, color: "w", line: 0.062/INCH, x: -res*2.5*DIAG/INCH, y: (dy2-res*2.5*DIAG)/INCH, score: 9},

					{diam: res*1/INCH, color: "bl", line: 0.125/INCH, x: 0, y: dy1/INCH, score: 10},
					{diam: res*2/INCH, color: "bl", line: 0.062/INCH, x: 0, y: dy1/INCH, score: 9},
					{diam: res*3/INCH, color: "bl", line: 0.062/INCH, x: 0, y: dy1/INCH, score: 8},
					{diam: res*4/INCH, color: "bl", line: 0.062/INCH, x: 0, y: dy1/INCH, score: 7},
					{diam: res*5/INCH, color: "bl", line: 0.062/INCH, x: 0, y: dy1/INCH, score: 6},

					{diam: res*1/INCH, color: "bl", line: 0.125/INCH, x: 0, y: dy2/INCH, score: 10},
					{diam: res*2/INCH, color: "bl", line: 0.062/INCH, x: 0, y: dy2/INCH, score: 9},
					{diam: res*3/INCH, color: "bl", line: 0.062/INCH, x: 0, y: dy2/INCH, score: 8},
					{diam: res*4/INCH, color: "bl", line: 0.062/INCH, x: 0, y: dy2/INCH, score: 7},
					{diam: res*5/INCH, color: "bl", line: 0.062/INCH, x: 0, y: dy2/INCH, score: 6},

		],

		poly: [
					{points: polybox(0, 4.27/INCH, 7/INCH, 7/INCH), color: "bl", line: 0.05/INCH},
					{points: polybox(0, -4.36/INCH, 7/INCH, 7/INCH), color: "bl", line: 0.05/INCH},
		],

		poly_top: [
					{points: polybox(0, (dy1+res*2.5)/INCH, res/INCH, res/INCH), color: "w", line: 0},
					{points: polybox(0, (dy1+res*2.5)/INCH, res*2/INCH, res*2/INCH), color: "b", line: 0, score: 0},
					{points: polybox(0, (dy2+res*2.5)/INCH, res/INCH, res/INCH), color: "w", line: 0},
					{points: polybox(0, (dy2+res*2.5)/INCH, res*2/INCH, res*2/INCH), color: "b", line: 0, score: 0},
		],

		text: [     {x: 3.2/INCH, y: -1.3/INCH, size: 0.75/INCH, color: "bl", text: "S"},
					{x: -3.2/INCH, y: -1.3/INCH, size: 0.75/INCH, color: "bl", text: "S"}
		]
	};

	var res = 1.5;
	var dy1 = 6.23;
	var dy2 = -6.6;
	targetfaces["IBS300BR"] = {
		name: "IBS 300yd BR",
		shortname: "IBS 300 BR",
		dist: 300,
		dist_unit: "y",
		score: [10],

		board: {w: 13.1/INCH, h: 25/INCH, line: 2},

		rings: [

					{diam: res*1/INCH, color: "bl", line: 0.125/INCH, x: 0, y: dy1/INCH, score: 10},
					{diam: res*2/INCH, color: "bl", line: 0.062/INCH, x: 0, y: dy1/INCH, score: 9},
					{diam: res*3/INCH, color: "bl", line: 0.062/INCH, x: 0, y: dy1/INCH, score: 8},
					{diam: res*4/INCH, color: "bl", line: 0.062/INCH, x: 0, y: dy1/INCH, score: 7},
					{diam: res*5/INCH, color: "bl", line: 0.062/INCH, x: 0, y: dy1/INCH, score: 6},

					{diam: res*1/INCH, color: "bl", line: 0.125/INCH, x: 0, y: dy2/INCH, score: 10},
					{diam: res*2/INCH, color: "bl", line: 0.062/INCH, x: 0, y: dy2/INCH, score: 9},
					{diam: res*3/INCH, color: "bl", line: 0.062/INCH, x: 0, y: dy2/INCH, score: 8},
					{diam: res*4/INCH, color: "bl", line: 0.062/INCH, x: 0, y: dy2/INCH, score: 7},
					{diam: res*5/INCH, color: "bl", line: 0.062/INCH, x: 0, y: dy2/INCH, score: 6},

		],

		poly: [
					{points: polybox(0, 6.45/INCH, 10.4/INCH, 10.4/INCH), color: "bl", line: 0.05/INCH},
					{points: polybox(0, -6.37/INCH, 10.4/INCH, 10.4/INCH), color: "bl", line: 0.05/INCH},
		],

		poly_top: [
					{points: polybox(0, (dy1+res*2.5)/INCH, res/INCH, res/INCH), color: "w", line: 0},
					{points: polybox(0, (dy1+res*2.5)/INCH, res*2/INCH, res*2/INCH), color: "b", line: 0, score: 0},
					{points: polybox(0, (dy2+res*2.5)/INCH, res/INCH, res/INCH), color: "w", line: 0},
					{points: polybox(0, (dy2+res*2.5)/INCH, res*2/INCH, res*2/INCH), color: "b", line: 0, score: 0},
		],

		text: [     {x: 4.6/INCH, y: -1.8/INCH, size: 1/INCH, color: "bl", text: "S"},
					{x: -4.6/INCH, y: -1.8/INCH, size: 1/INCH, color: "bl", text: "S"}
		]
	};

	// IBS 100 HR

	var hr100_dxy = [{x: 70, y: -241.3 + 81.5},
					 {x: -70, y: -241.3 + 81.5},
					 {x: -70, y: -241.3 + 81.5 + 139},
					 {x: -70, y: -241.3 + 81.5 + 139*2},
					 {x: 70, y: -241.3 + 81.5 + 178 + 139},
					 {x: 70, y: -241.3 + 81.5 + 178}];

	function hr100_rings() {
		var res = 0.5;
		var rings = [];
		for (var i in hr100_dxy) {
			var dx = hr100_dxy[i].x;
			var dy = hr100_dxy[i].y;
			rings.push({diam: (5/64)/INCH, color: "b", line: 0, x: dx, y: dy, score: "X"});
			rings.push({diam: res*1/INCH, color: "w", line: (1/32)/INCH, x: dx, y: dy, score: 10});
			rings.push({diam: res*2/INCH, color: "w", line: (1/32)/INCH, x: dx, y: dy, score: 9});
			rings.push({diam: res*3/INCH, color: "w", line: (1/32)/INCH, x: dx, y: dy, score: 8});
			rings.push({diam: res*4/INCH, color: "w", line: (1/32)/INCH, x: dx, y: dy, score: 7});
			rings.push({diam: res*5/INCH, color: "w", line: 0, x: dx, y: dy, score: 6});
			rings.push({diam: (3+1/16)/INCH, color: "b", line: (1/32)/INCH, x: dx, y: dy, score: 5});
			rings.push({diam: (3+5/8)/INCH, color: "b", line: (1/32)/INCH, x: dx, y: dy, score: 4});
			rings.push({diam: (4+1/8)/INCH, color: "b", line: 0, x: dx, y: dy, score: 3});
		}
		return rings;
	}

	targetfaces["IBS100HR"] = {
		name: "IBS 100yd HR",
		shortname: "IBS 100 HR",
		dist: 100,
		dist_unit: "y",
		score: [10, "X"],
		force_colors: true,
		board: {w: 12/INCH, h: 19/INCH, line: 2},

		rings: hr100_rings(),

		poly: [
					{points: polybox(hr100_dxy[0].x, hr100_dxy[0].y, 136, 135), color: "bl", line: 0.05/INCH},
					{points: polybox(hr100_dxy[1].x, hr100_dxy[1].y, 136, 135), color: "bl", line: 0.05/INCH},
					{points: polybox(hr100_dxy[2].x, hr100_dxy[2].y, 136, 135), color: "bl", line: 0.05/INCH},
					{points: polybox(hr100_dxy[3].x, hr100_dxy[3].y, 136, 135), color: "bl", line: 0.05/INCH},
					{points: polybox(hr100_dxy[4].x, hr100_dxy[4].y, 136, 135), color: "bl", line: 0.05/INCH},
					{points: polybox(hr100_dxy[5].x, hr100_dxy[5].y, 136, 135), color: "bl", line: 0.05/INCH},
		],

		text: [     {x: hr100_dxy[0].x - 2.3/INCH, y: hr100_dxy[0].y - 2.3/INCH, size: 0.8/INCH, color: "bl", text: "S"},
					{x: hr100_dxy[0].x + 2.3/INCH, y: hr100_dxy[0].y - 2.3/INCH, size: 0.8/INCH, color: "bl", text: "S"},
					{x: hr100_dxy[1].x - 2.3/INCH, y: hr100_dxy[1].y - 2.3/INCH, size: 0.7/INCH, color: "bl", text: "1"},
					{x: hr100_dxy[2].x - 2.3/INCH, y: hr100_dxy[2].y - 2.3/INCH, size: 0.7/INCH, color: "bl", text: "2"},
					{x: hr100_dxy[3].x - 2.3/INCH, y: hr100_dxy[3].y - 2.3/INCH, size: 0.7/INCH, color: "bl", text: "3"},
					{x: hr100_dxy[4].x - 2.3/INCH, y: hr100_dxy[4].y - 2.3/INCH, size: 0.7/INCH, color: "bl", text: "4"},
					{x: hr100_dxy[5].x - 2.3/INCH, y: hr100_dxy[5].y - 2.3/INCH, size: 0.7/INCH, color: "bl", text: "5"},
		].concat(text_rings({x: hr100_dxy[0].x - 0.35/INCH, y: hr100_dxy[0].y}, {x: -0.26/INCH, y: 0}, 9, 3, {size: 8, color: "gl"}))

	};

	// IBS 200 HR

	var hr200_dxy = [{x: (6.3/2)/INCH, y: (-21/2 + 1.72 + 6.3*0.5)/INCH},
					 {x: -(6.3/2)/INCH, y: (-21/2 + 0.5 + 6.3*0.5)/INCH},
					 {x: -(6.3/2)/INCH, y: (-21/2 + 0.5 + 6.3*1.5)/INCH},
					 {x: -(6.3/2)/INCH, y: (-21/2 + 0.5 + 6.3*2.5)/INCH},
					 {x: (6.3/2)/INCH, y: (-21/2 + 1.72 + 6.3*2.5)/INCH},
					 {x: (6.3/2)/INCH, y: (-21/2 + 1.72 + 6.3*1.5)/INCH}];

	function hr200_rings() {
		var res = 1;
		var rings = [];

		rings.push({diam: (5/32)/INCH, color: "b", line: 0, x: hr200_dxy[0].x - 0.7/INCH, y: hr200_dxy[0].y - 1/INCH, score: 10});
		rings.push({diam: res*1/INCH, color: "w", line: (1/16)/INCH, x: hr200_dxy[0].x - 0.7/INCH, y: hr200_dxy[0].y - 1/INCH, score: 9});

		rings.push({diam: (5/32)/INCH, color: "b", line: 0, x: hr200_dxy[0].x + 0.7/INCH, y: hr200_dxy[0].y - 1/INCH, score: 10});
		rings.push({diam: res*1/INCH, color: "w", line: (1/16)/INCH, x: hr200_dxy[0].x + 0.7/INCH, y: hr200_dxy[0].y - 1/INCH, score: 9});

		for (var i in hr200_dxy) {
			var dx = hr200_dxy[i].x;
			var dy = hr200_dxy[i].y;
			rings.push({diam: (5/32)/INCH, color: "b", line: 0, x: dx, y: dy, score: "X"});
			rings.push({diam: res*1/INCH, color: "w", line: (1/16)/INCH, x: dx, y: dy, score: 10});
			rings.push({diam: res*2/INCH, color: "w", line: (1/16)/INCH, x: dx, y: dy, score: 9});
			rings.push({diam: res*3/INCH, color: "w", line: (1/16)/INCH, x: dx, y: dy, score: 8});
			rings.push({diam: res*4/INCH, color: "w", line: 0, x: dx, y: dy, score: 7});
			rings.push({diam: res*5/INCH, color: "b", line: (1/16)/INCH, x: dx, y: dy, score: 6});
			rings.push({diam: res*6/INCH, color: "b", line: 0, x: dx, y: dy, score: 5});
		}


		return rings;
	}

	targetfaces["IBS200HR"] = {
		name: "IBS 200yd HR",
		shortname: "IBS 200 HR",
		dist: 200,
		dist_unit: "y",
		score: [10, "X"],
		force_colors: true,
		board: {w: 13/INCH, h: 21/INCH, line: 2},

		rings: hr200_rings(),

		poly: [
					{points: polybox(hr200_dxy[0].x, hr200_dxy[0].y, 6.3/INCH, 6.3/INCH), color: "bl", line: 0.05/INCH},
					{points: polybox(hr200_dxy[1].x, hr200_dxy[1].y, 6.3/INCH, 6.3/INCH), color: "bl", line: 0.05/INCH},
					{points: polybox(hr200_dxy[2].x, hr200_dxy[2].y, 6.3/INCH, 6.3/INCH), color: "bl", line: 0.05/INCH},
					{points: polybox(hr200_dxy[3].x, hr200_dxy[3].y, 6.3/INCH, 6.3/INCH), color: "bl", line: 0.05/INCH},
					{points: polybox(hr200_dxy[4].x, hr200_dxy[4].y, 6.3/INCH, 6.3/INCH), color: "bl", line: 0.05/INCH},
					{points: polybox(hr200_dxy[5].x, hr200_dxy[5].y, 6.3/INCH, 6.3/INCH), color: "bl", line: 0.05/INCH},
		],

		text: [     {x: hr200_dxy[0].x - 2.7/INCH, y: hr200_dxy[0].y - 2.7/INCH, size: 1/INCH, color: "bl", text: "S"},
					{x: hr200_dxy[0].x + 2.7/INCH, y: hr200_dxy[0].y - 2.7/INCH, size: 1/INCH, color: "bl", text: "S"},
					{x: hr200_dxy[1].x - 2.7/INCH, y: hr200_dxy[1].y - 2.7/INCH, size: 0.8/INCH, color: "bl", text: "1"},
					{x: hr200_dxy[2].x - 2.7/INCH, y: hr200_dxy[2].y - 2.7/INCH, size: 0.8/INCH, color: "bl", text: "2"},
					{x: hr200_dxy[3].x - 2.7/INCH, y: hr200_dxy[3].y - 2.7/INCH, size: 0.8/INCH, color: "bl", text: "3"},
					{x: hr200_dxy[4].x - 2.7/INCH, y: hr200_dxy[4].y - 2.7/INCH, size: 0.8/INCH, color: "bl", text: "4"},
					{x: hr200_dxy[5].x - 2.7/INCH, y: hr200_dxy[5].y - 2.7/INCH, size: 0.8/INCH, color: "bl", text: "5"},
		].concat(text_rings({x: hr200_dxy[0].x - 0.7/INCH, y: hr200_dxy[0].y}, {x: -0.51/INCH, y: 0}, 9, 5, {size: 16, color: "gl"}))

	};


	// IBS 300 HR


	var hr300_dxy = [{x: (9.4/2)/INCH, y: (-32.7/2 + 4 + 9.2*0.5)/INCH},
					 {x: -(9.4/2)/INCH, y: (-32.7/2 + 1.82 + 9.4*0.5)/INCH},
					 {x: -(9.4/2)/INCH, y: (-32.7/2 + 1.82 + 9.4*1.5)/INCH},
					 {x: -(9.4/2)/INCH, y: (-32.7/2 + 1.82 + 9.4*2.5)/INCH},
					 {x: (9.4/2)/INCH, y: (-32.7/2 + 4 + 9.2 + 9.4*1.5)/INCH},
					 {x: (9.4/2)/INCH, y: (-32.7/2 + 4 + 9.2 + 9.4*0.5)/INCH}];

	function hr300_rings() {
		var res = 1.5;
		var rings = [];

		for (var i in hr300_dxy) {
			var dx = hr300_dxy[i].x;
			var dy = hr300_dxy[i].y;
			rings.push({diam: (17/64)/INCH, color: "b", line: 0, x: dx, y: dy, score: "X"});
			rings.push({diam: res*1/INCH, color: "w", line: (1/8)/INCH, x: dx, y: dy, score: 10});
			rings.push({diam: res*2/INCH, color: "w", line: (1/8)/INCH, x: dx, y: dy, score: 9});
			rings.push({diam: res*3/INCH, color: "w", line: (1/8)/INCH, x: dx, y: dy, score: 8});
			rings.push({diam: res*4/INCH, color: "w", line: 0, x: dx, y: dy, score: 7});
			rings.push({diam: res*5/INCH, color: "b", line: (1/8)/INCH, x: dx, y: dy, score: 6});
			rings.push({diam: res*6/INCH, color: "b", line: 0, x: dx, y: dy, score: 5});
		}


		return rings;
	}

	targetfaces["IBS300HR"] = {
		name: "IBS 300yd HR",
		shortname: "IBS 300 HR",
		dist: 300,
		dist_unit: "y",
		score: [10, "X"],
		force_colors: true,
		board: {w: 20/INCH, h: 32.7/INCH, line: 2},

		rings: hr300_rings(),

		poly: [
					{points: polybox(hr300_dxy[0].x, hr300_dxy[0].y, 9.4/INCH, 9.2/INCH), color: "bl", line: 0.05/INCH},
					{points: polybox(hr300_dxy[1].x, hr300_dxy[1].y, 9.4/INCH, 9.4/INCH), color: "bl", line: 0.05/INCH},
					{points: polybox(hr300_dxy[2].x, hr300_dxy[2].y, 9.4/INCH, 9.4/INCH), color: "bl", line: 0.05/INCH},
					{points: polybox(hr300_dxy[3].x, hr300_dxy[3].y, 9.4/INCH, 9.4/INCH), color: "bl", line: 0.05/INCH},
					{points: polybox(hr300_dxy[4].x, hr300_dxy[4].y, 9.4/INCH, 9.4/INCH), color: "bl", line: 0.05/INCH},
					{points: polybox(hr300_dxy[5].x, hr300_dxy[5].y, 9.4/INCH, 9.4/INCH), color: "bl", line: 0.05/INCH},
		],

		text: [     {x: hr300_dxy[0].x - 4.2/INCH, y: hr300_dxy[0].y - 4.1/INCH, size: 1.2/INCH, color: "bl", text: "S"},
					{x: hr300_dxy[0].x + 4.2/INCH, y: hr300_dxy[0].y - 4.1/INCH, size: 1.2/INCH, color: "bl", text: "S"},
					{x: hr300_dxy[1].x - 4.2/INCH, y: hr300_dxy[1].y - 4.2/INCH, size: 1/INCH, color: "bl", text: "1"},
					{x: hr300_dxy[2].x - 4.2/INCH, y: hr300_dxy[2].y - 4.2/INCH, size: 1/INCH, color: "bl", text: "2"},
					{x: hr300_dxy[3].x - 4.2/INCH, y: hr300_dxy[3].y - 4.2/INCH, size: 1/INCH, color: "bl", text: "3"},
					{x: hr300_dxy[4].x - 4.2/INCH, y: hr300_dxy[4].y - 4.2/INCH, size: 1/INCH, color: "bl", text: "4"},
					{x: hr300_dxy[5].x - 4.2/INCH, y: hr300_dxy[5].y - 4.2/INCH, size: 1/INCH, color: "bl", text: "5"},
		].concat(text_rings({x: hr300_dxy[0].x - 1.05/INCH, y: hr300_dxy[0].y}, {x: -0.76/INCH, y: 0}, 9, 5, {size: 24, color: "gl"}))

	};

	// IBS 600
	targetfaces["IBS600BR"] = {
		name: "IBS 600yd BR",
		shortname: "IBS 600 BR",
		dist: 600,
		dist_unit: "y",
		score: [10, "X"],
		board: {w: 17.5/INCH, h: 17.5/INCH, line: 5, score: 0},
		rings: [	{diam: 1.2/INCH, color: "w", line: 3, score: "X"},
					{diam: 2.8/INCH, color: "w", line: 0, score: 10},
					{diam: 5.2/INCH, color: "b", line: 0, score: 9},
					{diam: 7.6/INCH, color: "w", line: 3, score: 8},
					{diam: 10/INCH, color: "w", line: 3, score: 7},
					{diam: 12.4/INCH, color: "w", line: 3, score: 6},
					{diam: 14.8/INCH, color: "w", line: 3, score: 5}
		],

		poly_top: [
					{points: polybox(0, 0, 2.5/INCH, 2.5/INCH), color: "wl", line: 2},
		],

		text: [
			{x: 0, y: 0, text: "X", size: 20, color: "gl"},
			{x: 0, y: 1/INCH, text: "10", size: 20, color: "gl"},
			{x: 0, y: 2/INCH, text: "9", size: 20, color: "gl"},
		].concat(text_rings({x: -3.2/INCH, y: 0}, {x: -1.2/INCH, y: 0}, 8, 5, {size: 20, color: "gl"}))

	};

	// IBS 600 x 3
	targetfaces["IBS600Bx3"] = {
		name: "IBS 600yd BR x3",
		shortname: "IBS 600 BR x3",
		dist: 600,
		dist_unit: "y",
		score: [10, "X"],
		board: {w: (20.875 + 21)/INCH, h: 48/INCH, line: 5, score: 0},
		rings: [
					{x: -10.5/INCH, y: (5/8+12)/INCH, diam: 1.2/INCH, color: "w", line: 3, score: "X"},
					{x: -10.5/INCH, y: (5/8+12)/INCH, diam: 2.8/INCH, color: "w", line: 0, score: 10},
					{x: -10.5/INCH, y: (5/8+12)/INCH, diam: 5.2/INCH, color: "b", line: 0, score: 9},
					{x: -10.5/INCH, y: (5/8+12)/INCH, diam: 7.6/INCH, color: "w", line: 3, score: 8},
					{x: -10.5/INCH, y: (5/8+12)/INCH, diam: 10/INCH, color: "w", line: 3, score: 7},
					{x: -10.5/INCH, y: (5/8+12)/INCH, diam: 12.4/INCH, color: "w", line: 3, score: 6},
					{x: -10.5/INCH, y: (5/8+12)/INCH, diam: 14.8/INCH, color: "w", line: 3, score: 5},

					{x: 10.5/INCH, y: (5/8+12)/INCH, diam: 1.2/INCH, color: "w", line: 3, score: "X"},
					{x: 10.5/INCH, y: (5/8+12)/INCH, diam: 2.8/INCH, color: "w", line: 0, score: 10},
					{x: 10.5/INCH, y: (5/8+12)/INCH, diam: 5.2/INCH, color: "b", line: 0, score: 9},
					{x: 10.5/INCH, y: (5/8+12)/INCH, diam: 7.6/INCH, color: "w", line: 3, score: 8},
					{x: 10.5/INCH, y: (5/8+12)/INCH, diam: 10/INCH, color: "w", line: 3, score: 7},
					{x: 10.5/INCH, y: (5/8+12)/INCH, diam: 12.4/INCH, color: "w", line: 3, score: 6},
					{x: 10.5/INCH, y: (5/8+12)/INCH, diam: 14.8/INCH, color: "w", line: 3, score: 5},

					{x: 0, y: (5/8-12)/INCH, diam: 1.2/INCH, color: "w", line: 3, score: "X"},
					{x: 0, y: (5/8-12)/INCH, diam: 2.8/INCH, color: "w", line: 0, score: 10},
					{x: 0, y: (5/8-12)/INCH, diam: 5.2/INCH, color: "b", line: 0, score: 9},
					{x: 0, y: (5/8-12)/INCH, diam: 7.6/INCH, color: "w", line: 3, score: 8},
					{x: 0, y: (5/8-12)/INCH, diam: 10/INCH, color: "w", line: 3, score: 7},
					{x: 0, y: (5/8-12)/INCH, diam: 12.4/INCH, color: "w", line: 3, score: 6},
					{x: 0, y: (5/8-12)/INCH, diam: 14.8/INCH, color: "w", line: 3, score: 5},

		],

		poly_top: [
					{points: polybox(-10.5/INCH, (5/8+12)/INCH, 2.5/INCH, 2.5/INCH), color: "wl", line: 2},
					{points: polybox(10.5/INCH, (5/8+12)/INCH, 2.5/INCH, 2.5/INCH), color: "wl", line: 2},
					{points: polybox(0, (5/8-12)/INCH, 2.5/INCH, 2.5/INCH), color: "wl", line: 2},

					{points: polybox(-10.5/INCH, 12/INCH, 21/INCH, 24/INCH), color: "bl", line: 2},
					{points: polybox(10.5/INCH, 12/INCH, 21/INCH, 24/INCH), color: "bl", line: 2},
					{points: polybox(0/INCH, -12/INCH, 21/INCH, 24/INCH), color: "bl", line: 2},
		],

		text: [
			{x: -10.5/INCH, y: (5/8+12)/INCH, text: "X", size: 20, color: "gl"},
			{x: -10.5/INCH, y: (5/8+12+1)/INCH, text: "10", size: 20, color: "gl"},
			{x: -10.5/INCH, y: (5/8+12+2)/INCH, text: "9", size: 20, color: "gl"},
			{x: 10.5/INCH, y: (5/8+12)/INCH, text: "X", size: 20, color: "gl"},
			{x: 10.5/INCH, y: (5/8+12+1)/INCH, text: "10", size: 20, color: "gl"},
			{x: 10.5/INCH, y: (5/8+12+2)/INCH, text: "9", size: 20, color: "gl"},
			{x: 0, y: (5/8-12)/INCH, text: "X", size: 20, color: "gl"},
			{x: 0, y: (5/8-12+1)/INCH, text: "10", size: 20, color: "gl"},
			{x: 0, y: (5/8-12+2)/INCH, text: "9", size: 20, color: "gl"},
		]
		.concat(text_rings({x: (-10.5 + -3.2)/INCH, y: (5/8+12)/INCH}, {x: -1.2/INCH, y: 0/INCH}, 8, 5, {size: 20, color: "gl"}))
		.concat(text_rings({x: (10.5 + -3.2)/INCH, y: (5/8+12)/INCH}, {x: -1.2/INCH, y: 0/INCH}, 8, 5, {size: 20, color: "gl"}))
		.concat(text_rings({x: (0 + -3.2)/INCH, y: (5/8-12)/INCH}, {x: -1.2/INCH, y: 0/INCH}, 8, 5, {size: 20, color: "gl"}))

	};


	// IBS 1000
	targetfaces["IBS1000BR"] = {
		name: "IBS 1000yd BR",
		shortname: "IBS 1000 BR",
		dist: 1000,
		dist_unit: "y",
		score: [10, "X"],
		board: {w: 42/INCH, h: 42/INCH, line: 10, score: 0},
		rings: [	{diam: 3/INCH, color: "w", line: 0, score: "X"},
					{diam: 7/INCH, color: "b", line: 6, score: 10},
					{diam: 13/INCH, color: "b", line: 0, score: 9},
					{diam: 19/INCH, color: "w", line: 6, score: 8},
					{diam: 25/INCH, color: "w", line: 6, score: 7},
					{diam: 31/INCH, color: "w", line: 6, score: 6},
					{diam: 37/INCH, color: "w", line: 6, score: 5}
		],

		poly_top: [
					{points: polybox(0, 0, 4/INCH, 4/INCH), color: "wl", line: 6},
		],

		text: [
			{x: 0, y: 0, text: "X", size: 50, color: "gl"},
			{x: 0, y: 2.6/INCH, text: "10", size: 50, color: "gl"},
			{x: 0, y: 4.9/INCH, text: "9", size: 50, color: "gl"},
		].concat(text_rings({x: -8/INCH, y: 0}, {x: -3/INCH, y: 0}, 8, 5, {size: 50, color: "gl"}))

	};


	//Paul Compton
	targetfaces["Hunter100"] = {
		name: "Hunter Class Target 100",
		shortname: "Hunter 100",
		force_colors: true,
		dist: 100,
		dist_unit: "y",
		board: {w: 12/INCH, h: 8/INCH, line: 2},
		score: [10, "X"],

		rings: [

			{diam: 0.063/INCH, color: "b", line: 0, x: 0-4/INCH, y: 0-2/INCH, score: "X"},
			{diam: 0.5/INCH, color: "w", line: 0.6, x: 0-4/INCH, y: 0-2/INCH, score: 10},
			{diam: 1.0/INCH, color: "w", line: 0.6, x: 0-4/INCH, y: 0-2/INCH, score: 9},
			{diam: 1.5/INCH, color: "w", line: 0, x: 0-4/INCH, y: 0-2/INCH, score: 8},
			{diam: 2.0/INCH, color: "b", line: 0.6, x: 0-4/INCH, y: 0-2/INCH, score: 7},
			{diam: 2.5/INCH, color: "b", line: 0.6, x: 0-4/INCH, y: 0-2/INCH, score: 6},

			{diam: 0.063/INCH, color: "b", line: 0, x: 0-4/INCH, y: 0+2/INCH, score: "X"},
			{diam: 0.5/INCH, color: "w", line: 0.6, x: 0-4/INCH, y: 0+2/INCH, score: 10},
			{diam: 1.0/INCH, color: "w", line: 0.6, x: 0-4/INCH, y: 0+2/INCH, score: 9},
			{diam: 1.5/INCH, color: "w", line: 0, x: 0-4/INCH, y: 0+2/INCH, score: 8},
			{diam: 2.0/INCH, color: "b", line: 0.6, x: 0-4/INCH, y: 0+2/INCH, score: 7},
			{diam: 2.5/INCH, color: "b", line: 0.6, x: 0-4/INCH, y: 0+2/INCH, score: 6},

			{diam: 0.063/INCH, color: "b", line: 0, x: 0, y: 0-2/INCH, score: "X"},
			{diam: 0.5/INCH, color: "w", line: 0.6, x: 0, y: 0-2/INCH, score: 10},
			{diam: 1.0/INCH, color: "w", line: 0.6, x: 0, y: 0-2/INCH, score: 9},
			{diam: 1.5/INCH, color: "w", line: 0, x: 0, y: 0-2/INCH, score: 8},
			{diam: 2.0/INCH, color: "b", line: 0.6, x: 0, y: 0-2/INCH, score: 7},
			{diam: 2.5/INCH, color: "b", line: 0.6, x: 0, y: 0-2/INCH, score: 6},

			{diam: 0.063/INCH, color: "b", line: 0, x: 0, y: 0+2/INCH, score: "X"},
			{diam: 0.5/INCH, color: "w", line: 0.6, x: 0, y: 0+2/INCH, score: 10},
			{diam: 1.0/INCH, color: "w", line: 0.6, x: 0, y: 0+2/INCH, score: 9},
			{diam: 1.5/INCH, color: "w", line: 0, x: 0, y: 0+2/INCH, score: 8},
			{diam: 2.0/INCH, color: "b", line: 0.6, x: 0, y: 0+2/INCH, score: 7},
			{diam: 2.5/INCH, color: "b", line: 0.6, x: 0, y: 0+2/INCH, score: 6},

			{diam: 0.063/INCH, color: "b", line: 0, x: 0+4/INCH, y: 0+2/INCH, score: "X"},
			{diam: 0.5/INCH, color: "w", line: 0.6, x: 0+4/INCH, y: 0+2/INCH, score: 10},
			{diam: 1.0/INCH, color: "w", line: 0.6, x: 0+4/INCH, y: 0+2/INCH, score: 9},
			{diam: 1.5/INCH, color: "w", line: 0, x: 0+4/INCH, y: 0+2/INCH, score: 8},
			{diam: 2.0/INCH, color: "b", line: 0.6, x: 0+4/INCH, y: 0+2/INCH, score: 7},
			{diam: 2.5/INCH, color: "b", line: 0.6, x: 0+4/INCH, y: 0+2/INCH, score: 6},

			//sighting
			{diam: 0.063/INCH, color: "b", line: 0, x: 0+4/INCH, y: 0-2/INCH},
			{diam: 0.5/INCH, color: "w", line: 0.6, x: 0+4/INCH, y: 0-2/INCH},
			{diam: 1.0/INCH, color: "w", line: 0.6, x: 0+4/INCH, y: 0-2/INCH},
			{diam: 1.5/INCH, color: "w", line: 0, x: 0+4/INCH, y: 0-2/INCH},
			{diam: 2.0/INCH, color: "b", line: 0.6, x: 0+4/INCH, y: 0-2/INCH},
			{diam: 2.5/INCH, color: "b", line: 0.6, x: 0+4/INCH, y: 0-2/INCH},

		],

		poly: [
			{points: [
				{x: 0+2/INCH, y: 0}, {x: 0+6/INCH, y: 0},
				{x: 0+6/INCH, y: 0-4/INCH}, {x: 0+2/INCH, y: 0-4/INCH},], 
				color: "bl", line: 0.04/INCH, score: 0},
		],

		text: [
			{x: 0+2.3/INCH, y: 0-3.6/INCH, size: .6/INCH, color: "bl", text: "S"},
			{x: 0+5.6/INCH, y: 0-3.6/INCH, size: .6/INCH, color: "bl", text: "S"},
		],

	};

	targetfaces["Hunter200"] = {
		name: "Hunter Class Target 200",
		shortname: "Hunter 200",
		force_colors: true,
		dist: 200,
		dist_unit: "y",
		board: {w: 19/INCH, h: 12.425/INCH, line: 2},
		score: [10],

		rings: [

			{diam: 0.125/INCH, color: "b", line: 0, x: 0-6.25/INCH, y: 0-3/INCH, score: "X"},
			{diam: 1/INCH, color: "w", line: 0.6, x: 0-6.25/INCH, y: 0-3/INCH, score: 10},
			{diam: 2/INCH, color: "w", line: 0.6, x: 0-6.25/INCH, y: 0-3/INCH, score: 9},
			{diam: 3/INCH, color: "w", line: 0, x: 0-6.25/INCH, y: 0-3/INCH, score: 8},
			{diam: 4/INCH, color: "b", line: 0.6, x: 0-6.25/INCH, y: 0-3/INCH, score: 7},
			{diam: 5/INCH, color: "b", line: 0.6, x: 0-6.25/INCH, y: 0-3/INCH, score: 6},

			{diam: 0.125/INCH, color: "b", line: 0, x: 0-6.25/INCH, y: 0+3/INCH, score: "X"},
			{diam: 1/INCH, color: "w", line: 0.6, x: 0-6.25/INCH, y: 0+3/INCH, score: 10},
			{diam: 2/INCH, color: "w", line: 0.6, x: 0-6.25/INCH, y: 0+3/INCH, score: 9},
			{diam: 3/INCH, color: "w", line: 0, x: 0-6.25/INCH, y: 0+3/INCH, score: 8},
			{diam: 4/INCH, color: "b", line: 0.6, x: 0-6.25/INCH, y: 0+3/INCH, score: 7},
			{diam: 5/INCH, color: "b", line: 0.6, x: 0-6.25/INCH, y: 0+3/INCH, score: 6},

			{diam: 0.125/INCH, color: "b", line: 0, x: 0, y: 0-3/INCH, score: "X"},
			{diam: 1/INCH, color: "w", line: 0.6, x: 0, y: 0-3/INCH, score: 10},
			{diam: 2/INCH, color: "w", line: 0.6, x: 0, y: 0-3/INCH, score: 9},
			{diam: 3/INCH, color: "w", line: 0, x: 0, y: 0-3/INCH, score: 8},
			{diam: 4/INCH, color: "b", line: 0.6, x: 0, y: 0-3/INCH, score: 7},
			{diam: 5/INCH, color: "b", line: 0.6, x: 0, y: 0-3/INCH, score: 6},

			{diam: 0.125/INCH, color: "b", line: 0, x: 0, y: 0+3/INCH, score: "X"},
			{diam: 1/INCH, color: "w", line: 0.6, x: 0, y: 0+3/INCH, score: 10},
			{diam: 2/INCH, color: "w", line: 0.6, x: 0, y: 0+3/INCH, score: 9},
			{diam: 3/INCH, color: "w", line: 0, x: 0, y: 0+3/INCH, score: 8},
			{diam: 4/INCH, color: "b", line: 0.6, x: 0, y: 0+3/INCH, score: 7},
			{diam: 5/INCH, color: "b", line: 0.6, x: 0, y: 0+3/INCH, score: 6},

			{diam: 0.125/INCH, color: "b", line: 0, x: 0+6.25/INCH, y: 0+3/INCH, score: "X"},
			{diam: 1/INCH, color: "w", line: 0.6, x: 0+6.25/INCH, y: 0+3/INCH, score: 10},
			{diam: 2/INCH, color: "w", line: 0.6, x: 0+6.25/INCH, y: 0+3/INCH, score: 9},
			{diam: 3/INCH, color: "w", line: 0, x: 0+6.25/INCH, y: 0+3/INCH, score: 8},
			{diam: 4/INCH, color: "b", line: 0.6, x: 0+6.25/INCH, y: 0+3/INCH, score: 7},
			{diam: 5/INCH, color: "b", line: 0.6, x: 0+6.25/INCH, y: 0+3/INCH, score: 6},

			//sighting
			{diam: 0.125/INCH, color: "b", line: 0, x: 0+6.25/INCH, y: 0-3/INCH},
			{diam: 1/INCH, color: "w", line: 0.6, x: 0+6.25/INCH, y: 0-3/INCH},
			{diam: 2/INCH, color: "w", line: 0.6, x: 0+6.25/INCH, y: 0-3/INCH},
			{diam: 3/INCH, color: "w", line: 0, x: 0+6.25/INCH, y: 0-3/INCH},
			{diam: 4/INCH, color: "b", line: 0.6, x: 0+6.25/INCH, y: 0-3/INCH},
			{diam: 5/INCH, color: "b", line: 0.6, x: 0+6.25/INCH, y: 0-3/INCH},
		],

		poly: [
			{points: [
				{x: 0+9.5/INCH, y: 0}, {x: 0+(9.5-6.415)/INCH, y: 0},
				{x: 0+(9.5-6.415)/INCH, y: 0-6.2125/INCH}, {x: 0+(9.5)/INCH, y: 0-6.2125/INCH},], 
				color: "bl", line: 0.04/INCH, score: 0},
		],

		text: [
			{x: 0+8.75/INCH, y: 0-(6.2125-.75)/INCH, size: 1/INCH, color: "bl", text: "S"},
			{x: 0+(9.5-6.415+0.75)/INCH, y: 0-(6.2125-.75)/INCH, size: 1/INCH, color: "bl", text: "S"},
		],

	};

	
	// Figure US
	
	targetfaces["USE"] = {
		name: "NATO E-Type",
		shortname: "NATO E-Type",
		dist: 300,
		dist_unit: "y",
		score: [1],
		board: {w: 1800, h: 1800, line: 10, score: 0},
		poly: [
			{points: [
				{x: -248.2, y: -505.9},
				{x: -248.2, y: 158.3},
				{x: -243.1, y: 176.3},
				{x: -231.1, y: 192.6},
				{x: -214.8, y: 206.3},
				{x: -194.3, y: 219.1},
				{x: -172.9, y: 228.5},
				{x: -152.4, y: 236.2},
				{x: -130.1, y: 243.1},
				{x: -108.7, y: 247.4},
				{x: -107.8, y: 471.6},
				{x: -99.3, y: 481.9},
				{x: -85.6, y: 493.0},
				{x: -70.2, y: 499.9},
				{x: -53.1, y: 505.9},
				{x: -30.8, y: 509.3},
				{x: -1.7, y: 511.9},
				{x: 20.5, y: 511.0},
				{x: 37.7, y: 508.4},
				{x: 57.3, y: 504.1},
				{x: 80.5, y: 494.7},
				{x: 97.6, y: 482.7},
				{x: 107.0, y: 469.1},
				{x: 107.8, y: 248.2},
				{x: 130.1, y: 243.1},
				{x: 151.5, y: 236.2},
				{x: 170.3, y: 229.4},
				{x: 192.6, y: 219.1},
				{x: 213.1, y: 208.0},
				{x: 229.4, y: 192.6},
				{x: 240.5, y: 176.3},
				{x: 247.4, y: 158.3},
				{x: 248.2, y: -505.0},
			], color: "b", line: 0, score: 1},
		],

	};

	targetfaces["SRCR"] = {
		name: "Figure 12 (SRCR)",
		shortname: "SRCR",
		dist: 600,
		dist_unit: "y",
		score: ["V", 5],
		board: {w: 1800, h: 1800, line: 10, score: 0},
		rings: [	{diam: 6/INCH, color: "b", line: 3, score: "V"},
					{diam: 10/INCH, color: "b", line: 3, score: 5},
					{diam: 15.875/INCH, color: "b", line: 3, score: 4}
		],
		poly: [
			{points: [
				{x: -219, y: -565},
				{x: -219, y: 375},
				{x: -100, y: 565},
				{x: 100, y: 565},
				{x: 219, y: 375},
				{x: 219, y: -565},
			], color: "w", line: 5, score: 3},
		],
		default_ring_text: true,

	};

	// Figure UK

	targetfaces["Fig11SR"] = {
		name: "Figure 11 Short Range",
		shortname: "Fig. 11 (SR)",
		dist: 300,
		dist_unit: "y",
		score: [5],
		board: {w: 1800, h: 1800, line: 10, score: 0},
		rings: [	{diam: 80, color: "b", line: 3, score: 5},
					{diam: 160, color: "b", line: 3, score: 5},
					{diam: 240, color: "b", line: 3, score: 5},
					{diam: 300, color: "bl", line: 3, score: 4}
		],
		poly: [
			{points: [
				{x: -227.5, y: -376},
				{x: -227.5, y: 376},
				{x: -102, y: 572.5},
				{x: 102, y: 572.5},
				{x: 227.5, y: 376},
				{x: 227.5, y: -376},
				{x: 102, y: -572.5},
				{x: -102, y: -572.5}
			], color: "w", line: 5, score: 4},
		],
		default_ring_text: true,

	};

	targetfaces["Fig11LR"] = {
		name: "Figure 11 Long Range",
		shortname: "Fig. 11 (LR)",
		dist: 600,
		dist_unit: "y",
		score: [5],
		board: {w: 1800, h: 1800, line: 10, score: 0},
		rings: [	{diam: 80, color: "b", line: 3, score: 5},
					{diam: 160, color: "b", line: 3, score: 5},
					{diam: 240, color: "b", line: 3, score: 5},
					{diam: 300, color: "b", line: 3, score: 5}
		],
		poly: [
			{points: [
				{x: -227.5, y: -376},
				{x: -227.5, y: 376},
				{x: -102, y: 572.5},
				{x: 102, y: 572.5},
				{x: 227.5, y: 376},
				{x: 227.5, y: -376},
				{x: 102, y: -572.5},
				{x: -102, y: -572.5}
			], color: "w", line: 5, score: 4},
		],
		default_ring_text: true,

	};


	targetfaces["Fig11LRx2"] = {
		name: "Figure 11 LR x2",
		shortname: "Fig. 11 (LR) x2",
		dist: 300,
		dist_unit: "y",
		score: [5],
		board: {w: 1800, h: 1800, line: 10, score: 0},
		rings: [	{x: -455, diam: 80, color: "b", line: 3, score: 5},
					{x: -455, diam: 160, color: "b", line: 3, score: 5},
					{x: -455, diam: 240, color: "b", line: 3, score: 5},
					{x: -455, diam: 300, color: "b", line: 3, score: 5},
					{x: 455, diam: 80, color: "b", line: 3, score: 5},
					{x: 455, diam: 160, color: "b", line: 3, score: 5},
					{x: 455, diam: 240, color: "b", line: 3, score: 5},
					{x: 455, diam: 300, color: "b", line: 3, score: 5}
		],
		poly: [
			{points: [
				{x: -227.5-455, y: -376},
				{x: -227.5-455, y: 376},
				{x: -102-455, y: 572.5},
				{x: 102-455, y: 572.5},
				{x: 227.5-455, y: 376},
				{x: 227.5-455, y: -376},
				{x: 102-455, y: -572.5},
				{x: -102-455, y: -572.5}
			], color: "w", line: 5, score: 4},
			{points: [
				{x: -227.5+455, y: -376},
				{x: -227.5+455, y: 376},
				{x: -102+455, y: 572.5},
				{x: 102+455, y: 572.5},
				{x: 227.5+455, y: 376},
				{x: 227.5+455, y: -376},
				{x: 102+455, y: -572.5},
				{x: -102+455, y: -572.5}
			], color: "w", line: 5, score: 4},
		],
		default_ring_text: true,
		force_colors: true

	};
	
	targetfaces["Fig11LRx3A"] = {
		name: "Figure 11 LR x3A",
		shortname: "Fig. 11 (LR) x3A",
		dist: 600,
		dist_unit: "y",
		score: [5],
		board: {w: 1800, h: 1800, line: 10, score: 0},
		rings: [	{diam: 80, color: "b", line: 3, score: 5},
					{diam: 160, color: "b", line: 3, score: 5},
					{diam: 240, color: "b", line: 3, score: 5},
					{diam: 300, color: "b", line: 3, score: 5}
		],
		poly: [
			{points: [
				{x: -227.5, y: -376},
				{x: -227.5, y: 376},
				{x: -102, y: 572.5},
				{x: 102, y: 572.5},
				{x: 227.5, y: 376},
				{x: 227.5, y: -376},
				{x: 102, y: -572.5},
				{x: -102, y: -572.5}
			], color: "w", line: 5, score: 4},
			{points: [
				{x: -227.5-455, y: -376},
				{x: -227.5-455, y: 376},
				{x: -102-455, y: 572.5},
				{x: 102-455, y: 572.5},
				{x: 227.5-455, y: 376},
				{x: 227.5-455, y: -376},
				{x: 102-455, y: -572.5},
				{x: -102-455, y: -572.5}
			], color: "w", line: 5, score: 2},
			{points: [
				{x: -227.5+455, y: -376},
				{x: -227.5+455, y: 376},
				{x: -102+455, y: 572.5},
				{x: 102+455, y: 572.5},
				{x: 227.5+455, y: 376},
				{x: 227.5+455, y: -376},
				{x: 102+455, y: -572.5},
				{x: -102+455, y: -572.5}
			], color: "w", line: 5, score: 2},
		],
		default_ring_text: true,

	};
	
	targetfaces["Fig11LRx3B"] = {
		name: "Figure 11 LR x3B",
		shortname: "Fig. 11 (LR) x3B",
		dist: 600,
		dist_unit: "y",
		score: [5],
		board: {w: 1800, h: 1800, line: 10, score: 0},
		rings: [	{x: -455, diam: 80, color: "b", line: 3, score: 5},
					{x: -455, diam: 160, color: "b", line: 3, score: 5},
					{x: -455, diam: 240, color: "b", line: 3, score: 5},
					{x: -455, diam: 300, color: "b", line: 3, score: 5},
					{x: 455, diam: 80, color: "b", line: 3, score: 5},
					{x: 455, diam: 160, color: "b", line: 3, score: 5},
					{x: 455, diam: 240, color: "b", line: 3, score: 5},
					{x: 455, diam: 300, color: "b", line: 3, score: 5}
		],
		poly: [
			{points: [
				{x: -227.5, y: -376},
				{x: -227.5, y: 376},
				{x: -102, y: 572.5},
				{x: 102, y: 572.5},
				{x: 227.5, y: 376},
				{x: 227.5, y: -376},
				{x: 102, y: -572.5},
				{x: -102, y: -572.5}
			], color: "w", line: 5, score: 2},
			{points: [
				{x: -227.5-455, y: -376},
				{x: -227.5-455, y: 376},
				{x: -102-455, y: 572.5},
				{x: 102-455, y: 572.5},
				{x: 227.5-455, y: 376},
				{x: 227.5-455, y: -376},
				{x: 102-455, y: -572.5},
				{x: -102-455, y: -572.5}
			], color: "w", line: 5, score: 4},
			{points: [
				{x: -227.5+455, y: -376},
				{x: -227.5+455, y: 376},
				{x: -102+455, y: 572.5},
				{x: 102+455, y: 572.5},
				{x: 227.5+455, y: 376},
				{x: 227.5+455, y: -376},
				{x: 102+455, y: -572.5},
				{x: -102+455, y: -572.5}
			], color: "w", line: 5, score: 4},
		],
		default_ring_text: true,
		force_colors: true
	};

	targetfaces["Fig11LRx3C"] = {
		name: "Figure 11 LR x3C",
		shortname: "Fig. 11 (LR) x3C",
		dist: 600,
		dist_unit: "y",
		score: [5],
		board: {w: 1800, h: 1800, line: 10, score: 0},
		rings: [	{x: -455, diam: 80, color: "b", line: 3, score: 5},
					{x: -455, diam: 160, color: "b", line: 3, score: 5},
					{x: -455, diam: 240, color: "b", line: 3, score: 5},
					{x: -455, diam: 300, color: "b", line: 3, score: 5},
					{x: 455, diam: 80, color: "b", line: 3, score: 5},
					{x: 455, diam: 160, color: "b", line: 3, score: 5},
					{x: 455, diam: 240, color: "b", line: 3, score: 5},
					{x: 455, diam: 300, color: "b", line: 3, score: 5},
					{diam: 80, color: "b", line: 3, score: 5},
					{diam: 160, color: "b", line: 3, score: 5},
					{diam: 240, color: "b", line: 3, score: 5},
					{diam: 300, color: "b", line: 3, score: 5},
		],
		poly: [
			{points: [
				{x: -227.5, y: -376},
				{x: -227.5, y: 376},
				{x: -102, y: 572.5},
				{x: 102, y: 572.5},
				{x: 227.5, y: 376},
				{x: 227.5, y: -376},
				{x: 102, y: -572.5},
				{x: -102, y: -572.5}
			], color: "w", line: 5, score: 2},
			{points: [
				{x: -227.5-455, y: -376},
				{x: -227.5-455, y: 376},
				{x: -102-455, y: 572.5},
				{x: 102-455, y: 572.5},
				{x: 227.5-455, y: 376},
				{x: 227.5-455, y: -376},
				{x: 102-455, y: -572.5},
				{x: -102-455, y: -572.5}
			], color: "w", line: 5, score: 4},
			{points: [
				{x: -227.5+455, y: -376},
				{x: -227.5+455, y: 376},
				{x: -102+455, y: 572.5},
				{x: 102+455, y: 572.5},
				{x: 227.5+455, y: 376},
				{x: 227.5+455, y: -376},
				{x: 102+455, y: -572.5},
				{x: -102+455, y: -572.5}
			], color: "w", line: 5, score: 4},
		],
		default_ring_text: true,
		force_colors: true
	};

	
	targetfaces["Fig11LRx5"] = {
		name: "Figure 11 LR x5",
		shortname: "Fig. 11 (LR) x5",
		dist: 600,
		dist_unit: "y",
		score: [5],
		board: {w: 2500, h: 1800, line: 10, score: 0},
		rings: [	{x: -455, diam: 80, color: "b", line: 3, score: 5},
					{x: -455, diam: 160, color: "b", line: 3, score: 4},
					{x: -455, diam: 240, color: "b", line: 3, score: 3},
					{x: -455, diam: 300, color: "b", line: 3, score: 2},
					{x: 455, diam: 80, color: "b", line: 3, score: 5},
					{x: 455, diam: 160, color: "b", line: 3, score: 4},
					{x: 455, diam: 240, color: "b", line: 3, score: 3},
					{x: 455, diam: 300, color: "b", line: 3, score: 2},
					{x: 0, diam: 80, color: "b", line: 3, score: 5},
					{x: 0, diam: 160, color: "b", line: 3, score: 4},
					{x: 0, diam: 240, color: "b", line: 3, score: 3},
					{x: 0, diam: 300, color: "b", line: 3, score: 2},
					{x: -910, diam: 80, color: "b", line: 3, score: 5},
					{x: -910, diam: 160, color: "b", line: 3, score: 4},
					{x: -910, diam: 240, color: "b", line: 3, score: 3},
					{x: -910, diam: 300, color: "b", line: 3, score: 2},
					{x: 910, diam: 80, color: "b", line: 3, score: 5},
					{x: 910, diam: 160, color: "b", line: 3, score: 4},
					{x: 910, diam: 240, color: "b", line: 3, score: 3},
					{x: 910, diam: 300, color: "b", line: 3, score: 2},
		],
		poly: [
			{points: [
				{x: -227.5, y: -376},
				{x: -227.5, y: 376},
				{x: -102, y: 572.5},
				{x: 102, y: 572.5},
				{x: 227.5, y: 376},
				{x: 227.5, y: -376},
				{x: 102, y: -572.5},
				{x: -102, y: -572.5}
			], color: "w", line: 5, score: 1},
			{points: [
				{x: -227.5-455, y: -376},
				{x: -227.5-455, y: 376},
				{x: -102-455, y: 572.5},
				{x: 102-455, y: 572.5},
				{x: 227.5-455, y: 376},
				{x: 227.5-455, y: -376},
				{x: 102-455, y: -572.5},
				{x: -102-455, y: -572.5}
			], color: "w", line: 5, score: 1},
			{points: [
				{x: -227.5+455, y: -376},
				{x: -227.5+455, y: 376},
				{x: -102+455, y: 572.5},
				{x: 102+455, y: 572.5},
				{x: 227.5+455, y: 376},
				{x: 227.5+455, y: -376},
				{x: 102+455, y: -572.5},
				{x: -102+455, y: -572.5}
			], color: "w", line: 5, score: 1},
			{points: [
				{x: -227.5-910, y: -376},
				{x: -227.5-910, y: 376},
				{x: -102-910, y: 572.5},
				{x: 102-910, y: 572.5},
				{x: 227.5-910, y: 376},
				{x: 227.5-910, y: -376},
				{x: 102-910, y: -572.5},
				{x: -102-910, y: -572.5}
			], color: "w", line: 5, score: 1},
			{points: [
				{x: -227.5+910, y: -376},
				{x: -227.5+910, y: 376},
				{x: -102+910, y: 572.5},
				{x: 102+910, y: 572.5},
				{x: 227.5+910, y: 376},
				{x: 227.5+910, y: -376},
				{x: 102+910, y: -572.5},
				{x: -102+910, y: -572.5}
			], color: "w", line: 5, score: 1},
		],
		default_ring_text: true,
		force_colors: true
	};

	targetfaces["Fig11A"] = {
		name: "Figure 11A",
		shortname: "Fig. 11A",
		dist: 100,
		dist_unit: "y",
		score: [5],
		board: {w: 1200, h: 1200, line: 10, score: 0},
		rings: [	{diam: 25, color: "b", line: 1, score: 5},
					{diam: 50, color: "b", line: 1, score: 4},
					{diam: 75, color: "b", line: 1, score: 3},
					{diam: 95, color: "bl", line: 1, score: 2}
		],
		poly: [
			{points: [
				{x: -75, y: -125},
				{x: -75, y: 125},
				{x: -34, y: 189},
				{x: 34, y: 189},
				{x: 75, y: 125},
				{x: 75, y: -125},
				{x: 34, y: -189},
				{x: -34, y: -189}
			], color: "w", line: 2, score: 2},
		],
		default_ring_text: true,

	};

	targetfaces["Fig11B"] = {
		name: "Figure 11B",
		shortname: "Fig. 11B",
		dist: 200,
		dist_unit: "y",
		score: [5],
		board: {w: 1200, h: 1200, line: 10, score: 0},
		rings: [	{diam: 40, color: "b", line: 1, score: 5},
					{diam: 80, color: "b", line: 1, score: 4},
					{diam: 120, color: "b", line: 1, score: 3},
					{diam: 150, color: "bl", line: 1, score: 2}
		],
		poly: [
			{points: [
				{x: -115, y: -188},
				{x: -115, y: 188},
				{x: -52, y: 285},
				{x: 52, y: 285},
				{x: 115, y: 188},
				{x: 115, y: -188},
				{x: 52, y: -285},
				{x: -52, y: -285}
			], color: "w", line: 2, score: 2},
		],
		default_ring_text: true,

	};
	
	targetfaces["Fig12"] = {
		name: "Figure 12",
		shortname: "Fig. 12",
		dist: 300,
		dist_unit: "y",
		score: [5],
		board: {w: 1200, h: 1200, line: 5, score: 0},
		rings: [	{diam: 240, color: "b", line: 2, score: 5},
					{diam: 300, color: "b", line: 2, score: 4}
		],
		poly: [
			{points: [
				{x: -227.5, y: -260},
				{x: -227.5, y: 113},
				{x: -95, y: 300},
				{x: 95, y: 300},
				{x: 227.5, y: 113},
				{x: 227.5, y: -260}
			], color: "w", line: 3, score: 4},
		],
		default_ring_text: true,

	};

	targetfaces["Fig12B"] = {
		name: "Figure 12B",
		shortname: "Fig. 12B",
		dist: 200,
		dist_unit: "y",
		score: [5],
		board: {w: 1200, h: 1200, line: 5, score: 0},
		rings: [	{diam: 120, color: "b", line: 2, score: 5},
					{diam: 150, color: "b", line: 2, score: 5}
		],
		poly: [
			{points: [
				{x: -115, y: -142.5},
				{x: -115, y: 48},
				{x: -58, y: 142.5},
				{x: 58, y: 142.5},
				{x: 115, y: 48},
				{x: 115, y: -142.5}
			], color: "w", line: 3, score: 2},
		],
		default_ring_text: true,

	};

	targetfaces["Fig12C"] = {
		name: "Figure 12C",
		shortname: "Fig. 12C",
		dist: 300,
		dist_unit: "y",
		score: [5],
		board: {w: 1200, h: 1200, line: 5, score: 0},
		rings: [	{diam: 150, color: "b", line: 2, score: 5},
					{diam: 200, color: "b", line: 2, score: 5}
		],
		poly: [
			{points: [
				{x: -162.5, y: -202.5},
				{x: -162.5, y: 68},
				{x: -82, y: 202.5},
				{x: 82, y: 202.5},
				{x: 162.5, y: 68},
				{x: 162.5, y: -202.5}
			], color: "w", line: 4, score: 4},
		],
		default_ring_text: true,

	};


	targetfaces["Fig1259C"] = {
		name: "Figure 12/59C",
		shortname: "Fig. 12/59C",
		dist: 100,
		dist_unit: "m",
		score: [5],
		board: {w: 1200, h: 1200, line: 5, score: 0},
		rings: [	{diam: 150, color: "b", line: 2, score: 5},
					{diam: 300, color: "b", line: 2, score: 4}
		],
		poly: [ // +/- 230, 280
			{points: [
				{x: -230, y: -260},
				{x: -230, y: 100},
				{x: -100, y: 300},
				{x: 100, y: 300},
				{x: 230, y: 100},
				{x: 230, y: -260}
			], color: "w", line: 2, score: 3},
		],
		default_ring_text: true,

	};


	targetfaces["Fig14"] = {
		name: "Figure 14",
		shortname: "Fig. 14",
		dist: 300,
		dist_unit: "y",
		score: [5],
		board: {w: 1200, h: 1200, line: 5, score: 0},
		rings: [	{diam: 100, color: "bl", line: 4, score: 5}
		],
		poly: [
			{points: [
				{x: 0 -128, y: -285 +138},
				{x: 17 -128, y: -250 +138},
				{x: 41 -128, y: -232 +138},
				{x: 44 -128, y: -210 +138},
				{x: 29 -128, y: -165 +138},
				{x: 37 -128, y: -150 +138},
				{x: 102 -128, y: -118 +138},
				{x: 128- 102, y: -118 +138},
				{x: 128- 37, y: -150 +138},
				{x: 128- 29, y: -165 +138},
				{x: 128- 44, y: -210 +138},
				{x: 128- 41, y: -232 +138},
				{x: 128- 17, y: -250 +138},
				{x: 128- 0, y: -285 +138},
			], color: "g", line: 4, score: 4},
			{points: [
				{x: 37 -128, y: -150 +138},
				{x: 56 -128, y: -53 +138},
				{x: 76 -128, y: -14 +138},
				{x: 100 -128, y: 0 +138},
				{x: 128- 100, y: 0 +138},
				{x: 128- 76, y: -14 +138},
				{x: 128- 56, y: -53 +138},
				{x: 128- 37, y: -150 +138},
				{x: 128- 102, y: -118 +138},
				{x: 102 -128, y: -118 +138},
			], color: "w", line: 4, score: 4},
		],
	};
	
	targetfaces["Fig14W"] = {
		name: "Figure 14 Window",
		shortname: "Fig. 14W",
		dist: 300,
		dist_unit: "y",
		score: [5],
		board: {w: 1200, h: 1200, line: 5, score: 0},
		rings: [	{diam: 100, color: "bl", line: 4, score: 5}
		],
		poly: [
			{points: [
				{x: 0 -128, y: -285 +138 -37},
				{x: 17 -128, y: -250 +138 -37},
				{x: 41 -128, y: -232 +138 -37},
				{x: 44 -128, y: -210 +138 -37},
				{x: 29 -128, y: -165 +138 -37},
				{x: 37 -128, y: -150 +138 -37},
				{x: 102 -128, y: -118 +138 -37},
				{x: 128- 102, y: -118 +138 -37},
				{x: 128- 37, y: -150 +138 -37},
				{x: 128- 29, y: -165 +138 -37},
				{x: 128- 44, y: -210 +138 -37},
				{x: 128- 41, y: -232 +138 -37},
				{x: 128- 17, y: -250 +138 -37},
				{x: 128- 0, y: -285 +138 -37},
			], color: "g", line: 4, score: 4},
			{points: [
				{x: 37 -128, y: -150 +138 -37},
				{x: 56 -128, y: -53 +138 -37},
				{x: 76 -128, y: -14 +138 -37},
				{x: 100 -128, y: 0 +138 -37},
				{x: 128- 100, y: 0 +138 -37},
				{x: 128- 76, y: -14 +138 -37},
				{x: 128- 56, y: -53 +138 -37},
				{x: 128- 37, y: -150 +138 -37},
				{x: 128- 102, y: -118 +138 -37},
				{x: 102 -128, y: -118 +138 -37},
			], color: "w", line: 4, score: 4},
			{points: [
				{x: -227.5, y: -185},
				{x: -227.5, y: 185},
				{x: 227.5, y: 185},
				{x: 227.5, y: -185}
			], color: "w", line: 4, score: 3},
		],
	};


	// for brian harder, us appendix 9
	targetfaces["A9EIC"] = {
		name: "A9 Combat EIC",
		shortname: "EIC",
		dist: 300,
		dist_unit: "y",
		score: [5, "X", "F"],
		board: {w: 24/INCH, h: 40/INCH, line: 0, score: 0},
		
		poly: [

			{ points: polyarc(0, 0.375/INCH, 1.125/INCH, 0, 180, 10)
			.concat(polyarc(0, -0.375/INCH, 1.125/INCH, 180, 360, 10))
			, color: "wl", line: 2, score: "X"},

			{ points: polyarc(0, 1/INCH, 2/INCH, 0, 180, 10)
			.concat(polyarc(0, -1/INCH, 2/INCH, 180, 360, 10))
			, color: "b", line: 2, score: 5},
						
			{ points: polyarc(0, 1.625/INCH, 4/INCH, 0, 180, 10)
			.concat(polyarc(0, -1.625/INCH, 4/INCH, 180, 360, 10))
			, color: "b", line: 2, score: 4},

			{ points: polyarc(0, 3/INCH, 6/INCH, 0, 180, 10)
			.concat(polyarc(0, -3/INCH, 6/INCH, 180, 360, 10))
			, color: "b", line: 2, score: 3},

			//face
			{ points: polyarc(0, 349+1/INCH, 2/INCH, 0, 180, 10)
			.concat(polyarc(0, 349-1/INCH, 2/INCH, 180, 360, 10))
			, color: "b", line: 2, score: "F"},

			//Body
			{points: [

				{x: -249.5, y: -408.1},
				{x: -250.9, y: 125.5},
				{x: -233.7, y: 151.6},
				{x: -215.1, y: 172.3},
				{x: -192.3, y: 188.9},
				{x: -165.4, y: 202.0},
				{x: -143.4, y: 207.5},
				{x: -126.8, y: 219.2},
				{x: -115.8, y: 238.5},
				{x: -111.7, y: 263.3},
				{x: -111.7, y: 427.4},
				{x: -93.7, y: 442.5},
				{x: -75.8, y: 452.9},
				{x: -51.0, y: 461.8},
				{x: -26.2, y: 466.6},
				{x: -2.8, y: 468.0},
				{x: 17.9, y: 467.3},
				{x: 44.8, y: 463.2},
				{x: 68.9, y: 455.6},
				{x: 89.6, y: 445.3},
				{x: 108.9, y: 428.7},
				{x: 111.0, y: 264.7},
				{x: 115.1, y: 241.9},
				{x: 126.8, y: 221.3},
				{x: 144.8, y: 208.2},
				{x: 167.5, y: 202.0},
				{x: 186.1, y: 193.0},
				{x: 201.3, y: 182.7},
				{x: 215.7, y: 172.3},
				{x: 231.6, y: 154.4},
				{x: 250.9, y: 128.2},
				{x: 251.6, y: -408.7},

			], color: "b", line: 0, score: 2},

		],

		text: [
			{x: 0, y: 0, size: 20, color: "wl", text: "X"},
			{x: 37, y: 0, size: 20, color: "wl", text: "5"},
			{x: -37, y: 0, size: 20, color: "wl", text: "5"},
		].concat(text_rings({x: 75, y: 0}, {x: 2/INCH, y: 0}, 4, 2, {size: 20, color: "wl"}))
		.concat(text_rings({x: -75, y: 0}, {x: -2/INCH, y: 0}, 4, 2, {size: 20, color: "wl"}))
	};

	targetfaces["A9Fig11"] = {
		name: "A9 Figure 11 Rifle",
		shortname: "Fig 11-R",
		dist: 300,
		dist_unit: "y",
		score: [5, "V"],
		board: {w: 24/INCH, h: 48/INCH, line: 0, score: 0},
		
		rings: [	{diam: 6/INCH, color: "b", line: 3, score: "V"},
					{diam: 10/INCH, color: "b", line: 3, score: 5},
					{diam: 15.5/INCH, color: "b", line: 2, score: 4}
		],
		poly: [
			{points: [
				{x: -227.5, y: -23/INCH},
				{x: -227.5, y: 376},
				{x: -102, y: 23/INCH},
				{x: 102, y: 23/INCH},
				{x: 227.5, y: 376},
				{x: 227.5, y: -23/INCH},
			], color: "w", line: 5, score: 3},
		],

		default_ring_text: true,
	};

	targetfaces["A9Fig11P"] = {
		name: "A9 Figure 11 Pistol",
		shortname: "Fig 11-P",
		dist: 300,
		dist_unit: "y",
		score: [5, "F"],
		board: {w: 24/INCH, h: 48/INCH, line: 1, score: 0},

		rings: [	{diam: 4/INCH, color: "b", line: 3, score: 5},
					{diam: 6/INCH, color: "b", line: 3, score: 4},
					{diam: 8/INCH, color: "b", line: 3, score: 3},
		
		],
		poly: [

			{points: [
				{x: -33.1, y: 247.5},
				{x: -0.9, y: 245.7},
				{x: 21.4, y: 253.7},
				{x: 39.3, y: 265.3},
				{x: 100.1, y: 388.6},
				{x: 60.7, y: 406.5},
				{x: 32.2, y: 417.2},
				{x: -4.5, y: 425.2},
				{x: -27.7, y: 428.8},
				{x: -58.1, y: 427.9},
				{x: -93.8, y: 419.9},
				{x: -103.6, y: 414.5},
				{x: -102.7, y: 362.7},
				{x: -93.8, y: 317.1},
				{x: -81.3, y: 292.1},
				{x: -62.5, y: 267.1},
			], color: "bl", line: 5, score: "F"},

			{points: [
				{x: -8.5/INCH, y: -376},
				{x: -8.5/INCH, y: 376},
				{x: -102, y: 22/INCH},
				{x: 102, y: 22/INCH},
				{x: 8.5/INCH, y: 376},
				{x: 8.5/INCH, y: -376},
				{x: 102, y: -22/INCH},
				{x: -102, y: -22/INCH}
			], color: "w", line: 5, score: 2},
		],

		default_ring_text: true,

	};

	targetfaces["A9Fig12"] = {
		name: "A9 Figure 12",
		shortname: "Fig 12",
		dist: 300,
		dist_unit: "y",
		score: [5, "V"],
		board: {w: 24/INCH, h: 24/INCH, line: 0, score: 0},

		rings: [	
				{diam: 6/INCH, color: "b", line: 4, score: "V"},
				{diam: 10/INCH, color: "b", line: 4, score: 5},
				{diam: 15.5/INCH, color: "b", line: 4, score: 4}
		],
		poly: [
			{points: [
				{x: -9/INCH, y: -11/INCH},
				{x: -9/INCH, y: 113},
				{x: -95, y: 11/INCH},
				{x: 95, y: 11/INCH},
				{x: 9/INCH, y: 113},
				{x: 9/INCH, y: -11/INCH},
			], color: "bl", line: 3, score: 3},
		],

		default_ring_text: true,

	};

	targetfaces["A9Fig14"] = {
		name: "A9 Figure 14",
		shortname: "Fig 14",
		dist: 300,
		dist_unit: "y",
		score: [5],
		board: {w: 24/INCH, h: 24/INCH, line: 0, score: 0},

		poly: [
			{points: [
				{x: -0.4, y: 7.4},
				{x: 24.4, y: 7.0},
				{x: 48.4, y: 3.1},
				{x: 69.7, y: -8.3},
				{x: 82.4, y: -20.0},
				{x: 90.2, y: -35.7},
				{x: 91.5, y: -54.9},
				{x: 91.5, y: -82.8},
				{x: 92.8, y: -97.6},
				{x: 96.8, y: -111.6},
				{x: 98.9, y: -122.0},
				{x: 96.8, y: -139.9},
				{x: 86.3, y: -164.7},
				{x: 82.4, y: -185.2},
				{x: 85.0, y: -197.4},
				{x: 91.5, y: -217.5},
				{x: 103.7, y: -236.2},
				{x: 114.6, y: -248.0},
				{x: 130.8, y: -263.2},
				{x: 134.7, y: -272.4},
				{x: -122.9, y: -272.4},
				{x: -118.5, y: -260.6},
				{x: -106.3, y: -248.9},
				{x: -92.8, y: -231.4},
				{x: -82.8, y: -206.6},
				{x: -74.5, y: -183.5},
				{x: -77.1, y: -167.8},
				{x: -89.8, y: -139.0},
				{x: -90.7, y: -125.1},
				{x: -88.9, y: -114.2},
				{x: -85.4, y: -93.7},
				{x: -83.2, y: -65.8},
				{x: -82.4, y: -41.0},
				{x: -78.0, y: -25.3},
				{x: -64.5, y: -14.4},
				{x: -44.5, y: -0.4},
				{x: -22.7, y: 6.1},
			], color: "bl", line: 3, score: 4},

			{points: [
				{x: -9/INCH, y: -11/INCH},
				{x: -9/INCH, y: 113},
				{x: -95, y: 11/INCH},
				{x: 95, y: 11/INCH},
				{x: 9/INCH, y: 113},
				{x: 9/INCH, y: -11/INCH},
			], color: "bl", line: 3, score: 0},
		],
		rings: [
			{diam: 4/INCH, color: "bl", line: 0.6, x: 0, y: -5/INCH, score: 5},
		],

	};

	targetfaces["A9Fig22"] = {
		name: "A9 Figure 22",
		shortname: "Fig 22",
		dist: 300,
		dist_unit: "y",
		score: [5],
		board: {w: 24/INCH, h: 24/INCH, line: 0, score: 0},

		//face 5
		rings: [	
				{diam: 3/INCH, color: "bl", line: 3, x: 0, y: 7.5/INCH, score: 5},
		],
		
		poly: [
			//face 4
			{points: [
				{x: -18.6, y: 58.3},
				{x: 19.1, y: 57.3},
				{x: 30.3, y: 63.9},
				{x: 30.3, y: 139.4},
				{x: 51.8, y: 160.4},
				{x: 51.8, y: 228.5},
				{x: 43.4, y: 242.0},
				{x: 32.6, y: 253.2},
				{x: 20.5, y: 261.6},
				{x: 2.8, y: 264.4},
				{x: -14.0, y: 261.6},
				{x: -29.4, y: 254.6},
				{x: -40.6, y: 242.9},
				{x: -48.0, y: 230.8},
				{x: -49.9, y: 161.3},
				{x: -28.4, y: 139.9},
				{x: -28.4, y: 65.7},
			], color: "bl", line: 3, score: 4},

			//Face 3		
			{points: [
				{x: -20.0, y: 59.2},
				{x: 20.5, y: 56.9},
				{x: 31.2, y: 63.4},
				{x: 55.5, y: 87.2},
				{x: 63.9, y: 104.0},
				{x: 66.7, y: 138.0},
				{x: 72.7, y: 136.1},
				{x: 76.5, y: 138.9},
				{x: 76.5, y: 149.2},
				{x: 83.0, y: 157.1},
				{x: 84.9, y: 189.3},
				{x: 82.1, y: 193.5},
				{x: 76.5, y: 194.9},
				{x: 72.3, y: 192.1},
				{x: 72.7, y: 236.4},
				{x: 66.7, y: 252.2},
				{x: 57.3, y: 265.3},
				{x: 44.8, y: 275.1},
				{x: 25.6, y: 285.8},
				{x: 5.6, y: 290.0},
				{x: -6.1, y: 290.0},
				{x: -19.6, y: 286.7},
				{x: -34.0, y: 280.2},
				{x: -46.6, y: 272.3},
				{x: -58.7, y: 260.6},
				{x: -65.7, y: 249.9},
				{x: -69.0, y: 242.4},
				{x: -70.4, y: 227.5},
				{x: -69.9, y: 192.1},
				{x: -76.0, y: 196.8},
				{x: -80.2, y: 192.6},
				{x: -81.1, y: 172.5},
				{x: -80.7, y: 158.1},
				{x: -73.7, y: 150.1},
				{x: -71.3, y: 136.6},
				{x: -66.7, y: 135.7},
				{x: -62.5, y: 137.5},
				{x: -61.1, y: 111.0},
				{x: -52.2, y: 86.3},
				{x: -39.6, y: 71.8},

			], color: "bl", line: 3, score: 3},

			//body2
			{points: [
				{x: 1.9, y: -1.9},
				{x: 24.2, y: -1.9},
				{x: 45.7, y: -9.8},
				{x: 64.8, y: -21.9},
				{x: 80.7, y: -46.2},
				{x: 84.9, y: -51.8},
				{x: 86.7, y: -164.6},
				{x: 70.9, y: -193.5},
				{x: 44.3, y: -210.7},
				{x: 12.6, y: -217.7},
				{x: -21.4, y: -217.3},
				{x: -45.7, y: -207.0},
				{x: -69.9, y: -187.0},
				{x: -83.0, y: -166.4},
				{x: -83.0, y: -52.7},
				{x: -68.5, y: -27.0},
				{x: -50.4, y: -14.0},
				{x: -22.8, y: -1.9},

			], color: "bl", line: 3, score: 3},

			//body 1
			{points: [
				{x: -28.0, y: 63.4},
				{x: -21.4, y: 57.8},
				{x: 21.4, y: 57.8},
				{x: 32.6, y: 62.5},
				{x: 119.4, y: -40.1},
				{x: 120.3, y: -212.1},
				{x: 114.7, y: -233.1},
				{x: 94.6, y: -255.5},
				{x: 67.1, y: -269.5},
				{x: 33.6, y: -280.7},
				{x: 6.1, y: -282.1},
				{x: -21.4, y: -280.7},
				{x: -55.0, y: -273.7},
				{x: -75.1, y: -265.3},
				{x: -96.0, y: -252.7},
				{x: -115.2, y: -222.9},
				{x: -116.6, y: -40.1},

			], color: "bl", line: 3, score: 2},

						//body outer
			{points: [
				{x: -51.3, y: 83.9},
				{x: -28.9, y: 62.9},
				{x: -18.6, y: 57.8},
				{x: 20.5, y: 56.9},
				{x: 31.2, y: 64.3},
				{x: 55.9, y: 88.1},
				{x: 55.9, y: 64.3},
				{x: 68.5, y: 41.0},
				{x: 94.6, y: 24.2},
				{x: 142.7, y: 11.7},
				{x: 180.4, y: 0.9},
				{x: 202.3, y: -8.4},
				{x: 221.9, y: -25.6},
				{x: 229.4, y: -37.3},
				{x: 229.4, y: -155.3},
				{x: 191.2, y: -202.3},
				{x: 185.1, y: -289.1},
				{x: -182.3, y: -289.5},
				{x: -187.9, y: -203.3},
				{x: -227.5, y: -153.9},
				{x: -227.1, y: -38.7},
				{x: -221.5, y: -23.8},
				{x: -202.3, y: -8.4},
				{x: -175.3, y: 2.3},
				{x: -148.7, y: 7.5},
				{x: -119.8, y: 16.8},
				{x: -92.8, y: 24.7},
				{x: -70.9, y: 35.0},
				{x: -57.3, y: 50.4},
				{x: -53.2, y: 65.7},

			], color: "bl", line: 3, score: 1},

			{points: [
				{x: -8.75/INCH, y: -11.5/INCH},
				{x: -8.75/INCH, y: 113},
				{x: -95, y: 11.5/INCH},
				{x: 95, y: 11.5/INCH},
				{x: 8.75/INCH, y: 113},
				{x: 8.75/INCH, y: -11.5/INCH},
			], color: "bl", line: 3, score: 0},
		],
	};


	// Figure (Australia)

	targetfaces["Fig11AU"] = {
		name: "Figure 11 (AU)",
		shortname: "Fig. 11",
		dist: 300,
		dist_unit: "y",
		score: [5],
		board: {w: 1210, h: 1210, line: 5, score: 0},
		poly: [
			{points: [
				{x: -115.2, y: 27.6},
				{x: -72.0, y: 169.2},
				{x: -64.8, y: 180.0},
				{x: -55.2, y: 190.8},
				{x: -43.2, y: 201.6},
				{x: -28.8, y: 208.8},
				{x: -15.6, y: 212.4},
				{x: 0.0, y: 213.6},
				{x: 14.4, y: 212.4},
				{x: 26.4, y: 208.8},
				{x: 39.6, y: 201.6},
				{x: 50.4, y: 193.2},
				{x: 62.4, y: 181.2},
				{x: 70.8, y: 165.6},
				{x: 112.8, y: 31.2},
				{x: 116.4, y: 14.4},
				{x: 117.6, y: -3.6},
				{x: 116.4, y: -21.6},
				{x: 111.6, y: -39.6},
				{x: 103.2, y: -55.2},
				{x: 96.0, y: -69.6},
				{x: 82.8, y: -85.2},
				{x: 68.4, y: -96.0},
				{x: 51.6, y: -106.8},
				{x: 33.6, y: -112.8},
				{x: 12.0, y: -116.4},
				{x: -10.8, y: -116.4},
				{x: -32.4, y: -114.0},
				{x: -50.4, y: -105.6},
				{x: -64.8, y: -98.4},
				{x: -78.0, y: -88.8},
				{x: -90.0, y: -75.6},
				{x: -100.8, y: -61.2},
				{x: -109.2, y: -46.8},
				{x: -114.0, y: -28.8},
				{x: -118.8, y: -10.8},
				{x: -118.8, y: 6.0},
			], color: "b", line: 2, score: 5},

			{points: [
				{x: -177.6, y: 1.2},
				{x: -176.4, y: 16.8},
				{x: -175.2, y: 31.2},
				{x: -172.8, y: 45.6},
				{x: -127.2, y: 187.2},
				{x: -122.4, y: 199.2},
				{x: -115.2, y: 211.2},
				{x: -105.6, y: 224.4},
				{x: -96.0, y: 234.0},
				{x: -84.0, y: 244.8},
				{x: -69.6, y: 253.2},
				{x: -55.2, y: 260.4},
				{x: -39.6, y: 266.4},
				{x: -22.8, y: 270.0},
				{x: -3.6, y: 271.2},
				{x: 13.2, y: 270.0},
				{x: 31.2, y: 267.6},
				{x: 49.2, y: 262.8},
				{x: 66.0, y: 255.6},
				{x: 81.6, y: 246.0},
				{x: 99.6, y: 230.4},
				{x: 112.8, y: 213.6},
				{x: 123.6, y: 195.6},
				{x: 129.6, y: 180.0},
				{x: 174.0, y: 40.8},
				{x: 176.4, y: 16.8},
				{x: 177.6, y: -3.6},
				{x: 175.2, y: -21.6},
				{x: 171.6, y: -40.8},
				{x: 168.0, y: -57.6},
				{x: 159.6, y: -76.8},
				{x: 150.0, y: -92.4},
				{x: 140.4, y: -108.0},
				{x: 127.2, y: -121.2},
				{x: 114.0, y: -135.6},
				{x: 98.4, y: -147.6},
				{x: 79.2, y: -157.2},
				{x: 61.2, y: -165.6},
				{x: 38.4, y: -172.8},
				{x: 14.4, y: -176.4},
				{x: -9.6, y: -176.4},
				{x: -31.2, y: -174.0},
				{x: -52.8, y: -169.2},
				{x: -72.0, y: -162.0},
				{x: -92.4, y: -151.2},
				{x: -112.8, y: -138.0},
				{x: -127.2, y: -124.8},
				{x: -139.2, y: -110.4},
				{x: -150.0, y: -94.8},
				{x: -160.8, y: -73.2},
				{x: -170.4, y: -52.8},
				{x: -174.0, y: -36.0},
				{x: -177.6, y: -19.2},
			], color: "b", line: 2, score: 4},
			{points: [
				{x: -225, y: -570},
				{x: -225, y: 383},
				{x: -106, y: 570},
				{x: 106, y: 570},
				{x: 225, y: 383},
				{x: 225, y: -570},
			], color: "g", line: 4, score: 3},
		],
		text: [
			{x: 0, y: -91, size: 50, color: "wl", text: "5"},
			{x: 0, y: -150, size: 50, color: "wl", text: "4"},
			{x: 0, y: -210, size: 50, color: "wl", text: "3"},
		]
	};
	
	targetfaces["Fig11DAU"] = {
		name: "Figure 11D (AU)",
		shortname: "Fig. 11D",
		dist: 300,
		dist_unit: "y",
		score: [5],
		board: {w: 1210, h: 1210, line: 5, score: 0},
		rings: [	{diam: 795, color: "bl", line: 4, score: 3},
					{diam: 1200, color: "bl", line: 4, score: 2}
		],
		poly_top: [
		
			{points: [
				{x: -115.2, y: 27.6},
				{x: -72.0, y: 169.2},
				{x: -64.8, y: 180.0},
				{x: -55.2, y: 190.8},
				{x: -43.2, y: 201.6},
				{x: -28.8, y: 208.8},
				{x: -15.6, y: 212.4},
				{x: 0.0, y: 213.6},
				{x: 14.4, y: 212.4},
				{x: 26.4, y: 208.8},
				{x: 39.6, y: 201.6},
				{x: 50.4, y: 193.2},
				{x: 62.4, y: 181.2},
				{x: 70.8, y: 165.6},
				{x: 112.8, y: 31.2},
				{x: 116.4, y: 14.4},
				{x: 117.6, y: -3.6},
				{x: 116.4, y: -21.6},
				{x: 111.6, y: -39.6},
				{x: 103.2, y: -55.2},
				{x: 96.0, y: -69.6},
				{x: 82.8, y: -85.2},
				{x: 68.4, y: -96.0},
				{x: 51.6, y: -106.8},
				{x: 33.6, y: -112.8},
				{x: 12.0, y: -116.4},
				{x: -10.8, y: -116.4},
				{x: -32.4, y: -114.0},
				{x: -50.4, y: -105.6},
				{x: -64.8, y: -98.4},
				{x: -78.0, y: -88.8},
				{x: -90.0, y: -75.6},
				{x: -100.8, y: -61.2},
				{x: -109.2, y: -46.8},
				{x: -114.0, y: -28.8},
				{x: -118.8, y: -10.8},
				{x: -118.8, y: 6.0},
			], color: "b", line: 2, score: 5},

			{points: [
				{x: -177.6, y: 1.2},
				{x: -176.4, y: 16.8},
				{x: -175.2, y: 31.2},
				{x: -172.8, y: 45.6},
				{x: -127.2, y: 187.2},
				{x: -122.4, y: 199.2},
				{x: -115.2, y: 211.2},
				{x: -105.6, y: 224.4},
				{x: -96.0, y: 234.0},
				{x: -84.0, y: 244.8},
				{x: -69.6, y: 253.2},
				{x: -55.2, y: 260.4},
				{x: -39.6, y: 266.4},
				{x: -22.8, y: 270.0},
				{x: -3.6, y: 271.2},
				{x: 13.2, y: 270.0},
				{x: 31.2, y: 267.6},
				{x: 49.2, y: 262.8},
				{x: 66.0, y: 255.6},
				{x: 81.6, y: 246.0},
				{x: 99.6, y: 230.4},
				{x: 112.8, y: 213.6},
				{x: 123.6, y: 195.6},
				{x: 129.6, y: 180.0},
				{x: 174.0, y: 40.8},
				{x: 176.4, y: 16.8},
				{x: 177.6, y: -3.6},
				{x: 175.2, y: -21.6},
				{x: 171.6, y: -40.8},
				{x: 168.0, y: -57.6},
				{x: 159.6, y: -76.8},
				{x: 150.0, y: -92.4},
				{x: 140.4, y: -108.0},
				{x: 127.2, y: -121.2},
				{x: 114.0, y: -135.6},
				{x: 98.4, y: -147.6},
				{x: 79.2, y: -157.2},
				{x: 61.2, y: -165.6},
				{x: 38.4, y: -172.8},
				{x: 14.4, y: -176.4},
				{x: -9.6, y: -176.4},
				{x: -31.2, y: -174.0},
				{x: -52.8, y: -169.2},
				{x: -72.0, y: -162.0},
				{x: -92.4, y: -151.2},
				{x: -112.8, y: -138.0},
				{x: -127.2, y: -124.8},
				{x: -139.2, y: -110.4},
				{x: -150.0, y: -94.8},
				{x: -160.8, y: -73.2},
				{x: -170.4, y: -52.8},
				{x: -174.0, y: -36.0},
				{x: -177.6, y: -19.2},
			], color: "b", line: 2, score: 4},
		],	
		poly: [
			{points: [
				{x: -225, y: -570},
				{x: -225, y: 383},
				{x: -106, y: 570},
				{x: 106, y: 570},
				{x: 225, y: 383},
				{x: 225, y: -570},
			], color: "g", line: 4},
		],
		text: [
			{x: 0, y: -91, size: 50, color: "wl", text: "5"},
			{x: 0, y: -150, size: 50, color: "wl", text: "4"},
			{x: 0, y: -210, size: 50, color: "wl", text: "3"},
			{x: 0, y: -490, size: 50, color: "wl", text: "2"},
		]		
	};


	targetfaces["Fig12AU"] = {
		name: "Figure 12 (AU)",
		shortname: "Fig. 12",
		dist: 300,
		dist_unit: "y",
		score: [5],
		board: {w: 1210, h: 1210, line: 5, score: 0},
		poly: [
			{points: [
				{x: -115.2, y: 27.6},
				{x: -72.0, y: 169.2},
				{x: -64.8, y: 180.0},
				{x: -55.2, y: 190.8},
				{x: -43.2, y: 201.6},
				{x: -28.8, y: 208.8},
				{x: -15.6, y: 212.4},
				{x: 0.0, y: 213.6},
				{x: 14.4, y: 212.4},
				{x: 26.4, y: 208.8},
				{x: 39.6, y: 201.6},
				{x: 50.4, y: 193.2},
				{x: 62.4, y: 181.2},
				{x: 70.8, y: 165.6},
				{x: 112.8, y: 31.2},
				{x: 116.4, y: 14.4},
				{x: 117.6, y: -3.6},
				{x: 116.4, y: -21.6},
				{x: 111.6, y: -39.6},
				{x: 103.2, y: -55.2},
				{x: 96.0, y: -69.6},
				{x: 82.8, y: -85.2},
				{x: 68.4, y: -96.0},
				{x: 51.6, y: -106.8},
				{x: 33.6, y: -112.8},
				{x: 12.0, y: -116.4},
				{x: -10.8, y: -116.4},
				{x: -32.4, y: -114.0},
				{x: -50.4, y: -105.6},
				{x: -64.8, y: -98.4},
				{x: -78.0, y: -88.8},
				{x: -90.0, y: -75.6},
				{x: -100.8, y: -61.2},
				{x: -109.2, y: -46.8},
				{x: -114.0, y: -28.8},
				{x: -118.8, y: -10.8},
				{x: -118.8, y: 6.0},
			], color: "b", line: 2, score: 5},

			{points: [
				{x: -177.6, y: 1.2},
				{x: -176.4, y: 16.8},
				{x: -175.2, y: 31.2},
				{x: -172.8, y: 45.6},
				{x: -127.2, y: 187.2},
				{x: -122.4, y: 199.2},
				{x: -115.2, y: 211.2},
				{x: -105.6, y: 224.4},
				{x: -96.0, y: 234.0},
				{x: -84.0, y: 244.8},
				{x: -69.6, y: 253.2},
				{x: -55.2, y: 260.4},
				{x: -39.6, y: 266.4},
				{x: -22.8, y: 270.0},
				{x: -3.6, y: 271.2},
				{x: 13.2, y: 270.0},
				{x: 31.2, y: 267.6},
				{x: 49.2, y: 262.8},
				{x: 66.0, y: 255.6},
				{x: 81.6, y: 246.0},
				{x: 99.6, y: 230.4},
				{x: 112.8, y: 213.6},
				{x: 123.6, y: 195.6},
				{x: 129.6, y: 180.0},
				{x: 174.0, y: 40.8},
				{x: 176.4, y: 16.8},
				{x: 177.6, y: -3.6},
				{x: 175.2, y: -21.6},
				{x: 171.6, y: -40.8},
				{x: 168.0, y: -57.6},
				{x: 159.6, y: -76.8},
				{x: 150.0, y: -92.4},
				{x: 140.4, y: -108.0},
				{x: 127.2, y: -121.2},
				{x: 114.0, y: -135.6},
				{x: 98.4, y: -147.6},
				{x: 79.2, y: -157.2},
				{x: 61.2, y: -165.6},
				{x: 38.4, y: -172.8},
				{x: 14.4, y: -176.4},
				{x: -9.6, y: -176.4},
				{x: -31.2, y: -174.0},
				{x: -52.8, y: -169.2},
				{x: -72.0, y: -162.0},
				{x: -92.4, y: -151.2},
				{x: -112.8, y: -138.0},
				{x: -127.2, y: -124.8},
				{x: -139.2, y: -110.4},
				{x: -150.0, y: -94.8},
				{x: -160.8, y: -73.2},
				{x: -170.4, y: -52.8},
				{x: -174.0, y: -36.0},
				{x: -177.6, y: -19.2},
			], color: "b", line: 2, score: 4},
			{points: [
				{x: -225, y: -280},
				{x: -225, y: 93},
				{x: -106, y: 280},
				{x: 106, y: 280},
				{x: 225, y: 93},
				{x: 225, y: -280},
			], color: "g", line: 4, score: 3},
		],
		text: [
			{x: 0, y: -91, size: 50, color: "wl", text: "5"},
			{x: 0, y: -150, size: 50, color: "wl", text: "4"},
			{x: 0, y: -210, size: 50, color: "wl", text: "3"},
		]		
	};
	

	targetfaces["Fig13AU"] = {
		name: "Figure 13 (AU)",
		shortname: "Fig. 13",
		dist: 300,
		dist_unit: "y",
		score: [5],
		board: {w: 1210, h: 1210, line: 5, score: 0},
		poly: [
			{points: [
				{x: -200, y: -100},
				{x: -200, y: 100},
				{x: 200, y: 100},
				{x: 200, y: -100},
			], color: "b", line: 2, score: 5},
			{points: [
				{x: -375, y: -265},
				{x: -375, y: 25},
				{x: -165, y: 265},
				{x: 165, y: 265},
				{x: 375, y: -12},
				{x: 375, y: -265},
			], color: "g", line: 2, score: 4},
		],
	};
	
	targetfaces["Fig14AU"] = {
		name: "Figure 14 (AU)",
		shortname: "Fig. 14",
		dist: 300,
		dist_unit: "y",
		score: [5],
		board: {w: 1210, h: 1210, line: 5, score: 0},
		rings: [	{diam: 125, color: "wl", line: 2, score: 5},
		],
		poly: [
			{points: [
				{x: -127.5, y: -122.4},
				{x: -73.2, y: -84.3},
				{x: -75.6, y: -39.9},
				{x: -94.1, y: -15.3},
				{x: -97.6, y: -4.0},
				{x: -91.2, y: 14.5},
				{x: -91.5, y: 47.9},
				{x: -80.1, y: 85.1},
				{x: -64.8, y: 109.2},
				{x: -32.3, y: 134.3},
				{x: -7.1, y: 141.4},
				{x: 9.5, y: 141.7},
				{x: 43.1, y: 132.2},
				{x: 70.1, y: 109.2},
				{x: 87.0, y: 80.9},
				{x: 96.5, y: 51.8},
				{x: 95.4, y: 21.7},
				{x: 104.4, y: -2.9},
				{x: 101.0, y: -21.4},
				{x: 87.5, y: -42.8},
				{x: 76.9, y: -92.5},
				{x: 114.7, y: -122.4},
				{x: 127.5, y: -142.5},
				{x: -127.5, y: -142.5},
			], color: "b", line: 5, score: 4},
			{points: [
				{x: -127.5, y: -142.5},
				{x: -127.5, y: 142.5},
				{x: 127.5, y: 142.5},
				{x: 127.5, y: -142.5},
			], color: "bl", line: 2, score: 3},
		],
	};

	// animal

	targetfaces["Buffalo"] = {
		name: "Buffalo",
		shortname: "Buffalo",
		dist: 300,
		dist_unit: "m",
		score: [5],
		board: {w: 2800, h: 2500, line: 5, score: 0},
		
		poly: [
			//small hole near tail
			{points: [
				{x: 1059.7, y: -312.9},
				{x: 1072.8, y: -340.6},
				{x: 1082.9, y: -359.5},
				{x: 1093.1, y: -391.5},
				{x: 1097.5, y: -419.2},
				{x: 1081.5, y: -410.5},
				{x: 1065.5, y: -397.4},
				{x: 1053.8, y: -381.4},
				{x: 1050.9, y: -362.4},
				{x: 1048.0, y: -340.6},
				{x: 1050.9, y: -326.0},
			],color: "w", line: 0, score: 0},

			//The rest of the buffalo
			{points: [
							
				{x: -1090.2, y: 425.0},
				{x: -1071.3, y: 406.1},
				{x: -1046.6, y: 391.5},
				{x: -1016.0, y: 375.5},
				{x: -986.9, y: 377.0},
				{x: -950.5, y: 381.4},
				{x: -928.7, y: 379.9},
				{x: -903.9, y: 365.3},
				{x: -871.9, y: 353.7},
				{x: -841.3, y: 371.2},
				{x: -804.9, y: 387.2},
				{x: -765.6, y: 394.5},
				{x: -729.2, y: 394.5},
				{x: -685.6, y: 391.5},
				{x: -669.6, y: 410.5},
				{x: -662.3, y: 441.0},
				{x: -647.7, y: 471.6},
				{x: -609.9, y: 509.4},
				{x: -579.3, y: 525.5},
				{x: -537.1, y: 553.1},
				{x: -496.3, y: 580.8},
				{x: -448.3, y: 607.0},
				{x: -398.8, y: 620.1},
				{x: -356.6, y: 620.1},
				{x: -307.1, y: 633.2},
				{x: -254.7, y: 647.7},
				{x: -206.7, y: 655.0},
				{x: -155.7, y: 660.8},
				{x: -103.3, y: 662.3},
				{x: -59.7, y: 655.0},
				{x: -7.3, y: 639.0},
				{x: 45.1, y: 628.8},
				{x: 94.6, y: 605.5},
				{x: 126.6, y: 585.1},
				{x: 189.2, y: 567.7},
				{x: 228.5, y: 550.2},
				{x: 273.6, y: 528.4},
				{x: 315.9, y: 502.2},
				{x: 356.6, y: 484.7},
				{x: 411.9, y: 468.7},
				{x: 446.9, y: 454.1},
				{x: 494.9, y: 439.6},
				{x: 537.1, y: 410.5},
				{x: 591.0, y: 378.4},
				{x: 617.2, y: 368.3},
				{x: 662.3, y: 365.3},
				{x: 756.9, y: 371.2},
				{x: 787.5, y: 369.7},
				{x: 838.4, y: 349.3},
				{x: 918.5, y: 324.6},
				{x: 975.2, y: 307.1},
				{x: 1027.6, y: 288.2},
				{x: 1050.9, y: 273.6},
				{x: 1071.3, y: 240.2},
				{x: 1097.5, y: 189.2},
				{x: 1128.1, y: 136.8},
				{x: 1142.6, y: 88.8},
				{x: 1158.6, y: 26.2},
				{x: 1161.5, y: -20.4},
				{x: 1154.3, y: -84.4},
				{x: 1145.5, y: -131.0},
				{x: 1145.5, y: -180.5},
				{x: 1149.9, y: -241.6},
				{x: 1155.7, y: -288.2},
				{x: 1165.9, y: -329.0},
				{x: 1184.8, y: -371.2},
				{x: 1206.7, y: -417.7},
				{x: 1228.5, y: -451.2},
				{x: 1247.4, y: -477.4},
				{x: 1272.2, y: -524.0},
				{x: 1276.5, y: -564.8},
				{x: 1275.1, y: -595.3},
				{x: 1250.3, y: -576.4},
				{x: 1250.3, y: -621.5},
				{x: 1230.0, y: -660.8},
				{x: 1215.4, y: -697.2},
				{x: 1202.3, y: -736.5},
				{x: 1193.6, y: -751.1},
				{x: 1167.4, y: -719.0},
				{x: 1179.0, y: -895.2},
				{x: 1173.2, y: -919.9},
				{x: 1163.0, y: -934.5},
				{x: 1135.3, y: -944.7},
				{x: 1117.9, y: -981.1},
				{x: 1115.0, y: -1023.3},
				{x: 1099.0, y: -1043.6},
				{x: 1072.8, y: -1050.9},
				{x: 931.6, y: -1050.9},
				{x: 914.1, y: -1032.0},
				{x: 914.1, y: -1014.5},
				{x: 935.9, y: -981.1},
				{x: 953.4, y: -963.6},
				{x: 973.8, y: -934.5},
				{x: 995.6, y: -908.3},
				{x: 1002.9, y: -887.9},
				{x: 1005.8, y: -858.8},
				{x: 1005.8, y: -812.2},
				{x: 1005.8, y: -772.9},
				{x: 1002.9, y: -740.9},
				{x: 1001.4, y: -711.8},
				{x: 995.6, y: -688.5},
				{x: 988.3, y: -659.4},
				{x: 976.7, y: -627.3},
				{x: 972.3, y: -601.1},
				{x: 969.4, y: -589.5},
				{x: 940.3, y: -576.4},
				{x: 930.1, y: -561.8},
				{x: 915.6, y: -551.7},
				{x: 899.5, y: -553.1},
				{x: 890.8, y: -573.5},
				{x: 887.9, y: -609.9},
				{x: 885.0, y: -637.5},
				{x: 874.8, y: -665.2},
				{x: 861.7, y: -691.4},
				{x: 844.2, y: -720.5},
				{x: 825.3, y: -746.7},
				{x: 800.6, y: -786.0},
				{x: 778.7, y: -826.8},
				{x: 765.6, y: -873.3},
				{x: 759.8, y: -899.5},
				{x: 742.3, y: -914.1},
				{x: 694.3, y: -925.7},
				{x: 669.6, y: -940.3},
				{x: 662.3, y: -963.6},
				{x: 660.8, y: -986.9},
				{x: 643.4, y: -1024.7},
				{x: 617.2, y: -1029.1},
				{x: 596.8, y: -1029.1},
				{x: 567.7, y: -1029.1},
				{x: 531.3, y: -1029.1},
				{x: 503.6, y: -1026.2},
				{x: 473.1, y: -1020.4},
				{x: 464.3, y: -997.1},
				{x: 473.1, y: -972.3},
				{x: 487.6, y: -944.7},
				{x: 516.7, y: -917.0},
				{x: 540.0, y: -899.5},
				{x: 570.6, y: -869.0},
				{x: 605.5, y: -838.4},
				{x: 631.7, y: -815.1},
				{x: 660.8, y: -784.5},
				{x: 685.6, y: -751.1},
				{x: 710.3, y: -723.4},
				{x: 722.0, y: -694.3},
				{x: 729.2, y: -649.2},
				{x: 716.1, y: -605.5},
				{x: 688.5, y: -564.8},
				{x: 666.6, y: -534.2},
				{x: 631.7, y: -545.8},
				{x: 593.9, y: -566.2},
				{x: 564.8, y: -577.9},
				{x: 532.7, y: -579.3},
				{x: 499.3, y: -580.8},
				{x: 496.3, y: -567.7},
				{x: 512.4, y: -541.5},
				{x: 516.7, y: -519.6},
				{x: 481.8, y: -528.4},
				{x: 465.8, y: -532.7},
				{x: 419.2, y: -563.3},
				{x: 398.8, y: -576.4},
				{x: 337.7, y: -605.5},
				{x: 315.9, y: -614.2},
				{x: 289.7, y: -620.1},
				{x: 262.0, y: -624.4},
				{x: 232.9, y: -631.7},
				{x: 211.1, y: -630.3},
				{x: 202.3, y: -650.6},
				{x: 202.3, y: -684.1},
				{x: 192.1, y: -716.1},
				{x: 176.1, y: -732.1},
				{x: 164.5, y: -758.3},
				{x: 141.2, y: -781.6},
				{x: 116.4, y: -807.8},
				{x: 106.3, y: -835.5},
				{x: 99.0, y: -869.0},
				{x: 88.8, y: -915.6},
				{x: 75.7, y: -924.3},
				{x: 52.4, y: -928.7},
				{x: 37.8, y: -947.6},
				{x: 32.0, y: -959.2},
				{x: 34.9, y: -982.5},
				{x: 34.9, y: -1005.8},
				{x: 18.9, y: -1020.4},
				{x: -11.6, y: -1021.8},
				{x: -55.3, y: -1023.3},
				{x: -103.3, y: -1014.5},
				{x: -103.3, y: -991.2},
				{x: -120.8, y: -986.9},
				{x: -142.6, y: -994.2},
				{x: -142.6, y: -1023.3},
				{x: -152.8, y: -1039.3},
				{x: -173.2, y: -1039.3},
				{x: -224.2, y: -1039.3},
				{x: -318.8, y: -1039.3},
				{x: -330.4, y: -1030.5},
				{x: -330.4, y: -1013.1},
				{x: -318.8, y: -995.6},
				{x: -286.7, y: -969.4},
				{x: -256.2, y: -928.7},
				{x: -216.9, y: -879.2},
				{x: -206.7, y: -844.2},
				{x: -199.4, y: -790.4},
				{x: -216.9, y: -751.1},
				{x: -251.8, y: -685.6},
				{x: -264.9, y: -615.7},
				{x: -269.3, y: -580.8},
				{x: -275.1, y: -564.8},
				{x: -312.9, y: -563.3},
				{x: -350.8, y: -561.8},
				{x: -374.1, y: -554.6},
				{x: -387.2, y: -544.4},
				{x: -416.3, y: -532.7},
				{x: -441.0, y: -502.2},
				{x: -462.9, y: -529.8},
				{x: -471.6, y: -554.6},
				{x: -492.0, y: -582.2},
				{x: -500.7, y: -611.3},
				{x: -513.8, y: -641.9},
				{x: -538.6, y: -663.7},
				{x: -550.2, y: -675.4},
				{x: -596.8, y: -676.8},
				{x: -621.5, y: -701.6},
				{x: -640.4, y: -724.9},
				{x: -662.3, y: -732.1},
				{x: -692.8, y: -723.4},
				{x: -697.2, y: -700.1},
				{x: -714.7, y: -641.9},
				{x: -729.2, y: -612.8},
				{x: -739.4, y: -585.1},
				{x: -748.2, y: -557.5},
				{x: -754.0, y: -528.4},
				{x: -771.4, y: -512.4},
				{x: -799.1, y: -509.4},
				{x: -845.7, y: -510.9},
				{x: -886.4, y: -494.9},
				{x: -911.2, y: -458.5},
				{x: -914.1, y: -441.0},
				{x: -921.4, y: -416.3},
				{x: -915.6, y: -395.9},
				{x: -930.1, y: -369.7},
				{x: -959.2, y: -345.0},
				{x: -985.4, y: -315.9},
				{x: -1007.3, y: -267.8},
				{x: -1020.4, y: -228.5},
				{x: -1029.1, y: -192.1},
				{x: -1034.9, y: -160.1},
				{x: -1036.4, y: -122.3},
				{x: -1037.8, y: -99.0},
				{x: -1061.1, y: -68.4},
				{x: -1071.3, y: -36.4},
				{x: -1077.1, y: -17.5},
				{x: -1094.6, y: 30.6},
				{x: -1110.6, y: 69.9},
				{x: -1112.1, y: 110.6},
				{x: -1103.3, y: 160.1},
				{x: -1090.2, y: 192.1},
				{x: -1072.8, y: 214.0},
				{x: -1049.5, y: 247.4},
				{x: -1024.7, y: 264.9},
				{x: -1010.2, y: 283.8},
				{x: -1002.9, y: 307.1},
				{x: -1029.1, y: 327.5},
				{x: -1053.8, y: 343.5},
				{x: -1072.8, y: 362.4},
				{x: -1085.9, y: 385.7},
				{x: -1090.2, y: 403.2},
			],color: "b", line: 0, score: 5},
		],
	};

	// animals

	targetfaces["Chicken"] = {
		name: "Chicken",
		shortname: "Chicken",
		dist: 200,
		dist_unit: "m",
		score: [1],
		board: {w: 600, h: 600, line: 3, score: 0},

		poly: [
			{points: [
				{x: -80.9, y: 49.2},
				{x: -78.6, y: 49.3},
				{x: -76.5, y: 48.5},
				{x: -74.3, y: 47.3},
				{x: -71.9, y: 45.6},
				{x: -69.9, y: 44.0},
				{x: -67.5, y: 42.6},
				{x: -64.8, y: 40.8},
				{x: -62.2, y: 39.4},
				{x: -60.1, y: 37.0},
				{x: -56.4, y: 34.5},
				{x: -54.8, y: 33.4},
				{x: -52.3, y: 32.4},
				{x: -49.4, y: 31.5},
				{x: -47.3, y: 31.1},
				{x: -44.5, y: 30.7},
				{x: -41.4, y: 31.1},
				{x: -35.7, y: 31.7},
				{x: -30.5, y: 32.8},
				{x: -27.9, y: 33.8},
				{x: -24.7, y: 34.4},
				{x: -20.7, y: 35.0},
				{x: -17.2, y: 35.0},
				{x: -13.7, y: 35.2},
				{x: -10.0, y: 34.9},
				{x: -7.3, y: 34.6},
				{x: -4.0, y: 34.0},
				{x: -1.3, y: 33.4},
				{x: 1.2, y: 33.0},
				{x: 3.4, y: 32.2},
				{x: 6.1, y: 31.5},
				{x: 9.3, y: 30.8},
				{x: 12.2, y: 30.7},
				{x: 14.7, y: 31.1},
				{x: 17.3, y: 31.6},
				{x: 19.8, y: 32.4},
				{x: 22.5, y: 33.0},
				{x: 24.6, y: 34.4},
				{x: 26.7, y: 35.0},
				{x: 28.8, y: 36.2},
				{x: 30.7, y: 37.5},
				{x: 32.4, y: 39.0},
				{x: 34.4, y: 40.8},
				{x: 36.2, y: 43.1},
				{x: 37.7, y: 45.1},
				{x: 39.5, y: 47.8},
				{x: 41.0, y: 51.3},
				{x: 42.3, y: 54.5},
				{x: 43.5, y: 57.2},
				{x: 44.5, y: 59.5},
				{x: 45.7, y: 61.2},
				{x: 47.3, y: 63.7},
				{x: 48.9, y: 65.9},
				{x: 51.0, y: 67.9},
				{x: 52.6, y: 69.6},
				{x: 54.6, y: 71.5},
				{x: 57.0, y: 73.1},
				{x: 59.3, y: 73.9},
				{x: 61.9, y: 74.4},
				{x: 64.2, y: 74.5},
				{x: 67.4, y: 74.0},
				{x: 70.0, y: 72.7},
				{x: 72.0, y: 71.5},
				{x: 74.0, y: 70.2},
				{x: 75.3, y: 68.3},
				{x: 76.8, y: 65.9},
				{x: 78.1, y: 63.2},
				{x: 79.0, y: 60.4},
				{x: 80.2, y: 57.2},
				{x: 81.5, y: 54.3},
				{x: 82.6, y: 51.8},
				{x: 83.9, y: 49.6},
				{x: 85.5, y: 47.6},
				{x: 86.7, y: 46.0},
				{x: 87.5, y: 43.7},
				{x: 86.7, y: 41.5},
				{x: 85.5, y: 40.0},
				{x: 83.9, y: 39.4},
				{x: 81.4, y: 38.9},
				{x: 79.3, y: 38.6},
				{x: 77.3, y: 38.9},
				{x: 75.6, y: 39.3},
				{x: 73.2, y: 39.4},
				{x: 71.9, y: 39.3},
				{x: 70.0, y: 38.6},
				{x: 67.3, y: 37.4},
				{x: 65.2, y: 35.8},
				{x: 63.8, y: 34.2},
				{x: 62.6, y: 32.2},
				{x: 61.3, y: 30.3},
				{x: 60.8, y: 28.0},
				{x: 60.5, y: 25.6},
				{x: 60.5, y: 23.1},
				{x: 60.4, y: 20.4},
				{x: 60.5, y: 17.8},
				{x: 60.3, y: 15.2},
				{x: 59.7, y: 11.8},
				{x: 59.3, y: 8.9},
				{x: 58.7, y: 6.6},
				{x: 58.2, y: 4.4},
				{x: 57.2, y: 1.9},
				{x: 56.3, y: -0.5},
				{x: 55.4, y: -2.9},
				{x: 54.5, y: -4.6},
				{x: 53.1, y: -6.7},
				{x: 51.9, y: -8.7},
				{x: 50.9, y: -11.0},
				{x: 49.6, y: -12.7},
				{x: 48.1, y: -14.8},
				{x: 46.3, y: -16.5},
				{x: 45.1, y: -18.1},
				{x: 43.3, y: -19.7},
				{x: 41.9, y: -21.3},
				{x: 40.6, y: -22.9},
				{x: 38.3, y: -25.0},
				{x: 36.3, y: -26.6},
				{x: 34.0, y: -28.4},
				{x: 31.9, y: -29.6},
				{x: 29.6, y: -31.3},
				{x: 27.1, y: -32.4},
				{x: 25.2, y: -33.2},
				{x: 22.5, y: -34.4},
				{x: 18.8, y: -35.2},
				{x: 15.7, y: -35.8},
				{x: 12.3, y: -36.1},
				{x: 9.0, y: -36.3},
				{x: 7.1, y: -36.7},
				{x: 5.2, y: -37.9},
				{x: 4.2, y: -39.4},
				{x: 4.2, y: -41.9},
				{x: 4.1, y: -75.5},
				{x: -28.7, y: -75.3},
				{x: -28.5, y: -45.2},
				{x: -28.8, y: -43.5},
				{x: -29.7, y: -41.5},
				{x: -31.1, y: -39.4},
				{x: -32.2, y: -37.5},
				{x: -33.7, y: -36.1},
				{x: -35.3, y: -34.2},
				{x: -37.0, y: -32.4},
				{x: -39.1, y: -30.3},
				{x: -41.4, y: -27.9},
				{x: -43.7, y: -26.4},
				{x: -45.5, y: -24.7},
				{x: -47.7, y: -22.9},
				{x: -50.1, y: -21.1},
				{x: -52.9, y: -19.6},
				{x: -54.8, y: -17.4},
				{x: -57.6, y: -15.1},
				{x: -59.2, y: -13.1},
				{x: -60.8, y: -11.4},
				{x: -62.4, y: -9.1},
				{x: -63.6, y: -7.0},
				{x: -64.8, y: -5.3},
				{x: -66.3, y: -3.3},
				{x: -67.7, y: -0.0},
				{x: -69.0, y: 2.1},
				{x: -69.8, y: 4.5},
				{x: -70.7, y: 7.1},
				{x: -71.5, y: 9.6},
				{x: -72.4, y: 12.8},
				{x: -73.5, y: 14.5},
				{x: -74.4, y: 16.8},
				{x: -75.6, y: 18.6},
				{x: -76.9, y: 20.9},
				{x: -77.4, y: 22.5},
				{x: -78.4, y: 24.6},
				{x: -79.3, y: 27.5},
				{x: -80.1, y: 30.0},
				{x: -81.1, y: 32.6},
				{x: -81.5, y: 35.0},
				{x: -81.8, y: 37.0},
				{x: -82.5, y: 39.4},
				{x: -82.6, y: 43.0},
				{x: -82.6, y: 45.7},
				{x: -82.6, y: 47.3},
				{x: -82.2, y: 48.5},
				], color: "b", line: 0, score: 1},
		],

	};



	targetfaces["Ram"] = {
		name: "Ram",
		shortname: "Ram",
		dist: 200,
		dist_unit: "m",
		score: [1],
		board: {w: 600, h: 600, line: 3, score: 0},

		poly: [

			{points: [
				{x: 101.2, y: 108.8},
				{x: 96.4, y: 105.1},
				{x: 92.7, y: 100.6},
				{x: 89.0, y: 94.7},
				{x: 87.1, y: 88.8},
				{x: 86.8, y: 82.6},
				{x: 88.5, y: 79.2},
				{x: 93.0, y: 77.5},
				{x: 97.5, y: 78.3},
				{x: 102.9, y: 81.2},
				{x: 109.3, y: 85.1},
				{x: 114.7, y: 89.3},
				{x: 117.8, y: 92.1},
				{x: 121.7, y: 94.4},
				{x: 126.0, y: 95.5},
				{x: 129.1, y: 98.1},
				{x: 129.3, y: 102.3},
				{x: 126.8, y: 107.6},
				{x: 123.7, y: 111.3},
				{x: 119.8, y: 112.4},
				{x: 113.8, y: 112.7},
				{x: 109.6, y: 112.4},
				{x: 105.7, y: 111.0},
			], color: "w", line: 0, score: "0"},
			
			{points: [
				{x: -153.5, y: -172.9},
				{x: -179.4, y: -173.2},
				{x: -179.1, y: -161.9},
				{x: -179.6, y: -150.4},
				{x: -180.5, y: -139.4},
				{x: -182.5, y: -126.7},
				{x: -185.0, y: -116.6},
				{x: -185.3, y: -113.5},
				{x: -184.4, y: -104.7},
				{x: -184.2, y: -90.1},
				{x: -185.0, y: -81.9},
				{x: -188.1, y: -67.3},
				{x: -194.0, y: -52.1},
				{x: -199.9, y: -39.1},
				{x: -202.7, y: -29.3},
				{x: -204.4, y: -16.3},
				{x: -204.4, y: -5.3},
				{x: -201.9, y: 6.8},
				{x: -198.8, y: 15.8},
				{x: -189.5, y: 29.6},
				{x: -179.4, y: 40.5},
				{x: -169.5, y: 49.6},
				{x: -157.7, y: 57.7},
				{x: -143.6, y: 65.0},
				{x: -125.6, y: 71.0},
				{x: -109.8, y: 73.8},
				{x: -91.5, y: 74.3},
				{x: -72.1, y: 73.2},
				{x: -54.1, y: 70.1},
				{x: -40.5, y: 66.5},
				{x: -24.5, y: 63.9},
				{x: -6.8, y: 62.8},
				{x: 10.1, y: 63.1},
				{x: 25.3, y: 65.0},
				{x: 38.3, y: 67.3},
				{x: 54.9, y: 72.1},
				{x: 53.8, y: 78.6},
				{x: 49.8, y: 87.9},
				{x: 47.6, y: 96.6},
				{x: 46.7, y: 105.9},
				{x: 47.3, y: 114.9},
				{x: 49.3, y: 124.2},
				{x: 53.5, y: 134.0},
				{x: 58.3, y: 141.1},
				{x: 63.6, y: 146.4},
				{x: 71.8, y: 152.3},
				{x: 83.6, y: 161.3},
				{x: 96.9, y: 167.8},
				{x: 108.4, y: 171.2},
				{x: 121.4, y: 172.3},
				{x: 135.2, y: 171.8},
				{x: 149.0, y: 167.8},
				{x: 158.2, y: 162.8},
				{x: 168.1, y: 154.0},
				{x: 175.7, y: 142.8},
				{x: 181.3, y: 129.8},
				{x: 184.2, y: 117.7},
				{x: 184.7, y: 105.6},
				{x: 183.9, y: 98.0},
				{x: 181.9, y: 89.5},
				{x: 181.1, y: 82.5},
				{x: 182.2, y: 76.6},
				{x: 185.8, y: 69.3},
				{x: 190.3, y: 58.3},
				{x: 192.9, y: 46.7},
				{x: 193.2, y: 39.7},
				{x: 196.5, y: 27.6},
				{x: 201.9, y: 15.8},
				{x: 204.4, y: -0.3},
				{x: 205.0, y: -18.9},
				{x: 201.0, y: -26.2},
				{x: 196.3, y: -30.4},
				{x: 188.7, y: -32.7},
				{x: 181.6, y: -32.1},
				{x: 173.7, y: -26.2},
				{x: 165.0, y: -18.9},
				{x: 158.2, y: -9.9},
				{x: 149.8, y: -3.7},
				{x: 141.1, y: -0.8},
				{x: 134.6, y: -0.6},
				{x: 126.1, y: -2.5},
				{x: 120.2, y: -6.8},
				{x: 115.7, y: -12.7},
				{x: 111.2, y: -19.1},
				{x: 107.6, y: -27.0},
				{x: 104.2, y: -36.0},
				{x: 99.7, y: -45.3},
				{x: 91.8, y: -57.2},
				{x: 85.6, y: -65.3},
				{x: 78.3, y: -72.9},
				{x: 70.7, y: -81.4},
				{x: 65.9, y: -88.4},
				{x: 64.2, y: -95.2},
				{x: 63.1, y: -104.7},
				{x: 63.4, y: -114.0},
				{x: 64.2, y: -117.4},
				{x: 63.9, y: -172.9},
				{x: 31.0, y: -172.9},
				{x: 29.3, y: -106.4},
				{x: 29.3, y: -99.4},
				{x: 27.6, y: -91.8},
				{x: 23.4, y: -88.4},
				{x: 9.9, y: -90.1},
				{x: -10.7, y: -91.5},
				{x: -38.9, y: -92.6},
				{x: -55.5, y: -92.9},
				{x: -57.7, y: -94.0},
				{x: -56.0, y: -100.2},
				{x: -57.2, y: -104.2},
				{x: -63.4, y: -104.5},
				{x: -68.1, y: -100.2},
				{x: -73.2, y: -95.7},
				{x: -81.9, y: -90.7},
				{x: -95.5, y: -79.4},
				{x: -101.4, y: -77.4},
				{x: -108.4, y: -78.3},
				{x: -115.7, y: -83.1},
				{x: -125.3, y: -93.5},
				{x: -138.8, y: -109.5},
				{x: -150.6, y: -127.8},
				{x: -152.3, y: -133.7},
				{x: -154.6, y: -143.9},
				{x: -153.5, y: -153.7},
				{x: -152.9, y: -159.9},
			], color: "b", line: 0, score: "1"},

		],

	};

	targetfaces["Turkey"] = {
		name: "Turkey",
		shortname: "Turkey",
		dist: 200,
		dist_unit: "m",
		score: [1],
		board: {w: 600, h: 600, line: 3, score: 0},

		poly: [
			{points: [


				{x: 6.9, y: -132.9},
				{x: -39.2, y: -132.9},
				{x: -40.0, y: -100.2},
				{x: -40.0, y: -59.3},
				{x: -42.8, y: -53.4},
				{x: -47.3, y: -50.6},
				{x: -51.8, y: -48.7},
				{x: -63.4, y: -45.9},
				{x: -77.8, y: -39.7},
				{x: -86.8, y: -35.0},
				{x: -93.9, y: -31.0},
				{x: -105.0, y: -27.2},
				{x: -114.9, y: -26.2},
				{x: -123.2, y: -26.5},
				{x: -128.6, y: -25.3},
				{x: -132.1, y: -21.5},
				{x: -132.4, y: -16.5},
				{x: -130.0, y: -12.3},
				{x: -125.1, y: -5.7},
				{x: -120.8, y: 3.3},
				{x: -112.1, y: 14.7},
				{x: -101.2, y: 26.7},
				{x: -88.2, y: 39.0},
				{x: -66.2, y: 55.8},
				{x: -45.6, y: 67.6},
				{x: -25.1, y: 76.8},
				{x: -5.2, y: 83.9},
				{x: 6.1, y: 86.5},
				{x: 14.9, y: 87.7},
				{x: 23.4, y: 88.2},
				{x: 33.3, y: 87.5},
				{x: 42.1, y: 87.7},
				{x: 46.1, y: 88.7},
				{x: 49.4, y: 92.0},
				{x: 51.3, y: 107.6},
				{x: 51.3, y: 116.8},
				{x: 49.2, y: 126.5},
				{x: 48.5, y: 135.0},
				{x: 48.2, y: 143.5},
				{x: 49.4, y: 148.9},
				{x: 52.0, y: 153.7},
				{x: 56.5, y: 158.2},
				{x: 61.9, y: 160.5},
				{x: 68.6, y: 161.7},
				{x: 74.7, y: 161.5},
				{x: 79.0, y: 161.5},
				{x: 82.7, y: 162.9},
				{x: 85.1, y: 164.5},
				{x: 87.9, y: 163.1},
				{x: 88.7, y: 159.6},
				{x: 91.7, y: 156.0},
				{x: 99.1, y: 151.5},
				{x: 108.0, y: 142.3},
				{x: 107.3, y: 139.7},
				{x: 100.7, y: 139.2},
				{x: 94.8, y: 137.4},
				{x: 91.7, y: 134.0},
				{x: 91.3, y: 130.0},
				{x: 93.6, y: 124.6},
				{x: 95.5, y: 119.9},
				{x: 97.4, y: 108.0},
				{x: 97.9, y: 92.7},
				{x: 97.6, y: 80.9},
				{x: 95.7, y: 72.8},
				{x: 92.4, y: 67.1},
				{x: 88.9, y: 62.6},
				{x: 86.3, y: 60.0},
				{x: 84.6, y: 55.8},
				{x: 83.9, y: 51.3},
				{x: 83.2, y: 37.4},
				{x: 82.0, y: 24.8},
				{x: 80.4, y: 14.4},
				{x: 77.3, y: 4.7},
				{x: 71.9, y: -6.4},
				{x: 65.5, y: -17.7},
				{x: 59.3, y: -25.5},
				{x: 52.7, y: -31.7},
				{x: 46.6, y: -36.4},
				{x: 39.0, y: -39.5},
				{x: 30.0, y: -42.3},
				{x: 23.6, y: -44.2},
				{x: 14.9, y: -48.7},
				{x: 11.3, y: -52.2},
				{x: 8.3, y: -57.7},
				{x: 6.9, y: -62.2},


			], color: "b", line: 0, score: 1},
		],

	};

	targetfaces["Pig"] = {
		name: "Pig",
		shortname: "Pig",
		dist: 200,
		dist_unit: "m",
		score: [1],
		board: {w: 600, h: 600, line: 3, score: 0},

		poly: [
			{points: [

				{x: -91.1, y: -93.8},
				{x: -92.4, y: -69.1},
				{x: -95.8, y: -42.5},
				{x: -96.7, y: -39.5},
				{x: -98.7, y: -36.5},
				{x: -101.8, y: -33.8},
				{x: -105.7, y: -31.5},
				{x: -111.2, y: -26.9},
				{x: -119.1, y: -18.9},
				{x: -125.5, y: -10.3},
				{x: -131.2, y: -0.2},
				{x: -132.7, y: 1.4},
				{x: -137.2, y: 1.8},
				{x: -140.3, y: 2.8},
				{x: -141.4, y: 4.8},
				{x: -141.5, y: 15.2},
				{x: -140.6, y: 28.3},
				{x: -138.4, y: 41.1},
				{x: -136.1, y: 47.1},
				{x: -133.0, y: 52.3},
				{x: -129.1, y: 57.2},
				{x: -124.1, y: 62.0},
				{x: -119.2, y: 65.2},
				{x: -108.3, y: 69.7},
				{x: -91.5, y: 74.8},
				{x: -74.6, y: 78.0},
				{x: -68.4, y: 77.8},
				{x: -61.7, y: 78.8},
				{x: -54.9, y: 80.0},
				{x: -43.7, y: 81.4},
				{x: -36.0, y: 82.0},
				{x: -26.0, y: 83.8},
				{x: -15.2, y: 86.8},
				{x: -5.7, y: 89.8},
				{x: 5.4, y: 92.1},
				{x: 13.7, y: 93.2},
				{x: 24.8, y: 93.7},
				{x: 34.6, y: 93.2},
				{x: 41.7, y: 92.4},
				{x: 47.5, y: 89.8},
				{x: 56.6, y: 84.9},
				{x: 68.4, y: 76.9},
				{x: 76.1, y: 70.9},
				{x: 81.5, y: 66.0},
				{x: 84.0, y: 64.8},
				{x: 86.8, y: 64.4},
				{x: 89.2, y: 65.2},
				{x: 93.1, y: 67.5},
				{x: 97.1, y: 69.5},
				{x: 102.3, y: 71.5},
				{x: 107.7, y: 72.9},
				{x: 110.9, y: 72.8},
				{x: 113.2, y: 71.1},
				{x: 114.9, y: 68.9},
				{x: 115.2, y: 66.1},
				{x: 114.7, y: 63.1},
				{x: 113.4, y: 58.3},
				{x: 111.1, y: 50.9},
				{x: 108.4, y: 44.0},
				{x: 106.3, y: 38.6},
				{x: 105.2, y: 34.1},
				{x: 105.2, y: 30.6},
				{x: 106.1, y: 26.5},
				{x: 107.7, y: 23.2},
				{x: 110.7, y: 19.7},
				{x: 140.7, y: -21.1},
				{x: 141.5, y: -23.2},
				{x: 141.4, y: -26.1},
				{x: 140.1, y: -29.1},
				{x: 137.8, y: -30.9},
				{x: 117.8, y: -45.7},
				{x: 115.5, y: -46.1},
				{x: 113.4, y: -45.1},
				{x: 112.1, y: -42.5},
				{x: 109.1, y: -39.4},
				{x: 104.6, y: -35.7},
				{x: 98.7, y: -32.6},
				{x: 92.3, y: -30.3},
				{x: 89.1, y: -29.7},
				{x: 71.5, y: -30.0},
				{x: 61.8, y: -30.9},
				{x: 54.1, y: -32.1},
				{x: 48.3, y: -33.1},
				{x: 43.5, y: -33.4},
				{x: 39.4, y: -33.7},
				{x: 36.1, y: -35.5},
				{x: 33.4, y: -38.8},
				{x: 31.8, y: -42.5},
				{x: 30.1, y: -46.9},
				{x: 29.5, y: -51.1},
				{x: 29.4, y: -56.0},
				{x: 29.2, y: -58.6},
				{x: 26.5, y: -74.0},
				{x: 21.8, y: -93.7},
				{x: -4.6, y: -93.8},
				{x: -3.8, y: -46.6},
				{x: -4.9, y: -43.4},
				{x: -7.5, y: -40.3},
				{x: -12.3, y: -38.5},
				{x: -35.8, y: -37.5},
				{x: -52.0, y: -36.5},
				{x: -56.9, y: -36.8},
				{x: -60.0, y: -38.5},
				{x: -62.8, y: -41.2},
				{x: -63.8, y: -44.9},
				{x: -63.8, y: -49.2},
				{x: -63.4, y: -51.8},
				{x: -62.8, y: -60.1},
				{x: -62.1, y: -71.5},
				{x: -62.3, y: -80.0},
				{x: -62.8, y: -86.4},
				{x: -63.7, y: -93.8},


			], color: "b", line: 0, score: 1},
		],

	};
	
	// IPSC

	targetfaces["IPSCRifleMajor"] = {
		name: "IPSC Rifle (Major)",
		shortname: "IPSC Rifle (Major)",
		dist: 100,
		dist_unit: "y",
		score: [5],
		board: {w: 750, h: 1200, line: 0, score: 0},

		poly: [
			{points: [
				{x: -75, y: 0},
				{x: -25, y: 165},
				{x: 25, y: 165},
				{x: 75, y: 0},
				{x: 75, y: -85},
				{x: 25, y: -160},
				{x: -25, y: -160},
				{x: -75, y: -85}
			], color: "g", line: 2, score: 5},
			{points: [
				{x: -150, y: 0},
				{x: -75, y: 190},
				{x: 75, y: 190},
				{x: 150, y: 0},
				{x: 150, y: -145},
				{x: 50, y: -260},
				{x: -50, y: -260},
				{x: -150, y: -145}
			], color: "g", line: 2, score: 4},
			{points: [
				{x: -225, y: 0},
				{x: -75, y: 190},
				{x: 75, y: 190},
				{x: 225, y: 0},
				{x: 225, y: -190},
				{x: 75, y: -380},
				{x: -75, y: -380},
				{x: -225, y: -190}
			], color: "g", line: 2, score: 2},
		],

		text: [
			{x: 0, y: 0, size: 30, color: "bl", text: "5"},
			{x: -112.5, y: 0, size: 30, color: "bl", text: "4"},
			{x: 112.5, y: 0, size: 30, color: "bl", text: "4"},
			{x: -187.5, y: 0, size: 30, color: "bl", text: "2"},
			{x: 187.5, y: 0, size: 30, color: "bl", text: "2"},
		]

	};

	targetfaces["IPSCRifleMajor3"] = {
		name: "IPSC Rifle (Major) x3",
		shortname: "IPSC Rifle (Major) x3",
		dist: 100,
		dist_unit: "y",
		score: [5],
		board: {w: 2500, h: 1200, line: 0, score: 0},

		poly: [

			{points: [ // center
				{x: -75, y: 0},
				{x: -25, y: 165},
				{x: 25, y: 165},
				{x: 75, y: 0},
				{x: 75, y: -85},
				{x: 25, y: -160},
				{x: -25, y: -160},
				{x: -75, y: -85}
			], color: "g", line: 2, score: 5},
			{points: [
				{x: -150, y: 0},
				{x: -75, y: 190},
				{x: 75, y: 190},
				{x: 150, y: 0},
				{x: 150, y: -145},
				{x: 50, y: -260},
				{x: -50, y: -260},
				{x: -150, y: -145}
			], color: "g", line: 2, score: 4},
			{points: [
				{x: -225, y: 0},
				{x: -75, y: 190},
				{x: 75, y: 190},
				{x: 225, y: 0},
				{x: 225, y: -190},
				{x: 75, y: -380},
				{x: -75, y: -380},
				{x: -225, y: -190}
			], color: "g", line: 2, score: 2},
			
			{points: [ // left
				{x: -75-700, y: 0},
				{x: -25-700, y: 165},
				{x: 25-700, y: 165},
				{x: 75-700, y: 0},
				{x: 75-700, y: -85},
				{x: 25-700, y: -160},
				{x: -25-700, y: -160},
				{x: -75-700, y: -85}
			], color: "g", line: 2, score: 5},
			{points: [
				{x: -150-700, y: 0},
				{x: -75-700, y: 190},
				{x: 75-700, y: 190},
				{x: 150-700, y: 0},
				{x: 150-700, y: -145},
				{x: 50-700, y: -260},
				{x: -50-700, y: -260},
				{x: -150-700, y: -145}
			], color: "g", line: 2, score: 4},
			{points: [
				{x: -225-700, y: 0},
				{x: -75-700, y: 190},
				{x: 75-700, y: 190},
				{x: 225-700, y: 0},
				{x: 225-700, y: -190},
				{x: 75-700, y: -380},
				{x: -75-700, y: -380},
				{x: -225-700, y: -190}
			], color: "g", line: 2, score: 2},
			
			{points: [ // right
				{x: -75+700, y: 0},
				{x: -25+700, y: 165},
				{x: 25+700, y: 165},
				{x: 75+700, y: 0},
				{x: 75+700, y: -85},
				{x: 25+700, y: -160},
				{x: -25+700, y: -160},
				{x: -75+700, y: -85}
			], color: "g", line: 2, score: 5},
			{points: [
				{x: -150+700, y: 0},
				{x: -75+700, y: 190},
				{x: 75+700, y: 190},
				{x: 150+700, y: 0},
				{x: 150+700, y: -145},
				{x: 50+700, y: -260},
				{x: -50+700, y: -260},
				{x: -150+700, y: -145}
			], color: "g", line: 2, score: 4},
			{points: [
				{x: -225+700, y: 0},
				{x: -75+700, y: 190},
				{x: 75+700, y: 190},
				{x: 225+700, y: 0},
				{x: 225+700, y: -190},
				{x: 75+700, y: -380},
				{x: -75+700, y: -380},
				{x: -225+700, y: -190}
			], color: "g", line: 2, score: 2},
			
		],

		text: [
			{x: 0, y: 0, size: 30, color: "bl", text: "5"},
			{x: -112.5, y: 0, size: 30, color: "bl", text: "4"},
			{x: 112.5, y: 0, size: 30, color: "bl", text: "4"},
			{x: -187.5, y: 0, size: 30, color: "bl", text: "2"},
			{x: 187.5, y: 0, size: 30, color: "bl", text: "2"},
		]

	};


	targetfaces["IPSCRifleMinor"] = {
		name: "IPSC Rifle (Minor)",
		shortname: "IPSC Rifle (Minor)",
		dist: 100,
		dist_unit: "y",
		score: [5],
		board: {w: 750, h: 1200, line: 0, score: 0},

		poly: [
			{points: [
				{x: -75, y: 0},
				{x: -25, y: 165},
				{x: 25, y: 165},
				{x: 75, y: 0},
				{x: 75, y: -85},
				{x: 25, y: -160},
				{x: -25, y: -160},
				{x: -75, y: -85}
			], color: "g", line: 2, score: 5},
			{points: [
				{x: -150, y: 0},
				{x: -75, y: 190},
				{x: 75, y: 190},
				{x: 150, y: 0},
				{x: 150, y: -145},
				{x: 50, y: -260},
				{x: -50, y: -260},
				{x: -150, y: -145}
			], color: "g", line: 2, score: 3},
			{points: [
				{x: -225, y: 0},
				{x: -75, y: 190},
				{x: 75, y: 190},
				{x: 225, y: 0},
				{x: 225, y: -190},
				{x: 75, y: -380},
				{x: -75, y: -380},
				{x: -225, y: -190}
			], color: "g", line: 2, score: 1},
		],

		text: [
			{x: 0, y: 0, size: 30, color: "bl", text: "5"},
			{x: -112.5, y: 0, size: 30, color: "bl", text: "3"},
			{x: 112.5, y: 0, size: 30, color: "bl", text: "3"},
			{x: -187.5, y: 0, size: 30, color: "bl", text: "1"},
			{x: 187.5, y: 0, size: 30, color: "bl", text: "1"},
		]

	};


	targetfaces["IPSCMiniMajor"] = {
		name: "IPSC Mini (Major)",
		shortname: "IPSC Mini (Major)",
		dist: 100,
		dist_unit: "y",
		score: [5],
		board: {w: 750, h: 1200, line: 0, score: 0},

		poly: [
			{points: [
				{x: -50, y: 0},
				{x: -20, y: 110},
				{x: 20, y: 110},
				{x: 50, y: 0},
				{x: 50, y: -55},
				{x: 20, y: -105},
				{x: -20, y: -105},
				{x: -50, y: -55}
			], color: "g", line: 2, score: 5},
			{points: [
				{x: -100, y: 0},
				{x: -50, y: 125},
				{x: 50, y: 125},
				{x: 100, y: 0},
				{x: 100, y: -95},
				{x: 35, y: -175},
				{x: -35, y: -175},
				{x: -100, y: -95}
			], color: "g", line: 2, score: 4},
			{points: [
				{x: -150, y: 0},
				{x: -50, y: 125},
				{x: 50, y: 125},
				{x: 150, y: 0},
				{x: 150, y: -125},
				{x: 50, y: -250},
				{x: -50, y: -250},
				{x: -150, y: -125}
			], color: "g", line: 2, score: 2},
		],

		text: [
			{x: 0, y: 0, size: 30, color: "bl", text: "5"},
			{x: -75, y: 0, size: 30, color: "bl", text: "4"},
			{x: 75, y: 0, size: 30, color: "bl", text: "4"},
			{x: -125, y: 0, size: 30, color: "bl", text: "2"},
			{x: 125, y: 0, size: 30, color: "bl", text: "2"},
		]

	};

	targetfaces["IPSCMiniMinor"] = {
		name: "IPSC Mini (Minor)",
		shortname: "IPSC Mini (Minor)",
		dist: 100,
		dist_unit: "y",
		score: [5],
		board: {w: 750, h: 1200, line: 0, score: 0},

		poly: [
			{points: [
				{x: -50, y: 0},
				{x: -20, y: 110},
				{x: 20, y: 110},
				{x: 50, y: 0},
				{x: 50, y: -55},
				{x: 20, y: -105},
				{x: -20, y: -105},
				{x: -50, y: -55}
			], color: "g", line: 2, score: 5},
			{points: [
				{x: -100, y: 0},
				{x: -50, y: 125},
				{x: 50, y: 125},
				{x: 100, y: 0},
				{x: 100, y: -95},
				{x: 35, y: -175},
				{x: -35, y: -175},
				{x: -100, y: -95}
			], color: "g", line: 2, score: 3},
			{points: [
				{x: -150, y: 0},
				{x: -50, y: 125},
				{x: 50, y: 125},
				{x: 150, y: 0},
				{x: 150, y: -125},
				{x: 50, y: -250},
				{x: -50, y: -250},
				{x: -150, y: -125}
			], color: "g", line: 2, score: 1},
		],

		text: [
			{x: 0, y: 0, size: 30, color: "bl", text: "5"},
			{x: -75, y: 0, size: 30, color: "bl", text: "3"},
			{x: 75, y: 0, size: 30, color: "bl", text: "3"},
			{x: -125, y: 0, size: 30, color: "bl", text: "1"},
			{x: 125, y: 0, size: 30, color: "bl", text: "1"},
		]

	};

	targetfaces["IPSCUniversalMajor"] = {
		name: "IPSC Universal (Major)",
		shortname: "IPSC Universal (Major)",
		dist: 100,
		dist_unit: "y",
		score: [5],
		board: {w: 750, h: 1200, line: 0, score: 0},

		poly: [
			{points: [
				{x: -75, y: 85},
				{x: -25, y: 280},
				{x: 25, y: 280},
				{x: 75, y: 85},
				{x: 75, y: 0},
				{x: 25, y: -125},
				{x: -25, y: -125},
				{x: -75, y: 0}
			], color: "g", line: 2, score: 5},
			{points: [
				{x: -150, y: 95},
				{x: -75, y: 305},
				{x: 75, y: 305},
				{x: 150, y: 95},
				{x: 150, y: -25},
				{x: 50, y: -275},
				{x: -50, y: -275},
				{x: -150, y: -25}
			], color: "g", line: 2, score: 4},
			{points: [
				{x: -225, y: 115},
				{x: -75, y: 305},
				{x: 75, y: 305},
				{x: 225, y: 115},
				{x: 225, y: -75},
				{x: 75, y: -445},
				{x: -75, y: -445},
				{x: -225, y: -75}
			], color: "g", line: 2, score: 2},
		],

		text: [
			{x: 0, y: 42.5, size: 30, color: "bl", text: "5"},
			{x: 0, y: -200, size: 30, color: "bl", text: "4"},
			{x: 0, y: -360, size: 30, color: "bl", text: "2"},
		]

	};

	targetfaces["IPSCUniversalMinor"] = {
		name: "IPSC Universal (Minor)",
		shortname: "IPSC Universal (Minor)",
		dist: 100,
		dist_unit: "y",
		score: [5],
		board: {w: 750, h: 1200, line: 0, score: 0},

		poly: [
			{points: [
				{x: -75, y: 85},
				{x: -25, y: 280},
				{x: 25, y: 280},
				{x: 75, y: 85},
				{x: 75, y: 0},
				{x: 25, y: -125},
				{x: -25, y: -125},
				{x: -75, y: 0}
			], color: "g", line: 2, score: 5},
			{points: [
				{x: -150, y: 95},
				{x: -75, y: 305},
				{x: 75, y: 305},
				{x: 150, y: 95},
				{x: 150, y: -25},
				{x: 50, y: -275},
				{x: -50, y: -275},
				{x: -150, y: -25}
			], color: "g", line: 2, score: 3},
			{points: [
				{x: -225, y: 115},
				{x: -75, y: 305},
				{x: 75, y: 305},
				{x: 225, y: 115},
				{x: 225, y: -75},
				{x: 75, y: -445},
				{x: -75, y: -445},
				{x: -225, y: -75}
			], color: "g", line: 2, score: 1},
		],

		text: [
			{x: 0, y: 42.5, size: 30, color: "bl", text: "5"},
			{x: 0, y: -200, size: 30, color: "bl", text: "3"},
			{x: 0, y: -360, size: 30, color: "bl", text: "1"},
		]

	};


	targetfaces["IPSCHalfMajor"] = {
		name: "IPSC Half (Major)",
		shortname: "IPSC Half (Major)",
		dist: 100,
		dist_unit: "y",
		score: [5],
		board: {w: 750, h: 1200, line: 0, score: 0},

		poly: [
			{points: [
				{x: -75/2, y: 0},
				{x: -25/2, y: 165/2},
				{x: 25/2, y: 165/2},
				{x: 75/2, y: 0},
				{x: 75/2, y: -85/2},
				{x: 25/2, y: -160/2},
				{x: -25/2, y: -160/2},
				{x: -75/2, y: -85/2}
			], color: "g", line: 2, score: 5},
			{points: [
				{x: -150/2, y: 0},
				{x: -75/2, y: 190/2},
				{x: 75/2, y: 190/2},
				{x: 150/2, y: 0},
				{x: 150/2, y: -145/2},
				{x: 50/2, y: -260/2},
				{x: -50/2, y: -260/2},
				{x: -150/2, y: -145/2}
			], color: "g", line: 2, score: 4},
			{points: [
				{x: -225/2, y: 0},
				{x: -75/2, y: 190/2},
				{x: 75/2, y: 190/2},
				{x: 225/2, y: 0},
				{x: 225/2, y: -190/2},
				{x: 75/2, y: -380/2},
				{x: -75/2, y: -380/2},
				{x: -225/2, y: -190/2}
			], color: "g", line: 2, score: 2},
		],

		text: [
			{x: 0, y: 0, size: 15, color: "bl", text: "5"},
			{x: -112.5/2, y: 0, size: 15, color: "bl", text: "4"},
			{x: 112.5/2, y: 0, size: 15, color: "bl", text: "4"},
			{x: -187.5/2, y: 0, size: 15, color: "bl", text: "2"},
			{x: 187.5/2, y: 0, size: 15, color: "bl", text: "2"},
		]

	};

	targetfaces["IPSCHalfMinor"] = {
		name: "IPSC Half (Minor)",
		shortname: "IPSC Half (Minor)",
		dist: 100,
		dist_unit: "y",
		score: [5],
		board: {w: 750, h: 1200, line: 0, score: 0},

		poly: [
			{points: [
				{x: -75/2, y: 0},
				{x: -25/2, y: 165/2},
				{x: 25/2, y: 165/2},
				{x: 75/2, y: 0},
				{x: 75/2, y: -85/2},
				{x: 25/2, y: -160/2},
				{x: -25/2, y: -160/2},
				{x: -75/2, y: -85/2}
			], color: "g", line: 2, score: 5},
			{points: [
				{x: -150/2, y: 0},
				{x: -75/2, y: 190/2},
				{x: 75/2, y: 190/2},
				{x: 150/2, y: 0},
				{x: 150/2, y: -145/2},
				{x: 50/2, y: -260/2},
				{x: -50/2, y: -260/2},
				{x: -150/2, y: -145/2}
			], color: "g", line: 2, score: 3},
			{points: [
				{x: -225/2, y: 0},
				{x: -75/2, y: 190/2},
				{x: 75/2, y: 190/2},
				{x: 225/2, y: 0},
				{x: 225/2, y: -190/2},
				{x: 75/2, y: -380/2},
				{x: -75/2, y: -380/2},
				{x: -225/2, y: -190/2}
			], color: "g", line: 2, score: 1},
		],

		text: [
			{x: 0, y: 0, size: 15, color: "bl", text: "5"},
			{x: -112.5/2, y: 0, size: 15, color: "bl", text: "3"},
			{x: 112.5/2, y: 0, size: 15, color: "bl", text: "3"},
			{x: -187.5/2, y: 0, size: 15, color: "bl", text: "1"},
			{x: 187.5/2, y: 0, size: 15, color: "bl", text: "1"},
		]

	};
	
	targetfaces["IDPA"] = {
		name: "IDPA",
		shortname: "IDPA",
		dist: 100,
		dist_unit: "y",
		score: [5],
		board: {w: 750, h: 1200, line: 0, score: 0},
		
		rings: [
				{x: 0, y: 0, diam: 8/INCH, color: "bl", line: 2, score: 5},
				{x: 0, y: 10/INCH, diam: 4/INCH, color: "bl", line: 2, score: 5}
		],

		poly: [
			{points: [
				{x: -3/INCH, y: -11/INCH},
				{x: -6/INCH, y: -6/INCH},
				{x: -6/INCH, y: 4/INCH},
				{x: -3/INCH, y: 7/INCH},
				{x: -3/INCH, y: 13/INCH},
				{x: 3/INCH, y: 13/INCH},
				{x: 3/INCH, y: 7/INCH},
				{x: 6/INCH, y: 4/INCH},
				{x: 6/INCH, y: -6/INCH},
				{x: 3/INCH, y: -11/INCH},
			], color: "g", line: 2, score: 4},
			{points: [
				{x: -6/INCH, y: -17/INCH},
				{x: -8.6875/INCH, y: -12/INCH},
				{x: -8.6875/INCH, y: 4/INCH},
				{x: -6.6875/INCH, y: 7/INCH},
				{x: 6.6875/INCH, y: 7/INCH},
				{x: 8.6875/INCH, y: 4/INCH},
				{x: 8.6875/INCH, y: -12/INCH},
				{x: 6/INCH, y: -17/INCH},
			], color: "g", line: 2, score: 2},
		],

		text: [
			{x: 0, y: 0, size: 30, color: "bl", text: "5"},
			{x: 0, y: 10/INCH, size: 30, color: "bl", text: "5"},
			{x: 0, y: -7.5/INCH, size: 30, color: "bl", text: "4"},
			{x: 0, y: -14/INCH, size: 30, color: "bl", text: "2"},
		]

	};
	
	targetfaces["USPSAMajor"] = {
		name: "USPSA (Major)",
		shortname: "USPSA (Major)",
		dist: 100,
		dist_unit: "y",
		score: [5],
		board: {w: 750, h: 1200, line: 0, score: 0},
		
		poly: [

			{points: polybox(0, 0, 150, 280), color: "bl", line: 2, score: 5},
			{points: polybox(0, 290, 100, 40), color: "bl", line: 2, score: 5},

			{points: [
				{x: -100, y: -260},
				{x: -150, y: -140},
				{x: -150, y: 140},
				{x: -75, y: 190},
				{x: -75, y: 340},
				{x: 75, y: 340},
				{x: 75, y: 190},
				{x: 150, y: 140},
				{x: 150, y: -140},
				{x: 100, y: -260},
			], color: "g", line: 2, score: 4},
			{points: [
				{x: -150, y: -410},
				{x: -225, y: -260},
				{x: -225, y: 140},
				{x: -175, y: 190},
				{x: 175, y: 190},
				{x: 225, y: 140},
				{x: 225, y: -260},
				{x: 150, y: -410},
			], color: "g", line: 2, score: 2},
			

		],

		text: [
			{x: 0, y: 0, size: 30, color: "bl", text: "5"},
			{x: 0, y: -7.5/INCH, size: 30, color: "bl", text: "4"},
			{x: 0, y: -14/INCH, size: 30, color: "bl", text: "2"},
		]

	};


	targetfaces["USPSAMinor"] = {
		name: "USPSA (Minor)",
		shortname: "USPSA (Minor)",
		dist: 100,
		dist_unit: "y",
		score: [5],
		board: {w: 750, h: 1200, line: 0, score: 0},
		
		poly: [

			{points: polybox(0, 0, 150, 280), color: "bl", line: 2, score: 5},
			{points: polybox(0, 290, 100, 40), color: "bl", line: 2, score: 5},

			{points: [
				{x: -100, y: -260},
				{x: -150, y: -140},
				{x: -150, y: 140},
				{x: -75, y: 190},
				{x: -75, y: 340},
				{x: 75, y: 340},
				{x: 75, y: 190},
				{x: 150, y: 140},
				{x: 150, y: -140},
				{x: 100, y: -260},
			], color: "g", line: 2, score: 3},
			{points: [
				{x: -150, y: -410},
				{x: -225, y: -260},
				{x: -225, y: 140},
				{x: -175, y: 190},
				{x: 175, y: 190},
				{x: 225, y: 140},
				{x: 225, y: -260},
				{x: 150, y: -410},
			], color: "g", line: 2, score: 1},
			

		],

		text: [
			{x: 0, y: 0, size: 30, color: "bl", text: "5"},
			{x: 0, y: -7.5/INCH, size: 30, color: "bl", text: "3"},
			{x: 0, y: -14/INCH, size: 30, color: "bl", text: "1"},
		]

	};
	

	targetfaces["B27"] = {
		name: "NRA B-27",
		shortname: "B-27",
		dist: 100,
		dist_unit: "y",
		score: ["X", 10],
		board: {w: 1200, h: 1600, line: 0, score: 0},
		
		poly: [

			{ points: polyarc(0, 12.5, 25, 0, 180, 10)
			.concat(polyarc(0, -12.5, 25, 180, 360, 10))
			, color: "g", line: 2, score: "X"},

			{ points: polyarc(0, 25, 50, 0, 180, 10)
			.concat(polyarc(0, -25, 50, 180, 360, 10))
			, color: "g", line: 2, score: 10},

			{ points: polyarc(0, 50, 100, 0, 180, 10)
			.concat(polyarc(0, -50, 100, 180, 360, 10))
			, color: "g", line: 2, score: 9},

			{ points: polyarc(0, 75, 150, 0, 180, 10)
			.concat(polyarc(0, -75, 150, 180, 360, 10))
			, color: "g", line: 2, score: 8},

			{ points: polyarc(0, 100, 200, 0, 180, 10)
			.concat(polyarc(0, -100, 200, 180, 360, 10))
			, color: "g", line: 2, score: 7},
			
			{points: [
				{x: 72.6-308.8, y: -997.1+584.3},
				{x: 46.4-308.8, y: -998.0+584.3},
				{x: 34.1-308.8, y: -820.4+584.3},
				{x: 46.4-308.8, y: -628.9+584.3},
				{x: 41.1-308.8, y: -533.5+584.3},
				{x: 37.6-308.8, y: -410.2+584.3},
				{x: 53.4-308.8, y: -369.1+584.3},
				{x: 73.5-308.8, y: -345.5+584.3},
				{x: 214.3-308.8, y: -295.6+584.3},
				{x: 237.0-308.8, y: -285.1+584.3},
				{x: 244.0-308.8, y: -274.6+584.3},
				{x: 243.1-308.8, y: -223.0+584.3},
				{x: 229.2-308.8, y: -178.4+584.3},
				{x: 219.5-308.8, y: -129.4+584.3},
				{x: 224.8-308.8, y: -84.8+584.3},
				{x: 241.4-308.8, y: -52.5+584.3},
				{x: 265.0-308.8, y: -38.5+584.3},
				{x: 290.4-308.8, y: -32.4+584.3},
				{x: 334.1-308.8, y: -32.4+584.3},
				{x: 356.8-308.8, y: -41.1+584.3},
				{x: 380.5-308.8, y: -56.9+584.3},
				{x: 393.6-308.8, y: -87.5+584.3},
				{x: 393.6-308.8, y: -138.2+584.3},
				{x: 381.3-308.8, y: -184.5+584.3},
				{x: 369.1-308.8, y: -225.7+584.3},
				{x: 370.0-308.8, y: -273.8+584.3},
				{x: 383.1-308.8, y: -286.0+584.3},
				{x: 532.7-308.8, y: -342.9+584.3},
				{x: 549.3-308.8, y: -353.4+584.3},
				{x: 565.9-308.8, y: -375.2+584.3},
				{x: 574.6-308.8, y: -401.5+584.3},
				{x: 579.0-308.8, y: -434.7+584.3},
				{x: 574.6-308.8, y: -561.5+584.3},
				{x: 572.9-308.8, y: -644.6+584.3},
				{x: 581.6-308.8, y: -753.1+584.3},
				{x: 582.5-308.8, y: -926.2+584.3},
				{x: 575.5-308.8, y: -998.8+584.3},
				{x: 554.5-308.8, y: -999.7+584.3},
				{x: 565.9-308.8, y: -1066.2+584.3},
				{x: 539.6-308.8, y: -1105.5+584.3},
				{x: 512.5-308.8, y: -1114.3+584.3},
				{x: 98.0-308.8, y: -1113.4+584.3},
				{x: 59.5-308.8, y: -1064.4+584.3},
			], color: "g", line: 0, score: 0},
			
		],

		text: [
			{x: 0, y: 0, size: 25, color: "bl", text: "X"},
			{x: 0, y: -56.25, size: 25, color: "bl", text: "10"},
			{x: 0, y: -112.5, size: 25, color: "bl", text: "9"},
			{x: 0, y: -187.5, size: 25, color: "bl", text: "8"},
			{x: 0, y: -262.5, size: 25, color: "bl", text: "7"},
		]

	};
	

	targetfaces["B27Q"] = {
		name: "NRA B-27 (Qualification)",
		shortname: "B-27 (Qualification)",
		dist: 100,
		dist_unit: "y",
		score: [5],
		board: {w: 1200, h: 1600, line: 0, score: 0},
		
		poly: [

			{ points: polyarc(0, 12.5, 25, 0, 180, 10)
			.concat(polyarc(0, -12.5, 25, 180, 360, 10))
			, color: "g", line: 2, score: 5},

			{ points: polyarc(0, 25, 50, 0, 180, 10)
			.concat(polyarc(0, -25, 50, 180, 360, 10))
			, color: "g", line: 2, score: 5},

			{ points: polyarc(0, 50, 100, 0, 180, 10)
			.concat(polyarc(0, -50, 100, 180, 360, 10))
			, color: "g", line: 2, score: 5},

			{ points: polyarc(0, 75, 150, 0, 180, 10)
			.concat(polyarc(0, -75, 150, 180, 360, 10))
			, color: "g", line: 2, score: 5},

			{ points: polyarc(0, 100, 200, 0, 180, 10)
			.concat(polyarc(0, -100, 200, 180, 360, 10))
			, color: "g", line: 2, score: 4},
			
			{points: [
				{x: 72.6-308.8, y: -997.1+584.3},
				{x: 46.4-308.8, y: -998.0+584.3},
				{x: 34.1-308.8, y: -820.4+584.3},
				{x: 46.4-308.8, y: -628.9+584.3},
				{x: 41.1-308.8, y: -533.5+584.3},
				{x: 37.6-308.8, y: -410.2+584.3},
				{x: 53.4-308.8, y: -369.1+584.3},
				{x: 73.5-308.8, y: -345.5+584.3},
				{x: 214.3-308.8, y: -295.6+584.3},
				{x: 237.0-308.8, y: -285.1+584.3},
				{x: 244.0-308.8, y: -274.6+584.3},
				{x: 243.1-308.8, y: -223.0+584.3},
				{x: 229.2-308.8, y: -178.4+584.3},
				{x: 219.5-308.8, y: -129.4+584.3},
				{x: 224.8-308.8, y: -84.8+584.3},
				{x: 241.4-308.8, y: -52.5+584.3},
				{x: 265.0-308.8, y: -38.5+584.3},
				{x: 290.4-308.8, y: -32.4+584.3},
				{x: 334.1-308.8, y: -32.4+584.3},
				{x: 356.8-308.8, y: -41.1+584.3},
				{x: 380.5-308.8, y: -56.9+584.3},
				{x: 393.6-308.8, y: -87.5+584.3},
				{x: 393.6-308.8, y: -138.2+584.3},
				{x: 381.3-308.8, y: -184.5+584.3},
				{x: 369.1-308.8, y: -225.7+584.3},
				{x: 370.0-308.8, y: -273.8+584.3},
				{x: 383.1-308.8, y: -286.0+584.3},
				{x: 532.7-308.8, y: -342.9+584.3},
				{x: 549.3-308.8, y: -353.4+584.3},
				{x: 565.9-308.8, y: -375.2+584.3},
				{x: 574.6-308.8, y: -401.5+584.3},
				{x: 579.0-308.8, y: -434.7+584.3},
				{x: 574.6-308.8, y: -561.5+584.3},
				{x: 572.9-308.8, y: -644.6+584.3},
				{x: 581.6-308.8, y: -753.1+584.3},
				{x: 582.5-308.8, y: -926.2+584.3},
				{x: 575.5-308.8, y: -998.8+584.3},
				{x: 554.5-308.8, y: -999.7+584.3},
				{x: 565.9-308.8, y: -1066.2+584.3},
				{x: 539.6-308.8, y: -1105.5+584.3},
				{x: 512.5-308.8, y: -1114.3+584.3},
				{x: 98.0-308.8, y: -1113.4+584.3},
				{x: 59.5-308.8, y: -1064.4+584.3},
			], color: "g", line: 0, score: 3},
			
		],

		text: [
			{x: 0, y: -187.5, size: 25, color: "bl", text: "5"},
			{x: 0, y: -262.5, size: 25, color: "bl", text: "4"},
			{x: 0, y: -350.5, size: 25, color: "bl", text: "3"},
		]

	};
	

	targetfaces["B27E"] = {
		name: "NRA B-27E",
		shortname: "B-27E",
		dist: 100,
		dist_unit: "y",
		score: ["X", 10],
		board: {w: 1200, h: 1600, line: 0, score: 0},
		
		poly: [

			{ points: polyarc(0, 12.5, 25, 0, 180, 10)
			.concat(polyarc(0, -12.5, 25, 180, 360, 10))
			, color: "g", line: 2, score: "X"},

			{ points: polyarc(0, 25, 50, 0, 180, 10)
			.concat(polyarc(0, -25, 50, 180, 360, 10))
			, color: "g", line: 2, score: 10},

			{ points: polyarc(0, 50, 100, 0, 180, 10)
			.concat(polyarc(0, -50, 100, 180, 360, 10))
			, color: "g", line: 2, score: 9},

			{ points: polyarc(0, 75, 150, 0, 180, 10)
			.concat(polyarc(0, -75, 150, 180, 360, 10))
			, color: "g", line: 2, score: 8},

			{ points: polyarc(0, 100, 200, 0, 180, 10)
			.concat(polyarc(0, -100, 200, 180, 360, 10))
			, color: "g", line: 2, score: 7},
			
			{points: [
				{x: 34.1-308.8, y: -900+584.3},
				{x: 46.4-308.8, y: -628.9+584.3},
				{x: 41.1-308.8, y: -533.5+584.3},
				{x: 37.6-308.8, y: -410.2+584.3},
				{x: 53.4-308.8, y: -369.1+584.3},
				{x: 73.5-308.8, y: -345.5+584.3},
				{x: 214.3-308.8, y: -295.6+584.3},
				{x: 237.0-308.8, y: -285.1+584.3},
				{x: 244.0-308.8, y: -274.6+584.3},
				{x: 243.1-308.8, y: -223.0+584.3},
				{x: 229.2-308.8, y: -178.4+584.3},
				{x: 219.5-308.8, y: -129.4+584.3},
				{x: 224.8-308.8, y: -84.8+584.3},
				{x: 241.4-308.8, y: -52.5+584.3},
				{x: 265.0-308.8, y: -38.5+584.3},
				{x: 290.4-308.8, y: -32.4+584.3},
				{x: 334.1-308.8, y: -32.4+584.3},
				{x: 356.8-308.8, y: -41.1+584.3},
				{x: 380.5-308.8, y: -56.9+584.3},
				{x: 393.6-308.8, y: -87.5+584.3},
				{x: 393.6-308.8, y: -138.2+584.3},
				{x: 381.3-308.8, y: -184.5+584.3},
				{x: 369.1-308.8, y: -225.7+584.3},
				{x: 370.0-308.8, y: -273.8+584.3},
				{x: 383.1-308.8, y: -286.0+584.3},
				{x: 532.7-308.8, y: -342.9+584.3},
				{x: 549.3-308.8, y: -353.4+584.3},
				{x: 565.9-308.8, y: -375.2+584.3},
				{x: 574.6-308.8, y: -401.5+584.3},
				{x: 579.0-308.8, y: -434.7+584.3},
				{x: 574.6-308.8, y: -561.5+584.3},
				{x: 572.9-308.8, y: -644.6+584.3},
				{x: 581.6-308.8, y: -753.1+584.3},
				{x: 582.5-308.8, y: -900+584.3},
			], color: "g", line: 0, score: 0},
			
		],

		text: [
			{x: 0, y: 0, size: 25, color: "bl", text: "X"},
			{x: 0, y: -56.25, size: 25, color: "bl", text: "10"},
			{x: 0, y: -112.5, size: 25, color: "bl", text: "9"},
			{x: 0, y: -187.5, size: 25, color: "bl", text: "8"},
			{x: 0, y: -262.5, size: 25, color: "bl", text: "7"},
		]

	};
	
	targetfaces["B27ES"] = {
		name: "NRA B-27E (Simplified)",
		shortname: "B-27E (Simplified)",
		dist: 100,
		dist_unit: "y",
		score: [10],
		board: {w: 1200, h: 1600, line: 0, score: 0},
		
		rings_top: [
		
			{diam: 9/INCH, color: "w", line: 0, score: 10}
		
		],
		
		poly: [
	
			{points: [
				{x: 34.1-308.8, y: -900+584.3},
				{x: 46.4-308.8, y: -628.9+584.3},
				{x: 41.1-308.8, y: -533.5+584.3},
				{x: 37.6-308.8, y: -410.2+584.3},
				{x: 53.4-308.8, y: -369.1+584.3},
				{x: 73.5-308.8, y: -345.5+584.3},
				{x: 214.3-308.8, y: -295.6+584.3},
				{x: 237.0-308.8, y: -285.1+584.3},
				{x: 244.0-308.8, y: -274.6+584.3},
				{x: 243.1-308.8, y: -223.0+584.3},
				{x: 229.2-308.8, y: -178.4+584.3},
				{x: 219.5-308.8, y: -129.4+584.3},
				{x: 224.8-308.8, y: -84.8+584.3},
				{x: 241.4-308.8, y: -52.5+584.3},
				{x: 265.0-308.8, y: -38.5+584.3},
				{x: 290.4-308.8, y: -32.4+584.3},
				{x: 334.1-308.8, y: -32.4+584.3},
				{x: 356.8-308.8, y: -41.1+584.3},
				{x: 380.5-308.8, y: -56.9+584.3},
				{x: 393.6-308.8, y: -87.5+584.3},
				{x: 393.6-308.8, y: -138.2+584.3},
				{x: 381.3-308.8, y: -184.5+584.3},
				{x: 369.1-308.8, y: -225.7+584.3},
				{x: 370.0-308.8, y: -273.8+584.3},
				{x: 383.1-308.8, y: -286.0+584.3},
				{x: 532.7-308.8, y: -342.9+584.3},
				{x: 549.3-308.8, y: -353.4+584.3},
				{x: 565.9-308.8, y: -375.2+584.3},
				{x: 574.6-308.8, y: -401.5+584.3},
				{x: 579.0-308.8, y: -434.7+584.3},
				{x: 574.6-308.8, y: -561.5+584.3},
				{x: 572.9-308.8, y: -644.6+584.3},
				{x: 581.6-308.8, y: -753.1+584.3},
				{x: 582.5-308.8, y: -900+584.3},
			], color: "g", line: 0, score: 5},
			
		],

		text: [
			{x: 0, y: 0, size: 25, color: "bl", text: "10"},
			{x: 0, y: -9/INCH, size: 25, color: "bl", text: "5"},
			{x: -220, y: -310, size: 10, color: "bl", text: "B-27E with 9\" ring"},
		]

	};
	
	targetfaces["TRD"] = {
		name: "Target Rifle D / F",
		shortname: "D / F",
		dist: 300,
		dist_unit: "y",
		score: [1],
		board: {w: 1200, h: 1200, line: 0, score: 0},
		
		poly: [
	
			{points: [

				{x: -327.5, y: -155.3},
				{x: -327.1, y: -23.0},
				{x: -321.8, y: 1.6},
				{x: -314.8, y: 20.1},
				{x: -303.7, y: 39.0},
				{x: -290.1, y: 54.7},
				{x: -271.2, y: 69.9},
				{x: -254.4, y: 82.2},
				{x: -235.1, y: 93.7},
				{x: -214.9, y: 104.8},
				{x: -191.5, y: 121.6},
				{x: -171.4, y: 138.9},
				{x: -154.5, y: 157.0},
				{x: -140.5, y: 174.7},
				{x: -131.1, y: 193.6},
				{x: -123.7, y: 215.3},
				{x: -117.9, y: 241.6},
				{x: -107.3, y: 266.3},
				{x: -94.5, y: 284.8},
				{x: -72.7, y: 305.8},
				{x: -46.8, y: 321.0},
				{x: -22.2, y: 329.2},
				{x: 2.5, y: 330.8},
				{x: 25.1, y: 328.8},
				{x: 46.0, y: 323.4},
				{x: 66.2, y: 313.2},
				{x: 85.1, y: 299.6},
				{x: 99.9, y: 283.6},
				{x: 111.8, y: 263.8},
				{x: 121.2, y: 241.2},
				{x: 125.8, y: 217.4},
				{x: 131.9, y: 196.4},
				{x: 141.8, y: 176.3},
				{x: 156.2, y: 157.4},
				{x: 172.6, y: 141.4},
				{x: 190.3, y: 124.1},
				{x: 210.8, y: 109.7},
				{x: 232.2, y: 96.2},
				{x: 253.2, y: 85.1},
				{x: 276.2, y: 71.9},
				{x: 302.1, y: 48.9},
				{x: 318.1, y: 25.9},
				{x: 327.9, y: 1.6},
				{x: 332.9, y: -21.8},
				{x: 332.1, y: -155.3},

			], color: "g", line: 0, score: 1},
			
		],

	};

	// selected when face_id is invalid
	targetfaces["error"] = {
		name: "Target Face Error", // full name for main target
		shortname: "Error", // short name for selection list
		dist: 100, // default dist
		dist_unit: "m", // default unit
		score: [5], // scoring system
		board: {w: 1000, h: 1000, line: 20, score: 0},
		rings: [	{diam: 100, color: "b", line: 0, score: 1}   ],
	};

	// define categories and all faces used for face selection UI
	targetface_categories = [
		{	name: "Favorites",
			faces: []
		},
		{	name: "Misc",
			faces: ["LoadDev", "Dot14", "Dot1", "Dot2", "Dot3", "Rings1", "Rings2", "Rings3", "Diamonds1", "Diamonds2", "Calibration", "JRB", "Champion45726", "Champion46102", "Champion47388", "Splat1218", "NASS", "ISSFC50", "ISSFC200", "ISSF300", "ISSF300x15", "NALRSA", "SSAACore", "SSAAMiniCore", "AmericanS1", "NRA_LR_800", "NRA_LRFC_800", "NRA_MR1_400", "FCSA_MR1", "NRA_A33", "AU_MR", "AU_MRFC", "AT_600", "303B200", "303B300", "303B500", "NRA_A32", "NRA_A23_5", "RNBRA", "RingTarget200", "TRD", "Core", "MiniCore", "SSAAFly"]
		},
		{	name: "NRA High Power",
			faces: ["NRA_C1", "NRA_C2", "NRA_C3", "NRA_SR1", "NRA_SR21", "NRA_MR31", "NRA_SR", "NRA_SR42", "NRA_MR52", "NRA_SR5", "NRA_SR3", "NRA_MR63", "NRA_MR63FC", "NRA_MR", "NRA_MR65FC", "NRA_MR1", "NRA_MR1FC", "NRA_MR1FCA", "NRA_LR", "NRA_LRFC"]
		},
		{	name: "ICFRA F-Class 2014 (V, 5)",
			faces: ["IF300y", "IF300m", "IF400y", "IF400m", "IF500y", "IF500m", "IF600y", "IF600m", "IFLR"]
		},
		{	name: "ICFRA F-Class 2008 (X, 6)",
			faces: ["IFX300y", "IFX300m", "IFX400y", "IFX400m", "IFX500y", "IFX500m", "IFX600y", "IFX600m", "IFXLR"]
		},
		{	name: "ICFRA Target Rifle",
			faces: ["IS300y", "IS300m", "IS400y", "IS400m", "IS500y", "IS500m", "IS600y", "IS600m", "ISLR"]
		},
		{	name: "DCRA F-Class",
			faces: ["DF100y", "DF200y", "DF300y", "DF300m", "DF400y", "DF400m", "DF500y", "DF500m", "DF600y", "DF600m", "DFLR"]
		},
		{	name: "DCRA Target Rifle",
			faces: ["DS100y", "DS200y", "DS300y", "DS300m", "DS400y", "DS400m", "DS500y", "DS500m", "DS600y", "DS600m", "DSLR"]
		},
		{	name: "NRA UK (Bisley)",
			faces: ["UKTR200", "UKFC200", "UKTR300", "UKFC300", "UKTR400", "UKFC400", "UKTR500", "UKFC500", "UKTR600", "UKFC600", "UKTRLR", "UKFCLR"]
		},
		{	name: "South Africa Bisley Union",
			faces: ["SASRTR", "SASRFC", "SAMRTR", "SAMRFC", "SALRTR", "SALRFC", "SASRVX", "SAMRVX", "SALRVX"]
		},
		{	name: "IBS / Benchrest",
			faces: ["IBS100BR", "IBS100HR", "IBS200BR", "IBS200HR", "IBS300BR", "IBS300HR", "IBS600BR", "IBS600Bx3", "IBS1000BR", "Hunter100", "Hunter200"]
		},
		{	name: "Swiss",
			faces: ["SW_A10", "SW_A5", "SW_B4", "SW_B4_200", "SW_A100", "SW_A100_200Y", "SW_A5_200Y"]
		},
		{	name: "Figure Targets (US)",
			faces: ["USE", "B27", "B27Q", "B27E", "B27ES", "TRD", "SRCR"]
		},
		{	name: "Figure Targets (US - Appendix 9)",
			faces: ["A9EIC", "A9Fig11", "A9Fig11P", "A9Fig12", "A9Fig14", "A9Fig22"]
		},
		{	name: "Figure Targets (UK)",
			faces: ["Fig11SR", "Fig11LR", "Fig11LRx2", "Fig11LRx3A", "Fig11LRx3B", "Fig11LRx3C", "Fig11LRx5", "Fig11A", "Fig11B", "Fig12", "Fig12B", "Fig12C", "Fig1259C", "Fig14", "Fig14W"]
		},
		{	name: "Figure Targets (AU)",
			faces: ["Fig11AU", "Fig11DAU", "Fig12AU", "Fig13AU", "Fig14AU"]
		},
		{	name: "Other Silhouettes",
			faces: ["Buffalo", "Chicken", "Ram", "Turkey", "Pig"]
		},
		{	name: "IPSC / IDPA / USPSA",
			faces: ["IDPA", "USPSAMajor", "USPSAMinor", "IPSCHalfMajor", "IPSCHalfMinor", "IPSCRifleMajor", "IPSCRifleMajor3", "IPSCRifleMinor", "IPSCMiniMajor", "IPSCMiniMinor", "IPSCUniversalMajor", "IPSCUniversalMinor"]
		},
		{	name: "Norway F-Class",
			faces: ["NOR200", "NOR300", "NOR500", "NOR500UNL", "NOR1000"]
		},
	];


	// load custom targets

	if (typeof(custom_targetfaces) == "object" && typeof(init_custom_targetfaces) == "function") {

		init_custom_targetfaces();

		var custom_count = Object.keys(custom_targetfaces).length;
		if (custom_count) {

			log("loading " + custom_count + " custom target faces");

			var custom_ids = [];

			for (var id in custom_targetfaces) {
				log("loading custom target face " + id);

				var use_id = "CUSTOM_" + id;

				custom_targetfaces[id].shortname = custom_targetfaces[id].name;

				custom_targetfaces[id].force_colors = true;

				custom_ids.push(use_id);
				targetfaces[use_id] = custom_targetfaces[id];

			}

			if (custom_ids.length) {

				targetface_categories.splice(1, 0, {
					name: "CUSTOM",
					faces: custom_ids,
				});

			}

		}

	}

	// prep all faces
	for (var f in targetfaces) {
		var face = targetfaces[f];
		face.id = f;
		if (face.default_ring_text) add_default_ring_text(face);
	}

}


// return face object by id, or default error
function get_face(id) {
	return targetfaces[id] || targetfaces["error"];
}

